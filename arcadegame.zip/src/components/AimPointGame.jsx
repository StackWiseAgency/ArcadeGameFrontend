import React, { useState, useEffect } from "react";
import "./AimPointGame.css";

const AimPointGame = () => {
  // State Variables
  // eslint-disable-next-line
  const [board, setBoard] = useState(Array(3).fill(Array(3).fill(null))); // 3x3 grid
  const [activeTarget, setActiveTarget] = useState(null); // Active target index
  const [score, setScore] = useState(0); // Player's score
  const [missedTargets, setMissedTargets] = useState(0); // Missed targets count
  const [timer, setTimer] = useState(120); // 2-minute timer
  const [targetDuration, setTargetDuration] = useState(5); // Duration target stays active
  const [activationInterval, setActivationInterval] = useState(4); // Time between activations
  const [gameEnded, setGameEnded] = useState(false); // Game over flag

  // Timer Management
  useEffect(() => {
    if (timer === 0 || gameEnded) return; // Stop if game ends

    const countdown = setInterval(() => {
      setTimer((prev) => Math.max(prev - 1, 0));
    }, 1000); // Decrease timer every second

    return () => clearInterval(countdown); // Cleanup
  }, [timer, gameEnded]);

  // Target Activation
  useEffect(() => {
    if (gameEnded) return; // Stop target activation if game ends

    const interval = setInterval(() => {
      const randomIndex = Math.floor(Math.random() * 9); // Random index
      setActiveTarget(randomIndex);

      const timeout = setTimeout(() => {
        if (activeTarget === randomIndex) {
          setMissedTargets((prev) => prev + 1); // Increment missed targets
          setActiveTarget(null);
        }
      }, targetDuration * 1000); // Target stays active for targetDuration seconds

      return () => clearTimeout(timeout); // Cleanup timeout
    }, activationInterval * 1000); // Activate every interval seconds

    return () => clearInterval(interval); // Cleanup interval
  }, [activationInterval, targetDuration, gameEnded, activeTarget]);

  // Game Over Check
  useEffect(() => {
    if (timer === 0 || missedTargets >= 20) {
      setGameEnded(true);
    }
  }, [timer, missedTargets]);

  // Dynamic Speed and Duration Decay
  useEffect(() => {
    const decayInterval = setInterval(() => {
      setActivationInterval((prev) => Math.max(prev - 0.5, 1)); // Decrease interval to minimum 1 sec
      setTargetDuration((prev) => Math.max(prev - 0.5, 2)); // Decrease duration to minimum 2 sec
    }, 10000); // Decay every 10 seconds

    return () => clearInterval(decayInterval); // Cleanup
  }, []);

  // Handle Cell Click
  const handleCellClick = (index) => {
    if (gameEnded) return; // Ignore clicks if game ended

    if (index === activeTarget) {
      setScore((prev) => prev + 1); // Increment score
      setActiveTarget(null); // Deactivate target
    } else {
      setMissedTargets((prev) => prev + 1); // Increment missed targets
    }
  };

  // Render UI
  return (
    <div className="game-container-point">
      <div className="game-board-point">
        {board.flat().map((_, index) => (
          <div
            key={index}
            className={`board-cell-point ${
              index === activeTarget ? "active-target-point" : ""
            }`}
            onClick={() => handleCellClick(index)}
          ></div>
        ))}
      </div>
      <div className="scoreboard-point">
        <h2>Score: {score}</h2>
        <h2>Missed Targets: {missedTargets}</h2>
        <h2>Time Left: {timer}s</h2>
        {activeTarget !== null ? (
          <h2 className="target-duration-point">Target Duration: {targetDuration}s</h2>
        ) : (
          <h2 className="activation-interval-point">Activation Interval: {activationInterval}s</h2>
        )}
      </div>
      {gameEnded && <h2 className="game-over-point">Game Over!</h2>}
    </div>
  );
};

export default AimPointGame;


// import React, { useState, useEffect } from "react";
// import "./AimPointGame.css";

// const AimPointGame = () => {
//   // State Variables
//   const [board, setBoard] = useState(Array(3).fill(Array(3).fill(null))); // 3x3 grid
//   const [activeTarget, setActiveTarget] = useState(null); // Active target index
//   const [score, setScore] = useState(0); // Player's score
//   const [missedTargets, setMissedTargets] = useState(0); // Missed targets count
//   const [timer, setTimer] = useState(120); // 2-minute timer
//   const [targetDuration, setTargetDuration] = useState(5); // Duration target stays active
//   const [interval, setIntervalState] = useState(4); // Time between activations
//   const [gameEnded, setGameEnded] = useState(false); // Game over flag

//   // Timer Management
//   useEffect(() => {
//     if (timer === 0 || gameEnded) return; // Stop if game ends

//     const countdown = setInterval(() => {
//       setTimer((prev) => Math.max(prev - 1, 0));
//     }, 1000); // Decrease timer every second

//     return () => clearInterval(countdown); // Cleanup
//   }, [timer, gameEnded]);

//   // Target Activation
//   useEffect(() => {
//     if (gameEnded) return; // Stop target activation if game ends

//     const activationInterval = setInterval(() => {
//       const randomIndex = Math.floor(Math.random() * 9); // Random index
//       setActiveTarget(randomIndex);

//       const timeout = setTimeout(() => {
//         if (activeTarget === randomIndex) {
//           setMissedTargets((prev) => prev + 1); // Increment missed targets
//           setActiveTarget(null);
//         }
//       }, targetDuration * 1000); // Target stays active for targetDuration seconds

//       return () => clearTimeout(timeout); // Cleanup timeout
//     }, interval * 1000); // Activate every interval seconds

//     return () => clearInterval(activationInterval); // Cleanup interval
//   }, [interval, targetDuration, gameEnded]);

//   // Game Over Check
//   useEffect(() => {
//     if (timer === 0 || missedTargets >= 20) {
//       setGameEnded(true);
//     }
//   }, [timer, missedTargets]);

//   // Dynamic Speed and Duration Decay
//   useEffect(() => {
//     const decayInterval = setInterval(() => {
//       setIntervalState((prev) => Math.max(prev - 0.5, 1)); // Decrease interval to minimum 1 sec
//       setTargetDuration((prev) => Math.max(prev - 0.5, 2)); // Decrease duration to minimum 2 sec
//     }, 10000); // Decay every 10 seconds

//     return () => clearInterval(decayInterval); // Cleanup
//   }, []);

//   // Handle Cell Click
//   const handleCellClick = (index) => {
//     if (gameEnded) return; // Ignore clicks if game ended

//     if (index === activeTarget) {
//       setScore((prev) => prev + 1); // Increment score
//       setActiveTarget(null); // Deactivate target
//     } else {
//       setMissedTargets((prev) => prev + 1); // Increment missed targets
//     }
//   };

//   // Render UI
//   return (
//     <div className="game-container-point">
//       <div className="game-board-point">
//         {board.flat().map((_, index) => (
//           <div
//             key={index}
//             className={`board-cell-point ${
//               index === activeTarget ? "active-target-point" : ""
//             }`}
//             onClick={() => handleCellClick(index)}
//           ></div>
//         ))}
//       </div>
//       <div className="scoreboard-point">
//         <h2>Score: {score}</h2>
//         <h2>Missed Targets: {missedTargets}</h2>
//         <h2>Time Left: {timer}s</h2>
//       </div>
//       {gameEnded && <h2 className="game-over-point">Game Over!</h2>}
//     </div>
//   );
// };

// export default AimPointGame;
