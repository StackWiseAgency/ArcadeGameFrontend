


import React, { useState, useEffect, useCallback } from "react";
import "./DiscArcadeModeGame.css";
import * as signalR from "@microsoft/signalr"; // Import SignalR library
 // Import Timer component
import forbiddenCircle from "../assets/forbiddenCircle.png";
import purpleDisc from "../assets/purpledisc.png";
import redDisc from "../assets/reddisc.png";
import orangeDisc from "../assets/orangedisc.png";
import blueDisc from "../assets/bluedisc.png";
import yellowDisc from "../assets/yellowdisc.png";
import greenDisc from "../assets/greendisc.png";
import backgroundImage from "../assets/background-image.png";

const DiscArcadeModeGame = ({ navigateToSelection }) => {
  const [score, setScore] = useState(0);
  // eslint-disable-next-line
  const [misses, setMisses] = useState(0); // Tracks missed throws and updates UI when discs miss targets
  const [gameStarted, setGameStarted] = useState(false);
  const [startButtonDisabled, setStartButtonDisabled] = useState(false);
  
  const [timeRemaining, setTimeRemaining] = useState(20); // Timer starts at 8 minutes (480 seconds) // Timer starts at 5 minutes (300 seconds)
  // eslint-disable-next-line
  const [gameEnded, setGameEnded] = useState(false);

  // Flags for input modes
  const useManualInput = true; // Toggle for manual board clicks
  const useApiInput = false; // Toggle for API/WebSocket input

  const epcMapping = {
    EPC001: { type: "normal", points: 10, color: purpleDisc },
    EPC002: { type: "normal", points: 10, color: redDisc },
    EPC003: { type: "normal", points: 10, color: orangeDisc },
    EPC004: { type: "normal", points: 10, color: blueDisc },
    EPC005: { type: "normal", points: 10, color: yellowDisc },
    EPC101: { type: "bonus", points: 20, color: greenDisc },
    EPC102: { type: "bonus", points: 20, color: blueDisc },
    EPC103: { type: "bonus", points: 20, color: redDisc },
    EPC104: { type: "bonus", points: 20, color: yellowDisc },
    EPC105: { type: "bonus", points: 20, color: orangeDisc },
  };

  const [remainingDiscs, setRemainingDiscs] = useState([
    { epc: "EPC001", ...epcMapping["EPC001"] },
    { epc: "EPC002", ...epcMapping["EPC002"] },
    { epc: "EPC003", ...epcMapping["EPC003"] },
    { epc: "EPC004", ...epcMapping["EPC004"] },
    { epc: "EPC005", ...epcMapping["EPC005"] },
    { epc: "EPC006", ...epcMapping["EPC001"] },
    { epc: "EPC007", ...epcMapping["EPC002"] },
    { epc: "EPC008", ...epcMapping["EPC003"] },
    { epc: "EPC009", ...epcMapping["EPC004"] },
    { epc: "EPC010", ...epcMapping["EPC005"] },
    { epc: "EPC101", ...epcMapping["EPC101"] },
    { epc: "EPC102", ...epcMapping["EPC102"] },
    { epc: "EPC103", ...epcMapping["EPC103"] },
    { epc: "EPC104", ...epcMapping["EPC104"] },
    { epc: "EPC105", ...epcMapping["EPC105"] },
    { epc: "EPC106", ...epcMapping["EPC101"] },
    { epc: "EPC107", ...epcMapping["EPC102"] },
    { epc: "EPC108", ...epcMapping["EPC103"] },
    { epc: "EPC109", ...epcMapping["EPC104"] },
    { epc: "EPC110", ...epcMapping["EPC105"] },
]);

  // Create a 3x3 grid for holes
  const initialGrid = Array(3)
    .fill(null)
    .map(() => Array(3).fill(null));

  // eslint-disable-next-line  
  const [grid, setGrid] = useState(initialGrid);

  const applyGlowEffect = (row, col) => {
    const cell = document.querySelector(
      `.retro-board-row:nth-child(${row + 1}) .retro-board-cell:nth-child(${col + 1})`
    );

    if (cell) {
      cell.style.backgroundColor = "white";
      setTimeout(() => {
        cell.style.backgroundColor = "";
      }, 300);
    }
  };

  const handleApiThrow = useCallback((epc, row, col) => {
    if (!gameStarted) return;
  
    const disc = remainingDiscs.find((d) => d.epc === epc);
    if (!disc) return; // No matching disc available
  
    applyGlowEffect(row, col);
  
    setScore((prev) => prev + disc.points);
    setRemainingDiscs((prev) => prev.filter((d) => d.epc !== epc));
  }, [gameStarted, remainingDiscs]);
  

  const handleManualThrow = useCallback((row, col) => {
    if (!useManualInput || !gameStarted || grid[row][col] !== null) return;
  
    const disc = remainingDiscs[0];
    applyGlowEffect(row, col);
  
    setScore((prev) => prev + disc.points);
    setRemainingDiscs((prev) => prev.slice(1));
  }, [useManualInput, gameStarted, grid, remainingDiscs]);
  

  const handleInputThrow = useCallback((epc, row, col) => {
    if (useApiInput) {
      handleApiThrow(epc, row, col);
    } else if (useManualInput) {
      handleManualThrow(row, col);
    } else {
      console.log("No valid input mode is active.");
    }
  }, [useApiInput, useManualInput, handleApiThrow, handleManualThrow]);

  useEffect(() => {
    if (timeRemaining === 0 || remainingDiscs.length === 0) {
      setGameStarted(false);
      setGameEnded(true);
    }
  }, [timeRemaining, remainingDiscs.length]);
  

  // Gameplay Timer
  useEffect(() => {
    console.log("Timer effect triggered");
    let timer;
    if (gameStarted && timeRemaining > 0) {
      timer = setInterval(() => {
        console.log("Timer tick: ", timeRemaining);
        setTimeRemaining((prev) => prev - 1);
      }, 1000);
    }
  
    return () => {
      console.log("Timer cleared");
      clearInterval(timer);
    };
  }, [gameStarted, timeRemaining]);
  

  // WebSocket/SignalR setup
  useEffect(() => {
    if (!useApiInput || gameStarted) return;

    const connection = new signalR.HubConnectionBuilder()
      .withUrl("https://arcadegamebackendapi20241227164011.azurewebsites.net/gameHub", {
        transport: signalR.HttpTransportType.WebSockets |
                   signalR.HttpTransportType.ServerSentEvents |
                   signalR.HttpTransportType.LongPolling, // Enable fallback transports
      })
      .configureLogging(signalR.LogLevel.Information) // Optional: Logging for debugging
      .withAutomaticReconnect()
      .build();

    connection
      .start()
      .then(() => {
        console.log("SignalR connection established using fallback transports");
        connection.on("ReceiveMove", (epc, row, col) => {
          console.log(`Move received: EPC=${epc}, Row=${row}, Col=${col}`);
          handleInputThrow(epc, row, col);
        });
      })
      .catch((err) => console.error("SignalR connection error:", err));

    return () => {
      connection.stop(); // Clean up the connection on component unmount
    };
  }, [useApiInput, gameStarted, handleInputThrow]);

  // Stop timer and set gameEnded when discs are used up
  useEffect(() => {
    if (remainingDiscs.length === 0 || timeRemaining <= 0) {
      setGameStarted(false);
      setGameEnded(true);
    }
  }, [remainingDiscs, timeRemaining]);

  return (
    <div
      className="arcade-game-container"
     
      style={{ backgroundImage: `url(${backgroundImage})` }}
    >
      <div className="retro-top-section">
        <div className="timer-display">
          <span>Time Remaining: {Math.floor(timeRemaining / 60)}:{(timeRemaining % 60).toString().padStart(2, '0')}</span>
        </div>
        <div className="misses-display">
          <img src={forbiddenCircle} alt="Misses Icon" />
          <span>Misses: {misses}</span>
        </div>
      </div>

      <div className="retro-score-display">
        <h1>{score.toString().padStart(3, "0")}</h1>
      </div>

      <div className="retro-disc-pile">
        <h2>Discs Left</h2>
        <div className="retro-disc-stack">
          <div className="normal-disc-stack">
            <h3>Normal Discs: {remainingDiscs.filter((disc) => disc.type === "normal").length}</h3>
            <div className="stack-container">
              {remainingDiscs.filter((disc) => disc.type === "normal").map((disc, index) => (
                <img
                  key={`normal-disc-${index}`}
                  src={disc.color}
                  alt="Normal Disc"
                  className="disc-icon"
                  style={{
                    left: `${index * 5}px`,
                    zIndex: remainingDiscs.length - index,
                  }}
                />
              ))}
            </div>
          </div>
          <div className="bonus-disc-stack">
            <h3>Bonus Discs: {remainingDiscs.filter((disc) => disc.type === "bonus").length}</h3>
            <div className="stack-container">
              {remainingDiscs.filter((disc) => disc.type === "bonus").map((disc, index) => (
                <img
                  key={`bonus-disc-${index}`}
                  src={disc.color}
                  alt="Bonus Disc"
                  className="disc-icon"
                  style={{
                    left: `${index * 5}px`,
                    zIndex: remainingDiscs.length - index,
                  }}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {!gameStarted && (
        <>
          <button
            className="start-button"
            onClick={() => {
              setGameStarted(true);
              setStartButtonDisabled(true);
            }}
            disabled={startButtonDisabled}
          >
            Start Game
          </button>
          <div className="retro-game-board">
            {grid.map((row, rowIndex) => (
              <div key={rowIndex} className="retro-board-row">
                {row.map((cell, colIndex) => (
                  <div
                    key={colIndex}
                    className={`retro-board-cell ${cell?.type === "B" ? "bonus-cell" : cell?.type === "N" ? "normal-cell" : ""}`}
                    onClick={() => handleManualThrow(rowIndex, colIndex)}
                    style={{ backgroundImage: cell?.color ? `url(${cell.color})` : "none" }}
                  ></div>
                ))}
              </div>
            ))}
          </div>
        </>
      )}

      {gameStarted && (
        <div className="game-board tictactoe-board">
          {grid.map((row, rowIndex) => (
            <div key={rowIndex} className="retro-board-row">
              {row.map((cell, colIndex) => (
                <div
                  key={colIndex}
                  className={`retro-board-cell ${cell?.type === "B" ? "bonus-cell" : cell?.type === "N" ? "normal-cell" : ""}`}
                  onClick={() => handleManualThrow(rowIndex, colIndex)}
                  style={{ backgroundImage: cell?.color ? `url(${cell.color})` : "none" }}
                ></div>
              ))}
            </div>
          ))}
        </div>
      )}

      <button className="back-button" onClick={navigateToSelection}>
        Back to Selection
      </button>
    </div>
  );
};

export default DiscArcadeModeGame;



// import React, { useState, useEffect, useCallback } from "react";
// import "./DiscArcadeModeGame.css";
// import * as signalR from "@microsoft/signalr"; // Import SignalR library

// import forbiddenCircle from "../assets/forbiddenCircle.png";
// import purpleDisc from "../assets/purpledisc.png";
// import redDisc from "../assets/reddisc.png";
// import orangeDisc from "../assets/orangedisc.png";
// import blueDisc from "../assets/bluedisc.png";
// import yellowDisc from "../assets/yellowdisc.png";
// import greenDisc from "../assets/greendisc.png";
// import backgroundImage from "../assets/background-image.png";

// const DiscArcadeModeGame = ({ navigateToSelection }) => {
//   const [score, setScore] = useState(0);
//   const [misses, setMisses] = useState(0); // Tracks missed throws and updates UI when discs miss targets
//   const [gameStarted, setGameStarted] = useState(false);
//   const [firstThrowMade, setFirstThrowMade] = useState(false); // Track if the first throw was made
//   const [timeRemaining, setTimeRemaining] = useState(480); // Timer starts at 8 minutes (480 seconds) // Timer starts at 5 minutes (300 seconds)
//   const [gameEnded, setGameEnded] = useState(false);

//   // Flags for input modes
//   const useManualInput = true; // Toggle for manual board clicks
//   const useApiInput = false; // Toggle for API/WebSocket input

//   const epcMapping = {
//     EPC001: { type: "normal", points: 10, color: purpleDisc },
//     EPC002: { type: "normal", points: 10, color: redDisc },
//     EPC003: { type: "normal", points: 10, color: orangeDisc },
//     EPC004: { type: "normal", points: 10, color: blueDisc },
//     EPC005: { type: "normal", points: 10, color: yellowDisc },
//     EPC101: { type: "bonus", points: 20, color: greenDisc },
//     EPC102: { type: "bonus", points: 20, color: blueDisc },
//     EPC103: { type: "bonus", points: 20, color: redDisc },
//     EPC104: { type: "bonus", points: 20, color: yellowDisc },
//     EPC105: { type: "bonus", points: 20, color: orangeDisc },
//   };

//   const [remainingDiscs, setRemainingDiscs] = useState([
//     { epc: "EPC001", ...epcMapping["EPC001"] },
//     { epc: "EPC002", ...epcMapping["EPC002"] },
//     { epc: "EPC003", ...epcMapping["EPC003"] },
//     { epc: "EPC004", ...epcMapping["EPC004"] },
//     { epc: "EPC005", ...epcMapping["EPC005"] },
//     { epc: "EPC006", ...epcMapping["EPC001"] },
//     { epc: "EPC007", ...epcMapping["EPC002"] },
//     { epc: "EPC008", ...epcMapping["EPC003"] },
//     { epc: "EPC009", ...epcMapping["EPC004"] },
//     { epc: "EPC010", ...epcMapping["EPC005"] },
//     { epc: "EPC101", ...epcMapping["EPC101"] },
//     { epc: "EPC102", ...epcMapping["EPC102"] },
//     { epc: "EPC103", ...epcMapping["EPC103"] },
//     { epc: "EPC104", ...epcMapping["EPC104"] },
//     { epc: "EPC105", ...epcMapping["EPC105"] },
//     { epc: "EPC106", ...epcMapping["EPC101"] },
//     { epc: "EPC107", ...epcMapping["EPC102"] },
//     { epc: "EPC108", ...epcMapping["EPC103"] },
//     { epc: "EPC109", ...epcMapping["EPC104"] },
//     { epc: "EPC110", ...epcMapping["EPC105"] },
// ]);

//   // Create a 3x3 grid for holes
//   const initialGrid = Array(3)
//     .fill(null)
//     .map(() => Array(3).fill(null));

//   const [grid, setGrid] = useState(initialGrid);

//   const handleApiThrow = useCallback((epc, row, col) => {
//     if (grid[row][col] !== null || !gameStarted || remainingDiscs.length === 0) return;

//     const disc = remainingDiscs.find((d) => d.epc === epc);
//     if (!disc) return; // No matching disc available

//     setGrid((prev) => {
//       const newGrid = prev.map((r, rowIndex) =>
//         r.map((cell, colIndex) =>
//           rowIndex === row && colIndex === col ? { color: disc.color, type: disc.type } : cell
//         )
//       );
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = prev.map((r, rowIndex) =>
//           r.map((cell, colIndex) =>
//             rowIndex === row && colIndex === col ? null : cell
//           )
//         );
//         return newGrid;
//       });
//     }, 100);

//     if (!firstThrowMade) {
//       setFirstThrowMade(true);
//       setGameStarted(true);
//     }

//     setScore((prev) => prev + disc.points);
//     setRemainingDiscs((prev) => prev.filter((d) => d.epc !== epc));

//     if (remainingDiscs.length === 1 || timeRemaining <= 0) {
//       setGameStarted(false);
//     }
//   }, [grid, gameStarted, remainingDiscs, firstThrowMade, timeRemaining]);

//   const handleManualThrow = useCallback((row, col) => {
//     if (!useManualInput || grid[row][col] !== null || remainingDiscs.length === 0) return;

//     if (!firstThrowMade) {
//       setFirstThrowMade(true);
//       setGameStarted(true);
//     }

//     const disc = remainingDiscs[0];

//     setGrid((prev) => {
//       const newGrid = prev.map((r, rowIndex) =>
//         r.map((cell, colIndex) =>
//           rowIndex === row && colIndex === col ? { color: disc.color, type: disc.type } : cell
//         )
//       );
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = prev.map((r, rowIndex) =>
//           r.map((cell, colIndex) =>
//             rowIndex === row && colIndex === col ? null : cell
//           )
//         );
//         return newGrid;
//       });
//     }, 1500);

//     setScore((prev) => prev + disc.points);
//     setRemainingDiscs((prev) => prev.slice(1));

//     if (remainingDiscs.length === 1 || timeRemaining <= 0) {
//       setGameStarted(false);
//     }
//   }, [grid, useManualInput, gameStarted, remainingDiscs, firstThrowMade, timeRemaining]);

//   const handleInputThrow = useCallback((epc, row, col) => {
//     if (useApiInput) {
//       handleApiThrow(epc, row, col);
//     } else if (useManualInput) {
//       handleManualThrow(row, col);
//     } else {
//       console.log("No valid input mode is active.");
//     }
//   }, [useApiInput, useManualInput, handleApiThrow, handleManualThrow]);

//   // Gameplay Timer
//   useEffect(() => {
//     let timer;
//     if (gameStarted && timeRemaining > 0) {
//       timer = setInterval(() => {
//         setTimeRemaining((prev) => prev - 1);
//       }, 1000);
//     } else if (timeRemaining <= 0 || remainingDiscs.length === 0) {
//       setGameStarted(false);
//       setGameEnded(true);
//     }
//     return () => clearInterval(timer);
//   }, [gameStarted, timeRemaining, remainingDiscs.length]);

//   // WebSocket/SignalR setup
//   useEffect(() => {
//     if (!useApiInput || gameStarted) return;

//     const connection = new signalR.HubConnectionBuilder()
//       .withUrl("https://arcadegamebackendapi20241227164011.azurewebsites.net/gameHub", {
//         transport: signalR.HttpTransportType.WebSockets |
//                    signalR.HttpTransportType.ServerSentEvents |
//                    signalR.HttpTransportType.LongPolling, // Enable fallback transports
//       })
//       .configureLogging(signalR.LogLevel.Information) // Optional: Logging for debugging
//       .withAutomaticReconnect()
//       .build();

//     connection
//       .start()
//       .then(() => {
//         console.log("SignalR connection established using fallback transports");
//         connection.on("ReceiveMove", (epc, row, col) => {
//           console.log(`Move received: EPC=${epc}, Row=${row}, Col=${col}`);
//           handleInputThrow(epc, row, col);
//         });
//       })
//       .catch((err) => console.error("SignalR connection error:", err));

//     return () => {
//       connection.stop(); // Clean up the connection on component unmount
//     };
//   }, [useApiInput, gameStarted, handleInputThrow]);

//   // Stop timer and set gameEnded when discs are used up
//   useEffect(() => {
//     if (remainingDiscs.length === 0 || timeRemaining <= 0) {
//       setGameStarted(false);
//       setFirstThrowMade(false);
//       setGameEnded(true);
//     }
//   }, [remainingDiscs, timeRemaining]);

//   return (
//     <div
//       className="arcade-game-container"
     
//       style={{ backgroundImage: `url(${backgroundImage})` }}
//     >
//       <div className="retro-top-section">
//         <div className="timer-display">
//           <span>Time Remaining: {Math.floor(timeRemaining / 60)}:{(timeRemaining % 60).toString().padStart(2, '0')}</span>
//         </div>
//         <div className="misses-display">
//           <img src={forbiddenCircle} alt="Misses Icon" />
//           <span>Misses: {misses}</span>
//         </div>
//       </div>

//       <div className="retro-score-display">
//         <h1>{score.toString().padStart(3, "0")}</h1>
//       </div>

//       <div className="retro-disc-pile">
//         <h2>Discs Left</h2>
//         <div className="retro-disc-stack">
//           <div className="normal-disc-stack">
//             <h3>Normal Discs: {remainingDiscs.filter((disc) => disc.type === "normal").length}</h3>
//             <div className="stack-container">
//               {remainingDiscs.filter((disc) => disc.type === "normal").map((disc, index) => (
//                 <img
//                   key={`normal-disc-${index}`}
//                   src={disc.color}
//                   alt="Normal Disc"
//                   className="disc-icon"
//                   style={{
//                     left: `${index * 5}px`,
//                     zIndex: remainingDiscs.length - index,
//                   }}
//                 />
//               ))}
//             </div>
//           </div>
//           <div className="bonus-disc-stack">
//             <h3>Bonus Discs: {remainingDiscs.filter((disc) => disc.type === "bonus").length}</h3>
//             <div className="stack-container">
//               {remainingDiscs.filter((disc) => disc.type === "bonus").map((disc, index) => (
//                 <img
//                   key={`bonus-disc-${index}`}
//                   src={disc.color}
//                   alt="Bonus Disc"
//                   className="disc-icon"
//                   style={{
//                     left: `${index * 5}px`,
//                     zIndex: remainingDiscs.length - index,
//                   }}
//                 />
//               ))}
//             </div>
//           </div>
//         </div>
//       </div>

//       {!gameStarted && (
//         <>
//           <button className='start-button' onClick={() => setGameStarted(true)}>Start Game</button>
//           <div className="retro-game-board">
//             {grid.map((row, rowIndex) => (
//               <div key={rowIndex} className="retro-board-row">
//                 {row.map((cell, colIndex) => (
//                   <div
//                     key={colIndex}
//                     className={`retro-board-cell ${cell?.type === "B" ? "bonus-cell" : cell?.type === "N" ? "normal-cell" : ""}`}
//                     onClick={() => handleManualThrow(rowIndex, colIndex)}
//                     style={{ backgroundImage: cell?.color ? `url(${cell.color})` : "none" }}
//                   ></div>
//                 ))}
//               </div>
//             ))}
//           </div>
//         </>
//       )}

//       {gameStarted && (
//         <div className="game-board tictactoe-board">
//           {grid.map((row, rowIndex) => (
//             <div key={rowIndex} className="retro-board-row">
//               {row.map((cell, colIndex) => (
//                 <div
//                   key={colIndex}
//                   className={`retro-board-cell ${cell?.type === "B" ? "bonus-cell" : cell?.type === "N" ? "normal-cell" : ""}`}
//                   onClick={() => handleManualThrow(rowIndex, colIndex)}
//                   style={{ backgroundImage: cell?.color ? `url(${cell.color})` : "none" }}
//                 ></div>
//               ))}
//             </div>
//           ))}
//         </div>
//       )}

//       <button className="back-button" onClick={navigateToSelection}>
//         Back to Selection
//       </button>
//     </div>
//   );
// };

// export default DiscArcadeModeGame;



// import React, { useState, useEffect, useCallback } from "react";
// import "./DiscArcadeModeGame.css";
// import * as signalR from "@microsoft/signalr"; // Import SignalR library
// import Timer from "./Timer"; // Import Timer component
// import forbiddenCircle from "../assets/forbiddenCircle.png";
// import purpleDisc from "../assets/purpledisc.png";
// import redDisc from "../assets/reddisc.png";
// import orangeDisc from "../assets/orangedisc.png";
// import blueDisc from "../assets/bluedisc.png";
// import yellowDisc from "../assets/yellowdisc.png";
// import greenDisc from "../assets/greendisc.png";
// import backgroundImage from "../assets/background-image.png";

// const DiscArcadeModeGame = ({ navigateToSelection }) => {
//   const [score, setScore] = useState(0);
//   const [misses, setMisses] = useState(0); // Tracks missed throws and updates UI when discs miss targets
//   const [gameStarted, setGameStarted] = useState(false);
//   const [firstThrowMade, setFirstThrowMade] = useState(false); // Track if the first throw was made
//   const [timeRemaining, setTimeRemaining] = useState(300); // Timer starts at 5 minutes (300 seconds)
//   const [gameEnded, setGameEnded] = useState(false);


//   // Flags for input modes
//   const useManualInput = true; // Toggle for manual board clicks
//   const useApiInput = false; // Toggle for API/WebSocket input

//   const epcMapping = {
//     EPC001: { type: "normal", points: 10, color: purpleDisc },
//     EPC002: { type: "normal", points: 10, color: redDisc },
//     EPC003: { type: "normal", points: 10, color: orangeDisc },
//     EPC004: { type: "normal", points: 10, color: blueDisc },
//     EPC005: { type: "normal", points: 10, color: yellowDisc },
//     EPC101: { type: "bonus", points: 20, color: greenDisc },
//     EPC102: { type: "bonus", points: 20, color: blueDisc },
//     EPC103: { type: "bonus", points: 20, color: redDisc },
//     EPC104: { type: "bonus", points: 20, color: yellowDisc },
//     EPC105: { type: "bonus", points: 20, color: orangeDisc },
//   };

//   const [remainingDiscs, setRemainingDiscs] = useState([
//     { epc: "EPC001", ...epcMapping["EPC001"] },
//     { epc: "EPC002", ...epcMapping["EPC002"] },
//     { epc: "EPC003", ...epcMapping["EPC003"] },
//     { epc: "EPC004", ...epcMapping["EPC004"] },
//     { epc: "EPC005", ...epcMapping["EPC005"] },
//     { epc: "EPC006", ...epcMapping["EPC001"] },
//     { epc: "EPC007", ...epcMapping["EPC002"] },
//     { epc: "EPC008", ...epcMapping["EPC003"] },
//     { epc: "EPC009", ...epcMapping["EPC004"] },
//     { epc: "EPC010", ...epcMapping["EPC005"] },
//     { epc: "EPC101", ...epcMapping["EPC101"] },
//     { epc: "EPC102", ...epcMapping["EPC102"] },
//     { epc: "EPC103", ...epcMapping["EPC103"] },
//     { epc: "EPC104", ...epcMapping["EPC104"] },
//     { epc: "EPC105", ...epcMapping["EPC105"] },
//     { epc: "EPC106", ...epcMapping["EPC101"] },
//     { epc: "EPC107", ...epcMapping["EPC102"] },
//     { epc: "EPC108", ...epcMapping["EPC103"] },
//     { epc: "EPC109", ...epcMapping["EPC104"] },
//     { epc: "EPC110", ...epcMapping["EPC105"] },
// ]);

//   // Create a 3x3 grid for holes
//   const initialGrid = Array(3)
//     .fill(null)
//     .map(() => Array(3).fill(null));

//   const [grid, setGrid] = useState(initialGrid);

//   const handleApiThrow = useCallback((epc, row, col) => {
//     if (grid[row][col] !== null || !gameStarted || remainingDiscs.length === 0) return;

//     const disc = remainingDiscs.find((d) => d.epc === epc);
//     if (!disc) return; // No matching disc available

//     setGrid((prev) => {
//       const newGrid = prev.map((r, rowIndex) =>
//         r.map((cell, colIndex) =>
//           rowIndex === row && colIndex === col ? { color: disc.color, type: disc.type } : cell
//         )
//       );
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = prev.map((r, rowIndex) =>
//           r.map((cell, colIndex) =>
//             rowIndex === row && colIndex === col ? null : cell
//           )
//         );
//         return newGrid;
//       });
//     }, 1500);

//     if (!firstThrowMade) {
//       setFirstThrowMade(true);
//       setGameStarted(true);
//     }

//     setScore((prev) => prev + disc.points);
//     setRemainingDiscs((prev) => prev.filter((d) => d.epc !== epc));

//     if (remainingDiscs.length === 1 || timeRemaining <= 0) {
//       setGameStarted(false);
//     }
//   }, [grid, gameStarted, remainingDiscs, firstThrowMade, timeRemaining]);

//   const handleManualThrow = useCallback((row, col) => {
//     if (!useManualInput || grid[row][col] !== null || remainingDiscs.length === 0) return;

//     if (!firstThrowMade) {
//       setFirstThrowMade(true);
//       setGameStarted(true);
//     }

//     const disc = remainingDiscs[0];

//     setGrid((prev) => {
//       const newGrid = prev.map((r, rowIndex) =>
//         r.map((cell, colIndex) =>
//           rowIndex === row && colIndex === col ? { color: disc.color, type: disc.type } : cell
//         )
//       );
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = prev.map((r, rowIndex) =>
//           r.map((cell, colIndex) =>
//             rowIndex === row && colIndex === col ? null : cell
//           )
//         );
//         return newGrid;
//       });
//     }, 1500);

//     setScore((prev) => prev + disc.points);
//     setRemainingDiscs((prev) => prev.slice(1));

//     if (remainingDiscs.length === 1 || timeRemaining <= 0) {
//       setGameStarted(false);
//     }
//   }, [grid, useManualInput, gameStarted, remainingDiscs, firstThrowMade, timeRemaining]);

//   const handleInputThrow = useCallback((epc, row, col) => {
//     if (useApiInput) {
//       handleApiThrow(epc, row, col);
//     } else if (useManualInput) {
//       handleManualThrow(row, col);
//     } else {
//       console.log("No valid input mode is active.");
//     }
//   }, [useApiInput, useManualInput, handleApiThrow, handleManualThrow]);

//   // Gameplay Timer
//   useEffect(() => {
//     let timer;
//     if (gameStarted && timeRemaining > 0) {
//       timer = setInterval(() => {
//         setTimeRemaining((prev) => prev - 1);
//       }, 1000);
//     } else {
//       clearInterval(timer);
//     }

//     if (timeRemaining <= 0) {
//       setGameStarted(false);
//     }

//     return () => clearInterval(timer);
//   }, [gameStarted, timeRemaining]);

//   // WebSocket/SignalR setup
//   useEffect(() => {
//     if (!useApiInput || gameStarted) return;

//     const connection = new signalR.HubConnectionBuilder()
//       .withUrl("https://arcadegamebackendapi20241227164011.azurewebsites.net/gameHub", {
//         transport: signalR.HttpTransportType.WebSockets |
//                    signalR.HttpTransportType.ServerSentEvents |
//                    signalR.HttpTransportType.LongPolling, // Enable fallback transports
//       })
//       .configureLogging(signalR.LogLevel.Information) // Optional: Logging for debugging
//       .withAutomaticReconnect()
//       .build();

//     connection
//       .start()
//       .then(() => {
//         console.log("SignalR connection established using fallback transports");
//         connection.on("ReceiveMove", (epc, row, col) => {
//           console.log(`Move received: EPC=${epc}, Row=${row}, Col=${col}`);
//           handleInputThrow(epc, row, col);
//         });
//       })
//       .catch((err) => console.error("SignalR connection error:", err));

//     return () => {
//       connection.stop(); // Clean up the connection on component unmount
//     };
//   }, [useApiInput, gameStarted, handleInputThrow]);

//   // Stop timer and set gameEnded when discs are used up
//   useEffect(() => {
//     if (remainingDiscs.length === 0 || timeRemaining <= 0) {
//       setGameStarted(false);
//       setFirstThrowMade(false);
//       setGameEnded(true);
//     }
//   }, [remainingDiscs, timeRemaining]);

//   return (
//     <div
//       className="arcade-game-container"
     
//       style={{ backgroundImage: `url(${backgroundImage})` }}
//     >
//       <div className="retro-top-section">
//         <div className="timer-display">
//           <span>Time Remaining: {Math.floor(timeRemaining / 60)}:{(timeRemaining % 60).toString().padStart(2, '0')}</span>
//         </div>
//         <div className="misses-display">
//           <img src={forbiddenCircle} alt="Misses Icon" />
//           <span>Misses: {misses}</span>
//         </div>
//       </div>

//       <div className="retro-score-display">
//         <h1>{score.toString().padStart(3, "0")}</h1>
//       </div>

//       <div className="retro-disc-pile">
//         <h2>Discs Left</h2>
//         <div className="retro-disc-stack">
//           <div className="normal-disc-stack">
//             <h3>Normal Discs: {remainingDiscs.filter((disc) => disc.type === "normal").length}</h3>
//             <div className="stack-container">
//               {remainingDiscs.filter((disc) => disc.type === "normal").map((disc, index) => (
//                 <img
//                   key={`normal-disc-${index}`}
//                   src={disc.color}
//                   alt="Normal Disc"
//                   className="disc-icon"
//                   style={{
//                     left: `${index * 5}px`,
//                     zIndex: remainingDiscs.length - index,
//                   }}
//                 />
//               ))}
//             </div>
//           </div>
//           <div className="bonus-disc-stack">
//             <h3>Bonus Discs: {remainingDiscs.filter((disc) => disc.type === "bonus").length}</h3>
//             <div className="stack-container">
//               {remainingDiscs.filter((disc) => disc.type === "bonus").map((disc, index) => (
//                 <img
//                   key={`bonus-disc-${index}`}
//                   src={disc.color}
//                   alt="Bonus Disc"
//                   className="disc-icon"
//                   style={{
//                     left: `${index * 5}px`,
//                     zIndex: remainingDiscs.length - index,
//                   }}
//                 />
//               ))}
//             </div>
//           </div>
//         </div>
//       </div>

//       {!gameStarted && (
//         <>
//           <Timer
//             userHasThrown={firstThrowMade}
//             onStart={() => setGameStarted(true)}
//           />
//           <div className="retro-game-board">
//             {grid.map((row, rowIndex) => (
//               <div key={rowIndex} className="retro-board-row">
//                 {row.map((cell, colIndex) => (
//                   <div
//                     key={colIndex}
//                     className={`retro-board-cell ${cell?.type === "B" ? "bonus-cell" : cell?.type === "N" ? "normal-cell" : ""}`}
//                     onClick={() => handleManualThrow(rowIndex, colIndex)}
//                     style={{ backgroundImage: cell?.color ? `url(${cell.color})` : "none" }}
//                   ></div>
//                 ))}
//               </div>
//             ))}
//           </div>
//         </>
//       )}

//       {gameStarted && (
//         <div className="game-board tictactoe-board">
//           {grid.map((row, rowIndex) => (
//             <div key={rowIndex} className="retro-board-row">
//               {row.map((cell, colIndex) => (
//                 <div
//                   key={colIndex}
//                   className={`retro-board-cell ${cell?.type === "B" ? "bonus-cell" : cell?.type === "N" ? "normal-cell" : ""}`}
//                   onClick={() => handleManualThrow(rowIndex, colIndex)}
//                   style={{ backgroundImage: cell?.color ? `url(${cell.color})` : "none" }}
//                 ></div>
//               ))}
//             </div>
//           ))}
//         </div>
//       )}

//       <button className="back-button" onClick={navigateToSelection}>
//         Back to Selection
//       </button>
//     </div>
//   );
// };

// export default DiscArcadeModeGame;


// import React, { useState, useEffect, useCallback } from "react";
// import "./DiscArcadeModeGame.css";
// import * as signalR from "@microsoft/signalr"; // Import SignalR library
// import Timer from "./Timer"; // Import Timer component
// import forbiddenCircle from "../assets/forbiddenCircle.png";
// import purpleDisc from "../assets/purpledisc.png";
// import redDisc from "../assets/reddisc.png";
// import orangeDisc from "../assets/orangedisc.png";
// import blueDisc from "../assets/bluedisc.png";
// import yellowDisc from "../assets/yellowdisc.png";
// import greenDisc from "../assets/greendisc.png";
// import backgroundImage from "../assets/background-image.png";

// const DiscArcadeModeGame = ({ navigateToSelection }) => {
//   const [score, setScore] = useState(0);
//   const [misses, setMisses] = useState(0); // Tracks missed throws and updates UI when discs miss targets
//   const [gameStarted, setGameStarted] = useState(false);
//   const [firstThrowMade, setFirstThrowMade] = useState(false); // Track if the first throw was made
//   const [timeElapsed, setTimeElapsed] = useState(0); // Timer for gameplay

//   // Flags for input modes
//   const useManualInput = true; // Toggle for manual board clicks
//   const useApiInput = false; // Toggle for API/WebSocket input

//   const epcMapping = {
//     EPC001: { type: "normal", points: 10, color: purpleDisc },
//     EPC002: { type: "normal", points: 10, color: redDisc },
//     EPC003: { type: "normal", points: 10, color: orangeDisc },
//     EPC004: { type: "normal", points: 10, color: blueDisc },
//     EPC005: { type: "normal", points: 10, color: yellowDisc },
//     EPC101: { type: "bonus", points: 20, color: greenDisc },
//     EPC102: { type: "bonus", points: 20, color: blueDisc },
//     EPC103: { type: "bonus", points: 20, color: redDisc },
//     EPC104: { type: "bonus", points: 20, color: yellowDisc },
//     EPC105: { type: "bonus", points: 20, color: orangeDisc },
//   };

//   const [remainingDiscs, setRemainingDiscs] = useState([
//     { epc: "EPC001", ...epcMapping["EPC001"] },
//     { epc: "EPC002", ...epcMapping["EPC002"] },
//     { epc: "EPC003", ...epcMapping["EPC003"] },
//     { epc: "EPC004", ...epcMapping["EPC004"] },
//     { epc: "EPC005", ...epcMapping["EPC005"] },
//     { epc: "EPC006", ...epcMapping["EPC001"] },
//     { epc: "EPC007", ...epcMapping["EPC002"] },
//     { epc: "EPC008", ...epcMapping["EPC003"] },
//     { epc: "EPC009", ...epcMapping["EPC004"] },
//     { epc: "EPC010", ...epcMapping["EPC005"] },
//     { epc: "EPC101", ...epcMapping["EPC101"] },
//     { epc: "EPC102", ...epcMapping["EPC102"] },
//     { epc: "EPC103", ...epcMapping["EPC103"] },
//     { epc: "EPC104", ...epcMapping["EPC104"] },
//     { epc: "EPC105", ...epcMapping["EPC105"] },
//     { epc: "EPC106", ...epcMapping["EPC101"] },
//     { epc: "EPC107", ...epcMapping["EPC102"] },
//     { epc: "EPC108", ...epcMapping["EPC103"] },
//     { epc: "EPC109", ...epcMapping["EPC104"] },
//     { epc: "EPC110", ...epcMapping["EPC105"] },
// ]);

//   // Create a 3x3 grid for holes
//   const initialGrid = Array(3)
//     .fill(null)
//     .map(() => Array(3).fill(null));

//   const [grid, setGrid] = useState(initialGrid);

//   const handleApiThrow = useCallback((epc, row, col) => {
//     if (grid[row][col] !== null || !gameStarted || remainingDiscs.length === 0) return;

//     const disc = remainingDiscs.find((d) => d.epc === epc);
//     if (!disc) return; // No matching disc available

//     setGrid((prev) => {
//       const newGrid = prev.map((r, rowIndex) =>
//         r.map((cell, colIndex) =>
//           rowIndex === row && colIndex === col ? { color: disc.color, type: disc.type } : cell
//         )
//       );
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = prev.map((r, rowIndex) =>
//           r.map((cell, colIndex) =>
//             rowIndex === row && colIndex === col ? null : cell
//           )
//         );
//         return newGrid;
//       });
//     }, 1500);

//     if (!firstThrowMade) {
//       setFirstThrowMade(true);
//       setGameStarted(true);
//     }

//     setScore((prev) => prev + disc.points);
//     setRemainingDiscs((prev) => prev.filter((d) => d.epc !== epc));

//     if (remainingDiscs.length === 1) {
//       setGameStarted(false);
//       setTimeElapsed((prev) => prev); // Ensure timer stops
//       setMisses((prev) => prev); // Keep track of misses until the end
//     }
//   }, [grid, gameStarted, remainingDiscs, firstThrowMade]);

//   const handleManualThrow = useCallback((row, col) => {
//     if (!useManualInput || grid[row][col] !== null || remainingDiscs.length === 0) return;

//     if (!firstThrowMade) {
//       setFirstThrowMade(true);
//       setGameStarted(true);
//     }

//     const disc = remainingDiscs[0];

//     setGrid((prev) => {
//       const newGrid = prev.map((r, rowIndex) =>
//         r.map((cell, colIndex) =>
//           rowIndex === row && colIndex === col ? { color: disc.color, type: disc.type } : cell
//         )
//       );
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = prev.map((r, rowIndex) =>
//           r.map((cell, colIndex) =>
//             rowIndex === row && colIndex === col ? null : cell
//           )
//         );
//         return newGrid;
//       });
//     }, 1500);

//     setScore((prev) => prev + disc.points);
//     setRemainingDiscs((prev) => prev.slice(1));

//     if (remainingDiscs.length === 1) {
//       setGameStarted(false);
//     }
//   }, [grid, useManualInput, gameStarted, remainingDiscs, firstThrowMade]);

//   const handleInputThrow = useCallback((epc, row, col) => {
//     if (useApiInput) {
//       handleApiThrow(epc, row, col);
//     } else if (useManualInput) {
//       handleManualThrow(row, col);
//     } else {
//       console.log("No valid input mode is active.");
//     }
//   }, [useApiInput, useManualInput, handleApiThrow, handleManualThrow]);

//   // Gameplay Timer
//   useEffect(() => {
//     let timer;
//     if (firstThrowMade && gameStarted) {
//       timer = setInterval(() => {
//         setTimeElapsed((prev) => prev + 1);
//       }, 1000);
//     } else {
//       clearInterval(timer);
//     }
//     return () => clearInterval(timer);
//   }, [firstThrowMade, gameStarted]);

//   // WebSocket/SignalR setup
//   useEffect(() => {
//     if (!useApiInput || gameStarted) return;

//     const connection = new signalR.HubConnectionBuilder()
//       .withUrl("https://arcadegamebackendapi20241227164011.azurewebsites.net/gameHub", {
//         transport: signalR.HttpTransportType.WebSockets |
//                    signalR.HttpTransportType.ServerSentEvents |
//                    signalR.HttpTransportType.LongPolling, // Enable fallback transports
//       })
//       .configureLogging(signalR.LogLevel.Information) // Optional: Logging for debugging
//       .withAutomaticReconnect()
//       .build();

//     connection
//       .start()
//       .then(() => {
//         console.log("SignalR connection established using fallback transports");
//         connection.on("ReceiveMove", (epc, row, col) => {
//           console.log(`Move received: EPC=${epc}, Row=${row}, Col=${col}`);
//           handleInputThrow(epc, row, col);
//         });
//       })
//       .catch((err) => console.error("SignalR connection error:", err));

//     return () => {
//       connection.stop(); // Clean up the connection on component unmount
//     };
//   }, [useApiInput, gameStarted, handleInputThrow]);

//   // Stop timer and set gameEnded when discs are used up
//   useEffect(() => {
//     if (remainingDiscs.length === 0) {
//       setGameStarted(false);
//       setFirstThrowMade(false);
//     }
//   }, [remainingDiscs]);

//   return (
//     <div
//       className="arcade-game-container"
//       style={{ backgroundImage: `url(${backgroundImage})` }}
//     >
//       <div className="retro-top-section">
//         <div className="timer-display">
//           <span>Time: {timeElapsed}s</span>
//         </div>
//         <div className="misses-display">
//           <img src={forbiddenCircle} alt="Misses Icon" />
//           <span>Misses: {misses}</span>
//         </div>
//       </div>

//       <div className="retro-score-display">
//         <h1>{score.toString().padStart(3, "0")}</h1>
//       </div>

//       <div className="retro-disc-pile">
//         <h2>Discs Left</h2>
//         <div className="retro-disc-stack">
//           <div className="normal-disc-stack">
//             <h3>Normal Discs: {remainingDiscs.filter((disc) => disc.type === "normal").length}</h3>
//             <div className="stack-container">
//               {remainingDiscs.filter((disc) => disc.type === "normal").map((disc, index) => (
//                 <img
//                   key={`normal-disc-${index}`}
//                   src={disc.color}
//                   alt="Normal Disc"
//                   className="disc-icon"
//                   style={{
                    
//                     left: `${index * 5}px`,
//                     zIndex: remainingDiscs.length - index, 
//                   }}
//                 />
//               ))}
//             </div>
//           </div>
//           <div className="bonus-disc-stack">
//             <h3>Bonus Discs: {remainingDiscs.filter((disc) => disc.type === "bonus").length}</h3>
//             <div className="stack-container"> 
//               {remainingDiscs.filter((disc) => disc.type === "bonus").map((disc, index) => (
//                 <img
//                   key={`bonus-disc-${index}`}
//                   src={disc.color}
//                   alt="Bonus Disc"
//                   className="disc-icon"
//                   style={{
                   
//                     left: `${index * 5}px`,
//                     zIndex: remainingDiscs.length - index, 
//                   }}
//                 />
//               ))}
//             </div>
//           </div>
//         </div>
//       </div>

//       {!gameStarted && (
//         <>
//           <Timer
//             userHasThrown={firstThrowMade}
//             onStart={() => setGameStarted(true)}
//           />
//           <div className="retro-game-board">
//             {grid.map((row, rowIndex) => (
//               <div key={rowIndex} className="retro-board-row">
//                 {row.map((cell, colIndex) => (
//                   <div
//                     key={colIndex}
//                     className={`retro-board-cell ${cell?.type === "B" ? "bonus-cell" : cell?.type === "N" ? "normal-cell" : ""}`}
//                     onClick={() => handleManualThrow(rowIndex, colIndex)}
//                     style={{ backgroundImage: cell?.color ? `url(${cell.color})` : "none" }}
//                   ></div>
//                 ))}
//               </div>
//             ))}
//           </div>
//         </>
//       )}

//       {gameStarted && (
//         <div className="game-board tictactoe-board">
//           {grid.map((row, rowIndex) => (
//             <div key={rowIndex} className="retro-board-row">
//               {row.map((cell, colIndex) => (
//                 <div
//                   key={colIndex}
//                   className={`retro-board-cell ${cell?.type === "B" ? "bonus-cell" : cell?.type === "N" ? "normal-cell" : ""}`}
//                   onClick={() => handleManualThrow(rowIndex, colIndex)}
//                   style={{ backgroundImage: cell?.color ? `url(${cell.color})` : "none" }}
//                 ></div>
//               ))}
//             </div>
//           ))}
//         </div>
//       )}

//       <button className="back-button" onClick={navigateToSelection}>
//         Back to Selection
//       </button>
//     </div>
//   );
// };

// export default DiscArcadeModeGame;



// import React, { useState, useEffect, useCallback } from "react";
// import "./DiscArcadeModeGame.css";
// import * as signalR from "@microsoft/signalr"; // Import SignalR library
// import Timer from "./Timer"; // Import Timer component
// import forbiddenCircle from "../assets/forbiddenCircle.png";
// import purpleDisc from "../assets/purpledisc.png";
// import redDisc from "../assets/reddisc.png";
// import orangeDisc from "../assets/orangedisc.png";
// import blueDisc from "../assets/bluedisc.png";
// import yellowDisc from "../assets/yellowdisc.png";
// import greenDisc from "../assets/greendisc.png";
// import backgroundImage from "../assets/background-image.png";

// const DiscArcadeModeGame = ({ navigateToSelection }) => {
//   const [score, setScore] = useState(0);
//   const [misses, setMisses] = useState(0); // Tracks missed throws and updates UI when discs miss targets
//   const [gameStarted, setGameStarted] = useState(false);
//   const [firstThrowMade, setFirstThrowMade] = useState(false); // Track if the first throw was made
//   const [timeElapsed, setTimeElapsed] = useState(0); // Timer for gameplay

//   // Flags for input modes
//   const useManualInput = true; // Toggle for manual board clicks
//   const useApiInput = false; // Toggle for API/WebSocket input

//   const epcMapping = {
//     EPC001: { type: "normal", points: 10, color: purpleDisc },
//     EPC002: { type: "normal", points: 10, color: redDisc },
//     EPC003: { type: "normal", points: 10, color: orangeDisc },
//     EPC004: { type: "normal", points: 10, color: blueDisc },
//     EPC005: { type: "normal", points: 10, color: yellowDisc },
//     EPC101: { type: "bonus", points: 20, color: greenDisc },
//     EPC102: { type: "bonus", points: 20, color: blueDisc },
//     EPC103: { type: "bonus", points: 20, color: redDisc },
//     EPC104: { type: "bonus", points: 20, color: yellowDisc },
//     EPC105: { type: "bonus", points: 20, color: orangeDisc },
//   };

//   const [remainingDiscs, setRemainingDiscs] = useState([
//     { epc: "EPC001", ...epcMapping["EPC001"] },
//     { epc: "EPC002", ...epcMapping["EPC002"] },
//     { epc: "EPC003", ...epcMapping["EPC003"] },
//     { epc: "EPC004", ...epcMapping["EPC004"] },
//     { epc: "EPC005", ...epcMapping["EPC005"] },
//     { epc: "EPC006", ...epcMapping["EPC001"] },
//     { epc: "EPC007", ...epcMapping["EPC002"] },
//     { epc: "EPC008", ...epcMapping["EPC003"] },
//     { epc: "EPC009", ...epcMapping["EPC004"] },
//     { epc: "EPC010", ...epcMapping["EPC005"] },
//     { epc: "EPC101", ...epcMapping["EPC101"] },
//     { epc: "EPC102", ...epcMapping["EPC102"] },
//     { epc: "EPC103", ...epcMapping["EPC103"] },
//     { epc: "EPC104", ...epcMapping["EPC104"] },
//     { epc: "EPC105", ...epcMapping["EPC105"] },
//     { epc: "EPC106", ...epcMapping["EPC101"] },
//     { epc: "EPC107", ...epcMapping["EPC102"] },
//     { epc: "EPC108", ...epcMapping["EPC103"] },
//     { epc: "EPC109", ...epcMapping["EPC104"] },
//     { epc: "EPC110", ...epcMapping["EPC105"] },
// ]);

//   // Create a 3x3 grid for holes
//   const initialGrid = Array(3)
//     .fill(null)
//     .map(() => Array(3).fill(null));

//   const [grid, setGrid] = useState(initialGrid);

//   const handleApiThrow = useCallback((epc, row, col) => {
//     if (grid[row][col] !== null || !gameStarted || remainingDiscs.length === 0) return;

//     const disc = remainingDiscs.find((d) => d.epc === epc);
//     if (!disc) return; // No matching disc available

//     setGrid((prev) => {
//       const newGrid = prev.map((r, rowIndex) =>
//         r.map((cell, colIndex) =>
//           rowIndex === row && colIndex === col ? { color: disc.color, type: disc.type } : cell
//         )
//       );
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = prev.map((r, rowIndex) =>
//           r.map((cell, colIndex) =>
//             rowIndex === row && colIndex === col ? null : cell
//           )
//         );
//         return newGrid;
//       });
//     }, 1500);

//     if (!firstThrowMade) {
//       setFirstThrowMade(true);
//       setGameStarted(true);
//     }

//     setScore((prev) => prev + disc.points);
//     setRemainingDiscs((prev) => prev.filter((d) => d.epc !== epc));

//     if (remainingDiscs.length === 1) {
//       setGameStarted(false);
//       setTimeElapsed((prev) => prev); // Ensure timer stops
//       setMisses((prev) => prev); // Keep track of misses until the end
//     }
//   }, [grid, gameStarted, remainingDiscs, firstThrowMade]);

//   const handleManualThrow = useCallback((row, col) => {
//     if (!useManualInput || grid[row][col] !== null || remainingDiscs.length === 0) return;

//     if (!firstThrowMade) {
//       setFirstThrowMade(true);
//       setGameStarted(true);
//     }

//     const disc = remainingDiscs[0];

//     setGrid((prev) => {
//       const newGrid = prev.map((r, rowIndex) =>
//         r.map((cell, colIndex) =>
//           rowIndex === row && colIndex === col ? { color: disc.color, type: disc.type } : cell
//         )
//       );
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = prev.map((r, rowIndex) =>
//           r.map((cell, colIndex) =>
//             rowIndex === row && colIndex === col ? null : cell
//           )
//         );
//         return newGrid;
//       });
//     }, 1500);

//     setScore((prev) => prev + disc.points);
//     setRemainingDiscs((prev) => prev.slice(1));

//     if (remainingDiscs.length === 1) {
//       setGameStarted(false);
//     }
//   }, [grid, useManualInput, gameStarted, remainingDiscs, firstThrowMade]);

//   const handleInputThrow = useCallback((epc, row, col) => {
//     if (useApiInput) {
//       handleApiThrow(epc, row, col);
//     } else if (useManualInput) {
//       handleManualThrow(row, col);
//     } else {
//       console.log("No valid input mode is active.");
//     }
//   }, [useApiInput, useManualInput, handleApiThrow, handleManualThrow]);

//   // Gameplay Timer
//   useEffect(() => {
//     let timer;
//     if (firstThrowMade && gameStarted) {
//       timer = setInterval(() => {
//         setTimeElapsed((prev) => prev + 1);
//       }, 1000);
//     } else {
//       clearInterval(timer);
//     }
//     return () => clearInterval(timer);
//   }, [firstThrowMade, gameStarted]);

//   // WebSocket/SignalR setup
//   useEffect(() => {
//     if (!useApiInput || gameStarted) return;

//     const connection = new signalR.HubConnectionBuilder()
//       .withUrl("https://arcadegamebackendapi20241227164011.azurewebsites.net/gameHub", {
//         transport: signalR.HttpTransportType.WebSockets |
//                    signalR.HttpTransportType.ServerSentEvents |
//                    signalR.HttpTransportType.LongPolling, // Enable fallback transports
//       })
//       .configureLogging(signalR.LogLevel.Information) // Optional: Logging for debugging
//       .withAutomaticReconnect()
//       .build();

//     connection
//       .start()
//       .then(() => {
//         console.log("SignalR connection established using fallback transports");
//         connection.on("ReceiveMove", (epc, row, col) => {
//           console.log(`Move received: EPC=${epc}, Row=${row}, Col=${col}`);
//           handleInputThrow(epc, row, col);
//         });
//       })
//       .catch((err) => console.error("SignalR connection error:", err));

//     return () => {
//       connection.stop(); // Clean up the connection on component unmount
//     };
//   }, [useApiInput, gameStarted, handleInputThrow]);

//   // Stop timer and set gameEnded when discs are used up
//   useEffect(() => {
//     if (remainingDiscs.length === 0) {
//       setGameStarted(false);
//       setFirstThrowMade(false);
//     }
//   }, [remainingDiscs]);

//   return (
//     <div
//       className="arcade-game-container"
//       style={{ backgroundImage: `url(${backgroundImage})` }}
//     >
//       <div className="top-section">
//         <div className="timer-display">
//           <span>Time: {timeElapsed}s</span>
//         </div>
//         <div className="misses-display">
//           <img src={forbiddenCircle} alt="Misses Icon" />
//           <span>Misses: {misses}</span>
//         </div>
//       </div>

//       <div className="retro-score-display">
//         <h1>{score.toString().padStart(3, "0")}</h1>
//       </div>

//       <div className="disc-pile">
//         <h2>Discs Left</h2>
//         <div className="disc-stack">
//           <div className="normal-disc-stack">
//             <h3>Normal Discs: {remainingDiscs.filter((disc) => disc.type === "normal").length}</h3>
//             <div className="stack-container">
//               {remainingDiscs.filter((disc) => disc.type === "normal").map((disc, index) => (
//                 <img
//                   key={`normal-disc-${index}`}
//                   src={disc.color}
//                   alt="Normal Disc"
//                   className="disc-icon"
//                   style={{
                    
//                     left: `${index * 5}px`,
//                     zIndex: remainingDiscs.length - index, 
//                   }}
//                 />
//               ))}
//             </div>
//           </div>
//           <div className="bonus-disc-stack">
//             <h3>Bonus Discs: {remainingDiscs.filter((disc) => disc.type === "bonus").length}</h3>
//             <div className="stack-container"> 
//               {remainingDiscs.filter((disc) => disc.type === "bonus").map((disc, index) => (
//                 <img
//                   key={`bonus-disc-${index}`}
//                   src={disc.color}
//                   alt="Bonus Disc"
//                   className="disc-icon"
//                   style={{
                   
//                     left: `${index * 5}px`,
//                     zIndex: remainingDiscs.length - index, 
//                   }}
//                 />
//               ))}
//             </div>
//           </div>
//         </div>
//       </div>

//       {!gameStarted && (
//         <>
//           <Timer
//             userHasThrown={firstThrowMade}
//             onStart={() => setGameStarted(true)}
//           />
//           <div className="retro-game-board">
//             {grid.map((row, rowIndex) => (
//               <div key={rowIndex} className="board-row">
//                 {row.map((cell, colIndex) => (
//                   <div
//                     key={colIndex}
//                     className={`retro-board-cell ${cell?.type === "B" ? "bonus-cell" : cell?.type === "N" ? "normal-cell" : ""}`}
//                     onClick={() => handleManualThrow(rowIndex, colIndex)}
//                     style={{ backgroundImage: cell?.color ? `url(${cell.color})` : "none" }}
//                   ></div>
//                 ))}
//               </div>
//             ))}
//           </div>
//         </>
//       )}

//       {gameStarted && (
//         <div className="game-board tictactoe-board">
//           {grid.map((row, rowIndex) => (
//             <div key={rowIndex} className="board-row">
//               {row.map((cell, colIndex) => (
//                 <div
//                   key={colIndex}
//                   className={`retro-board-cell ${cell?.type === "B" ? "bonus-cell" : cell?.type === "N" ? "normal-cell" : ""}`}
//                   onClick={() => handleManualThrow(rowIndex, colIndex)}
//                   style={{ backgroundImage: cell?.color ? `url(${cell.color})` : "none" }}
//                 ></div>
//               ))}
//             </div>
//           ))}
//         </div>
//       )}

//       <button className="back-button" onClick={navigateToSelection}>
//         Back to Selection
//       </button>
//     </div>
//   );
// };

// export default DiscArcadeModeGame;



// import React, { useState, useEffect, useCallback } from "react";
// import "./DiscArcadeModeGame.css";
// import * as signalR from "@microsoft/signalr"; // Import SignalR library
// import Timer from "./Timer"; // Import Timer component
// import forbiddenCircle from "../assets/forbiddenCircle.png";
// import purpleDisc from "../assets/purpledisc.png";
// import redDisc from "../assets/reddisc.png";
// import orangeDisc from "../assets/orangedisc.png";
// import blueDisc from "../assets/bluedisc.png";
// import yellowDisc from "../assets/yellowdisc.png";
// import greenDisc from "../assets/greendisc.png";
// import backgroundImage from "../assets/background-image.png";

// const DiscArcadeModeGame = ({ navigateToSelection }) => {
//   const [score, setScore] = useState(0);
//   const [misses, setMisses] = useState(0); // Tracks missed throws and updates UI when discs miss targets
//   const [gameStarted, setGameStarted] = useState(false);
//   const [firstThrowMade, setFirstThrowMade] = useState(false); // Track if the first throw was made
//   const [timeElapsed, setTimeElapsed] = useState(0); // Timer for gameplay

//   // Flags for input modes
//   const useManualInput = true; // Toggle for manual board clicks
//   const useApiInput = false; // Toggle for API/WebSocket input

//   const epcMapping = {
//     EPC001: { type: "normal", points: 10, color: purpleDisc },
//     EPC002: { type: "normal", points: 10, color: redDisc },
//     EPC003: { type: "normal", points: 10, color: orangeDisc },
//     EPC004: { type: "normal", points: 10, color: blueDisc },
//     EPC005: { type: "normal", points: 10, color: yellowDisc },
//     EPC101: { type: "bonus", points: 20, color: greenDisc },
//     EPC102: { type: "bonus", points: 20, color: blueDisc },
//     EPC103: { type: "bonus", points: 20, color: redDisc },
//     EPC104: { type: "bonus", points: 20, color: yellowDisc },
//     EPC105: { type: "bonus", points: 20, color: orangeDisc },
//   };

//   const [remainingDiscs, setRemainingDiscs] = useState([
//     { epc: "EPC001", ...epcMapping["EPC001"] },
//     { epc: "EPC002", ...epcMapping["EPC002"] },
//     { epc: "EPC003", ...epcMapping["EPC003"] },
//     { epc: "EPC004", ...epcMapping["EPC004"] },
//     { epc: "EPC005", ...epcMapping["EPC005"] },
//     { epc: "EPC006", ...epcMapping["EPC001"] },
//     { epc: "EPC007", ...epcMapping["EPC002"] },
//     { epc: "EPC008", ...epcMapping["EPC003"] },
//     { epc: "EPC009", ...epcMapping["EPC004"] },
//     { epc: "EPC010", ...epcMapping["EPC005"] },
//     { epc: "EPC101", ...epcMapping["EPC101"] },
//     { epc: "EPC102", ...epcMapping["EPC102"] },
//     { epc: "EPC103", ...epcMapping["EPC103"] },
//     { epc: "EPC104", ...epcMapping["EPC104"] },
//     { epc: "EPC105", ...epcMapping["EPC105"] },
//     { epc: "EPC106", ...epcMapping["EPC101"] },
//     { epc: "EPC107", ...epcMapping["EPC102"] },
//     { epc: "EPC108", ...epcMapping["EPC103"] },
//     { epc: "EPC109", ...epcMapping["EPC104"] },
//     { epc: "EPC110", ...epcMapping["EPC105"] },
// ]);

//   // Create a 3x3 grid for holes
//   const initialGrid = Array(3)
//     .fill(null)
//     .map(() => Array(3).fill(null));

//   const [grid, setGrid] = useState(initialGrid);

//   const handleApiThrow = useCallback((epc, row, col) => {
//     if (grid[row][col] !== null || !gameStarted || remainingDiscs.length === 0) return;

//     const disc = remainingDiscs.find((d) => d.epc === epc);
//     if (!disc) return; // No matching disc available

//     setGrid((prev) => {
//       const newGrid = prev.map((r, rowIndex) =>
//         r.map((cell, colIndex) =>
//           rowIndex === row && colIndex === col ? { color: disc.color, type: disc.type } : cell
//         )
//       );
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = prev.map((r, rowIndex) =>
//           r.map((cell, colIndex) =>
//             rowIndex === row && colIndex === col ? null : cell
//           )
//         );
//         return newGrid;
//       });
//     }, 1500);

//     if (!firstThrowMade) {
//       setFirstThrowMade(true);
//       setGameStarted(true);
//     }

//     setScore((prev) => prev + disc.points);
//     setRemainingDiscs((prev) => prev.filter((d) => d.epc !== epc));

//     if (remainingDiscs.length === 1) {
//       setGameStarted(false);
//       setTimeElapsed((prev) => prev); // Ensure timer stops
//       setMisses((prev) => prev); // Keep track of misses until the end
//     }
//   }, [grid, gameStarted, remainingDiscs, firstThrowMade]);

//   const handleManualThrow = useCallback((row, col) => {
//     if (!useManualInput || grid[row][col] !== null || remainingDiscs.length === 0) return;

//     if (!firstThrowMade) {
//       setFirstThrowMade(true);
//       setGameStarted(true);
//     }

//     const disc = remainingDiscs[0];

//     setGrid((prev) => {
//       const newGrid = prev.map((r, rowIndex) =>
//         r.map((cell, colIndex) =>
//           rowIndex === row && colIndex === col ? { color: disc.color, type: disc.type } : cell
//         )
//       );
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = prev.map((r, rowIndex) =>
//           r.map((cell, colIndex) =>
//             rowIndex === row && colIndex === col ? null : cell
//           )
//         );
//         return newGrid;
//       });
//     }, 1500);

//     setScore((prev) => prev + disc.points);
//     setRemainingDiscs((prev) => prev.slice(1));

//     if (remainingDiscs.length === 1) {
//       setGameStarted(false);
//     }
//   }, [grid, useManualInput, gameStarted, remainingDiscs, firstThrowMade]);

//   const handleInputThrow = useCallback((epc, row, col) => {
//     if (useApiInput) {
//       handleApiThrow(epc, row, col);
//     } else if (useManualInput) {
//       handleManualThrow(row, col);
//     } else {
//       console.log("No valid input mode is active.");
//     }
//   }, [useApiInput, useManualInput, handleApiThrow, handleManualThrow]);

//   // Gameplay Timer
//   useEffect(() => {
//     let timer;
//     if (firstThrowMade && gameStarted) {
//       timer = setInterval(() => {
//         setTimeElapsed((prev) => prev + 1);
//       }, 1000);
//     } else {
//       clearInterval(timer);
//     }
//     return () => clearInterval(timer);
//   }, [firstThrowMade, gameStarted]);

//   // WebSocket/SignalR setup
//   useEffect(() => {
//     if (!useApiInput || gameStarted) return;

//     const connection = new signalR.HubConnectionBuilder()
//       .withUrl("https://arcadegamebackendapi20241227164011.azurewebsites.net/gameHub", {
//         transport: signalR.HttpTransportType.WebSockets |
//                    signalR.HttpTransportType.ServerSentEvents |
//                    signalR.HttpTransportType.LongPolling, // Enable fallback transports
//       })
//       .configureLogging(signalR.LogLevel.Information) // Optional: Logging for debugging
//       .withAutomaticReconnect()
//       .build();

//     connection
//       .start()
//       .then(() => {
//         console.log("SignalR connection established using fallback transports");
//         connection.on("ReceiveMove", (epc, row, col) => {
//           console.log(`Move received: EPC=${epc}, Row=${row}, Col=${col}`);
//           handleInputThrow(epc, row, col);
//         });
//       })
//       .catch((err) => console.error("SignalR connection error:", err));

//     return () => {
//       connection.stop(); // Clean up the connection on component unmount
//     };
//   }, [useApiInput, gameStarted, handleInputThrow]);

//   // Stop timer and set gameEnded when discs are used up
//   useEffect(() => {
//     if (remainingDiscs.length === 0) {
//       setGameStarted(false);
//       setFirstThrowMade(false);
//     }
//   }, [remainingDiscs]);

//   return (
//     <div
//       className="arcade-game-container"
//       style={{ backgroundImage: `url(${backgroundImage})` }}
//     >
//       <div className="top-section">
//         <div className="timer-display">
//           <span>Time: {timeElapsed}s</span>
//         </div>
//         <div className="misses-display">
//           <img src={forbiddenCircle} alt="Misses Icon" />
//           <span>Misses: {misses}</span>
//         </div>
//       </div>

//       <div className="score-display">
//         <h1>{score.toString().padStart(3, "0")}</h1>
//       </div>

//       <div className="disc-pile">
//         <h2>Discs Left</h2>
//         <div className="disc-stack">
//           <div className="normal-disc-stack">
//             <h3>Normal Discs</h3>
//             {remainingDiscs.filter((disc) => disc.type === "normal").map((disc, index) => (
//               <img
//                 key={`normal-disc-${index}`}
//                 src={disc.color}
//                 alt="Normal Disc"
//                 className="disc-icon"
//                 style={{
//                   top: `${index * 5}px`, /* Adjust spacing */
//                   left: `${index * 5}px`,
//                   zIndex: remainingDiscs.length - index, /* Ensure correct stacking */
//                 }}
//               />
//             ))}
//           </div>
//           <div className="bonus-disc-stack">
//             <h3>Bonus Discs</h3>
//             {remainingDiscs.filter((disc) => disc.type === "bonus").map((disc, index) => (
//               <img
//                 key={`bonus-disc-${index}`}
//                 src={disc.color}
//                 alt="Bonus Disc"
//                 className="disc-icon"
//                 style={{
//                   top: `${index * 5}px`, /* Adjust spacing */
//                   left: `${index * 5}px`,
//                   zIndex: remainingDiscs.length - index, /* Ensure correct stacking */
//                 }}
//               />
//             ))}
//           </div>
//         </div>
//       </div>


//       {!gameStarted && (
//         <>
//           <Timer
//             userHasThrown={firstThrowMade}
//             onStart={() => setGameStarted(true)}
//           />
//           <div className="game-board tictactoe-board">
//             {grid.map((row, rowIndex) => (
//               <div key={rowIndex} className="board-row">
//                 {row.map((cell, colIndex) => (
//                   <div
//                     key={colIndex}
//                     className={`board-cell ${cell?.type === "B" ? "bonus-cell" : cell?.type === "N" ? "normal-cell" : ""}`}
//                     onClick={() => handleManualThrow(rowIndex, colIndex)}
//                     style={{ backgroundImage: cell?.color ? `url(${cell.color})` : "none" }}
//                   ></div>
//                 ))}
//               </div>
//             ))}
//           </div>
//         </>
//       )}

//       {gameStarted && (
//         <div className="game-board tictactoe-board">
//           {grid.map((row, rowIndex) => (
//             <div key={rowIndex} className="board-row">
//               {row.map((cell, colIndex) => (
//                 <div
//                   key={colIndex}
//                   className={`board-cell ${cell?.type === "B" ? "bonus-cell" : cell?.type === "N" ? "normal-cell" : ""}`}
//                   onClick={() => handleManualThrow(rowIndex, colIndex)}
//                   style={{ backgroundImage: cell?.color ? `url(${cell.color})` : "none" }}
//                 ></div>
//               ))}
//             </div>
//           ))}
//         </div>
//       )}

//       <button className="back-button" onClick={navigateToSelection}>
//         Back to Selection
//       </button>
//     </div>
//   );
// };

// export default DiscArcadeModeGame;



// import React, { useState, useEffect, useCallback } from "react";
// import "./DiscArcadeModeGame.css";
// import * as signalR from "@microsoft/signalr"; // Import SignalR library
// import Timer from "./Timer"; // Import Timer component
// import forbiddenCircle from "../assets/forbiddenCircle.png";
// import purpleDisc from "../assets/purpledisc.png";
// import redDisc from "../assets/reddisc.png";
// import orangeDisc from "../assets/orangedisc.png";
// import blueDisc from "../assets/bluedisc.png";
// import yellowDisc from "../assets/yellowdisc.png";
// import greenDisc from "../assets/greendisc.png";
// import backgroundImage from "../assets/background-image.png";

// const DiscArcadeModeGame = ({ navigateToSelection }) => {
//   const [score, setScore] = useState(0);
//   const [misses, setMisses] = useState(0); // Tracks missed throws and updates UI when discs miss targets
//   const [gameStarted, setGameStarted] = useState(false);
//   const [firstThrowMade, setFirstThrowMade] = useState(false); // Track if the first throw was made
//   const [timeElapsed, setTimeElapsed] = useState(0); // Timer for gameplay

//   // Flags for input modes
//   const useManualInput = true; // Toggle for manual board clicks
//   const useApiInput = false; // Toggle for API/WebSocket input

//   const epcMapping = {
//     EPC001: { type: "normal", points: 10, color: purpleDisc },
//     EPC002: { type: "normal", points: 10, color: redDisc },
//     EPC003: { type: "normal", points: 10, color: orangeDisc },
//     EPC004: { type: "normal", points: 10, color: blueDisc },
//     EPC005: { type: "normal", points: 10, color: yellowDisc },
//     EPC101: { type: "bonus", points: 20, color: greenDisc },
//     EPC102: { type: "bonus", points: 20, color: blueDisc },
//     EPC103: { type: "bonus", points: 20, color: redDisc },
//     EPC104: { type: "bonus", points: 20, color: yellowDisc },
//     EPC105: { type: "bonus", points: 20, color: orangeDisc },
//   };

//   const [remainingDiscs, setRemainingDiscs] = useState([
//     { epc: "EPC001", ...epcMapping["EPC001"] },
//     { epc: "EPC002", ...epcMapping["EPC002"] },
//     { epc: "EPC003", ...epcMapping["EPC003"] },
//     { epc: "EPC004", ...epcMapping["EPC004"] },
//     { epc: "EPC005", ...epcMapping["EPC005"] },
//     { epc: "EPC006", ...epcMapping["EPC001"] },
//     { epc: "EPC007", ...epcMapping["EPC002"] },
//     { epc: "EPC008", ...epcMapping["EPC003"] },
//     { epc: "EPC009", ...epcMapping["EPC004"] },
//     { epc: "EPC010", ...epcMapping["EPC005"] },
//     { epc: "EPC101", ...epcMapping["EPC101"] },
//     { epc: "EPC102", ...epcMapping["EPC102"] },
//     { epc: "EPC103", ...epcMapping["EPC103"] },
//     { epc: "EPC104", ...epcMapping["EPC104"] },
//     { epc: "EPC105", ...epcMapping["EPC105"] },
//     { epc: "EPC106", ...epcMapping["EPC101"] },
//     { epc: "EPC107", ...epcMapping["EPC102"] },
//     { epc: "EPC108", ...epcMapping["EPC103"] },
//     { epc: "EPC109", ...epcMapping["EPC104"] },
//     { epc: "EPC110", ...epcMapping["EPC105"] },
// ]);

//   // Create a 3x3 grid for holes
//   const initialGrid = Array(3)
//     .fill(null)
//     .map(() => Array(3).fill(null));

//   const [grid, setGrid] = useState(initialGrid);

//   const handleApiThrow = useCallback((epc, row, col) => {
//     if (grid[row][col] !== null || !gameStarted || remainingDiscs.length === 0) return;

//     const disc = remainingDiscs.find((d) => d.epc === epc);
//     if (!disc) return; // No matching disc available

//     setGrid((prev) => {
//       const newGrid = prev.map((r, rowIndex) =>
//         r.map((cell, colIndex) =>
//           rowIndex === row && colIndex === col ? { color: disc.color, type: disc.type } : cell
//         )
//       );
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = prev.map((r, rowIndex) =>
//           r.map((cell, colIndex) =>
//             rowIndex === row && colIndex === col ? null : cell
//           )
//         );
//         return newGrid;
//       });
//     }, 1500);

//     if (!firstThrowMade) {
//       setFirstThrowMade(true);
//       setGameStarted(true);
//     }

//     setScore((prev) => prev + disc.points);
//     setRemainingDiscs((prev) => prev.filter((d) => d.epc !== epc));

//     if (remainingDiscs.length === 1) {
//       setGameStarted(false);
//       setTimeElapsed((prev) => prev); // Ensure timer stops
//       setMisses((prev) => prev); // Keep track of misses until the end
//     }
//   }, [grid, gameStarted, remainingDiscs, firstThrowMade]);

//   const handleManualThrow = useCallback((row, col) => {
//     if (!useManualInput || grid[row][col] !== null || remainingDiscs.length === 0) return;

//     if (!firstThrowMade) {
//       setFirstThrowMade(true);
//       setGameStarted(true);
//     }

//     const disc = remainingDiscs[0];

//     setGrid((prev) => {
//       const newGrid = prev.map((r, rowIndex) =>
//         r.map((cell, colIndex) =>
//           rowIndex === row && colIndex === col ? { color: disc.color, type: disc.type } : cell
//         )
//       );
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = prev.map((r, rowIndex) =>
//           r.map((cell, colIndex) =>
//             rowIndex === row && colIndex === col ? null : cell
//           )
//         );
//         return newGrid;
//       });
//     }, 1500);

//     setScore((prev) => prev + disc.points);
//     setRemainingDiscs((prev) => prev.slice(1));

//     if (remainingDiscs.length === 1) {
//       setGameStarted(false);
//     }
//   }, [grid, useManualInput, gameStarted, remainingDiscs, firstThrowMade]);

//   const handleInputThrow = useCallback((epc, row, col) => {
//     if (useApiInput) {
//       handleApiThrow(epc, row, col);
//     } else if (useManualInput) {
//       handleManualThrow(row, col);
//     } else {
//       console.log("No valid input mode is active.");
//     }
//   }, [useApiInput, useManualInput, handleApiThrow, handleManualThrow]);

//   // Gameplay Timer
//   useEffect(() => {
//     let timer;
//     if (firstThrowMade && gameStarted) {
//       timer = setInterval(() => {
//         setTimeElapsed((prev) => prev + 1);
//       }, 1000);
//     } else {
//       clearInterval(timer);
//     }
//     return () => clearInterval(timer);
//   }, [firstThrowMade, gameStarted]);

//   // WebSocket/SignalR setup
//   useEffect(() => {
//     if (!useApiInput || gameStarted) return;

//     const connection = new signalR.HubConnectionBuilder()
//       .withUrl("https://arcadegamebackendapi20241227164011.azurewebsites.net/gameHub", {
//         transport: signalR.HttpTransportType.WebSockets |
//                    signalR.HttpTransportType.ServerSentEvents |
//                    signalR.HttpTransportType.LongPolling, // Enable fallback transports
//       })
//       .configureLogging(signalR.LogLevel.Information) // Optional: Logging for debugging
//       .withAutomaticReconnect()
//       .build();

//     connection
//       .start()
//       .then(() => {
//         console.log("SignalR connection established using fallback transports");
//         connection.on("ReceiveMove", (epc, row, col) => {
//           console.log(`Move received: EPC=${epc}, Row=${row}, Col=${col}`);
//           handleInputThrow(epc, row, col);
//         });
//       })
//       .catch((err) => console.error("SignalR connection error:", err));

//     return () => {
//       connection.stop(); // Clean up the connection on component unmount
//     };
//   }, [useApiInput, gameStarted, handleInputThrow]);

//   // Stop timer and set gameEnded when discs are used up
//   useEffect(() => {
//     if (remainingDiscs.length === 0) {
//       setGameStarted(false);
//       setFirstThrowMade(false);
//     }
//   }, [remainingDiscs]);

//   return (
//     <div
//       className="arcade-game-container"
//       style={{ backgroundImage: `url(${backgroundImage})` }}
//     >
//       <div className="top-section">
//         <div className="timer-display">
//           <span>Time: {timeElapsed}s</span>
//         </div>
//         <div className="misses-display">
//           <img src={forbiddenCircle} alt="Misses Icon" />
//           <span>Misses: {misses}</span>
//         </div>
//       </div>

//       <div className="score-display">
//         <h1>{score.toString().padStart(3, "0")}</h1>
//       </div>

//       <div className="disc-pile">
//         <h2>Discs Left</h2>
//         <p>Normal Discs: {remainingDiscs.filter((disc) => disc.type === "normal").length}</p>
//         <p>Bonus Discs: {remainingDiscs.filter((disc) => disc.type === "bonus").length}</p>
//         <div className="disc-stack">
//           {remainingDiscs.map((disc, index) => (
//             <img
//               key={`disc-${index}`}
//               src={disc.color}
//               alt={`${disc.type} Disc`}
//               className={`disc-icon ${disc.type === "normal" ? "normal-disc" : "bonus-disc"}`}
//             />
//           ))}
//         </div>
//       </div>


//       {!gameStarted && (
//         <>
//           <Timer
//             userHasThrown={firstThrowMade}
//             onStart={() => setGameStarted(true)}
//           />
//           <div className="game-board tictactoe-board">
//             {grid.map((row, rowIndex) => (
//               <div key={rowIndex} className="board-row">
//                 {row.map((cell, colIndex) => (
//                   <div
//                     key={colIndex}
//                     className={`board-cell ${cell?.type === "B" ? "bonus-cell" : cell?.type === "N" ? "normal-cell" : ""}`}
//                     onClick={() => handleManualThrow(rowIndex, colIndex)}
//                     style={{ backgroundImage: cell?.color ? `url(${cell.color})` : "none" }}
//                   ></div>
//                 ))}
//               </div>
//             ))}
//           </div>
//         </>
//       )}

//       {gameStarted && (
//         <div className="game-board tictactoe-board">
//           {grid.map((row, rowIndex) => (
//             <div key={rowIndex} className="board-row">
//               {row.map((cell, colIndex) => (
//                 <div
//                   key={colIndex}
//                   className={`board-cell ${cell?.type === "B" ? "bonus-cell" : cell?.type === "N" ? "normal-cell" : ""}`}
//                   onClick={() => handleManualThrow(rowIndex, colIndex)}
//                   style={{ backgroundImage: cell?.color ? `url(${cell.color})` : "none" }}
//                 ></div>
//               ))}
//             </div>
//           ))}
//         </div>
//       )}

//       <button className="back-button" onClick={navigateToSelection}>
//         Back to Selection
//       </button>
//     </div>
//   );
// };

// export default DiscArcadeModeGame;


// import React, { useState, useEffect, useCallback } from "react";
// import "./DiscArcadeModeGame.css";
// import * as signalR from "@microsoft/signalr"; // Import SignalR library
// import Timer from "./Timer"; // Import Timer component
// import forbiddenCircle from "../assets/forbiddenCircle.png";
// import purpleDisc from "../assets/purpledisc.png";
// import redDisc from "../assets/reddisc.png";
// import orangeDisc from "../assets/orangedisc.png";
// import blueDisc from "../assets/bluedisc.png";
// import yellowDisc from "../assets/yellowdisc.png";
// import greenDisc from "../assets/greendisc.png";
// import backgroundImage from "../assets/background-image.png";

// const DiscArcadeModeGame = ({ navigateToSelection }) => {
//   const [score, setScore] = useState(0);
//   const [misses, setMisses] = useState(0); // Tracks missed throws and updates UI when discs miss targets
//   const [gameStarted, setGameStarted] = useState(false);
//   const [firstThrowMade, setFirstThrowMade] = useState(false); // Track if the first throw was made
//   const [timeElapsed, setTimeElapsed] = useState(0); // Timer for gameplay

//   // Flags for input modes
//   const useManualInput = true; // Toggle for manual board clicks
//   const useApiInput = false; // Toggle for API/WebSocket input

//   const epcMapping = {
//     EPC001: { type: "normal", points: 10, color: purpleDisc },
//     EPC002: { type: "normal", points: 10, color: redDisc },
//     EPC003: { type: "normal", points: 10, color: orangeDisc },
//     EPC004: { type: "normal", points: 10, color: blueDisc },
//     EPC005: { type: "normal", points: 10, color: yellowDisc },
//     EPC101: { type: "bonus", points: 20, color: greenDisc },
//     EPC102: { type: "bonus", points: 20, color: blueDisc },
//     EPC103: { type: "bonus", points: 20, color: redDisc },
//     EPC104: { type: "bonus", points: 20, color: yellowDisc },
//     EPC105: { type: "bonus", points: 20, color: orangeDisc },
//   };

//   const [remainingDiscs, setRemainingDiscs] = useState([
//     { epc: "EPC001", ...epcMapping["EPC001"] },
//     { epc: "EPC002", ...epcMapping["EPC002"] },
//     { epc: "EPC003", ...epcMapping["EPC003"] },
//     { epc: "EPC004", ...epcMapping["EPC004"] },
//     { epc: "EPC005", ...epcMapping["EPC005"] },
//     { epc: "EPC006", ...epcMapping["EPC001"] },
//     { epc: "EPC007", ...epcMapping["EPC002"] },
//     { epc: "EPC008", ...epcMapping["EPC003"] },
//     { epc: "EPC009", ...epcMapping["EPC004"] },
//     { epc: "EPC010", ...epcMapping["EPC005"] },
//     { epc: "EPC101", ...epcMapping["EPC101"] },
//     { epc: "EPC102", ...epcMapping["EPC102"] },
//     { epc: "EPC103", ...epcMapping["EPC103"] },
//     { epc: "EPC104", ...epcMapping["EPC104"] },
//     { epc: "EPC105", ...epcMapping["EPC105"] },
//     { epc: "EPC106", ...epcMapping["EPC101"] },
//     { epc: "EPC107", ...epcMapping["EPC102"] },
//     { epc: "EPC108", ...epcMapping["EPC103"] },
//     { epc: "EPC109", ...epcMapping["EPC104"] },
//     { epc: "EPC110", ...epcMapping["EPC105"] },
// ]);

//   // Create a 3x3 grid for holes
//   const initialGrid = Array(3)
//     .fill(null)
//     .map(() => Array(3).fill(null));

//   const [grid, setGrid] = useState(initialGrid);

//   const handleApiThrow = useCallback((epc, row, col) => {
//     if (grid[row][col] !== null || !gameStarted || remainingDiscs.length === 0) return;

//     const disc = remainingDiscs.find((d) => d.epc === epc);
//     if (!disc) return; // No matching disc available

//     setGrid((prev) => {
//       const newGrid = prev.map((r, rowIndex) =>
//         r.map((cell, colIndex) =>
//           rowIndex === row && colIndex === col ? { color: disc.color, type: disc.type } : cell
//         )
//       );
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = prev.map((r, rowIndex) =>
//           r.map((cell, colIndex) =>
//             rowIndex === row && colIndex === col ? null : cell
//           )
//         );
//         return newGrid;
//       });
//     }, 1500);

//     if (!firstThrowMade) {
//       setFirstThrowMade(true);
//       setGameStarted(true);
//     }

//     setScore((prev) => prev + disc.points);
//     setRemainingDiscs((prev) => prev.filter((d) => d.epc !== epc));

//     if (remainingDiscs.length === 1) {
//       setGameStarted(false);
//       setTimeElapsed((prev) => prev); // Ensure timer stops
//       setMisses((prev) => prev); // Keep track of misses until the end
//     }
//   }, [grid, gameStarted, remainingDiscs, firstThrowMade]);

//   const handleManualThrow = useCallback((row, col) => {
//     if (!useManualInput || grid[row][col] !== null || remainingDiscs.length === 0) return;

//     if (!firstThrowMade) {
//       setFirstThrowMade(true);
//       setGameStarted(true);
//     }

//     const disc = remainingDiscs[0];

//     setGrid((prev) => {
//       const newGrid = prev.map((r, rowIndex) =>
//         r.map((cell, colIndex) =>
//           rowIndex === row && colIndex === col ? { color: disc.color, type: disc.type } : cell
//         )
//       );
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = prev.map((r, rowIndex) =>
//           r.map((cell, colIndex) =>
//             rowIndex === row && colIndex === col ? null : cell
//           )
//         );
//         return newGrid;
//       });
//     }, 1500);

//     setScore((prev) => prev + disc.points);
//     setRemainingDiscs((prev) => prev.slice(1));

//     if (remainingDiscs.length === 1) {
//       setGameStarted(false);
//     }
//   }, [grid, useManualInput, gameStarted, remainingDiscs, firstThrowMade]);

//   const handleInputThrow = useCallback((epc, row, col) => {
//     if (useApiInput) {
//       handleApiThrow(epc, row, col);
//     } else if (useManualInput) {
//       handleManualThrow(row, col);
//     } else {
//       console.log("No valid input mode is active.");
//     }
//   }, [useApiInput, useManualInput, handleApiThrow, handleManualThrow]);

//   // Gameplay Timer
//   useEffect(() => {
//     let timer;
//     if (firstThrowMade && gameStarted) {
//       timer = setInterval(() => {
//         setTimeElapsed((prev) => prev + 1);
//       }, 1000);
//     } else {
//       clearInterval(timer);
//     }
//     return () => clearInterval(timer);
//   }, [firstThrowMade, gameStarted]);

//   // WebSocket/SignalR setup
//   useEffect(() => {
//     if (!useApiInput || gameStarted) return;

//     const connection = new signalR.HubConnectionBuilder()
//       .withUrl("https://arcadegamebackendapi20241227164011.azurewebsites.net/gameHub", {
//         transport: signalR.HttpTransportType.WebSockets |
//                    signalR.HttpTransportType.ServerSentEvents |
//                    signalR.HttpTransportType.LongPolling, // Enable fallback transports
//       })
//       .configureLogging(signalR.LogLevel.Information) // Optional: Logging for debugging
//       .withAutomaticReconnect()
//       .build();

//     connection
//       .start()
//       .then(() => {
//         console.log("SignalR connection established using fallback transports");
//         connection.on("ReceiveMove", (epc, row, col) => {
//           console.log(`Move received: EPC=${epc}, Row=${row}, Col=${col}`);
//           handleInputThrow(epc, row, col);
//         });
//       })
//       .catch((err) => console.error("SignalR connection error:", err));

//     return () => {
//       connection.stop(); // Clean up the connection on component unmount
//     };
//   }, [useApiInput, gameStarted, handleInputThrow]);

//   return (
//     <div
//       className="arcade-game-container"
//       style={{ backgroundImage: `url(${backgroundImage})` }}
//     >
//       <div className="top-section">
//         <div className="timer-display">
//           <span>Time: {timeElapsed}s</span>
//         </div>
//         <div className="misses-display">
//           <img src={forbiddenCircle} alt="Misses Icon" />
//           <span>Misses: {misses}</span>
//         </div>
//       </div>

//       <div className="score-display">
//         <h1>{score.toString().padStart(3, "0")}</h1>
//       </div>

//       <div className="disc-pile">
//         <h2>Discs Left</h2>
//         <p>Normal Discs: {remainingDiscs.filter((disc) => disc.type === "normal").length}</p>
//         <p>Bonus Discs: {remainingDiscs.filter((disc) => disc.type === "bonus").length}</p>
//       </div>

//       {!gameStarted && (
//         <>
//           <Timer
//             userHasThrown={firstThrowMade}
//             onStart={() => setGameStarted(true)}
//           />
//           <div className="game-board tictactoe-board">
//             {grid.map((row, rowIndex) => (
//               <div key={rowIndex} className="board-row">
//                 {row.map((cell, colIndex) => (
//                   <div
//                     key={colIndex}
//                     className={`board-cell ${cell?.type === "B" ? "bonus-cell" : cell?.type === "N" ? "normal-cell" : ""}`}
//                     onClick={() => handleManualThrow(rowIndex, colIndex)}
//                     style={{ backgroundImage: cell?.color ? `url(${cell.color})` : "none" }}
//                   ></div>
//                 ))}
//               </div>
//             ))}
//           </div>
//         </>
//       )}

//       {gameStarted && (
//         <div className="game-board tictactoe-board">
//           {grid.map((row, rowIndex) => (
//             <div key={rowIndex} className="board-row">
//               {row.map((cell, colIndex) => (
//                 <div
//                   key={colIndex}
//                   className={`board-cell ${cell?.type === "B" ? "bonus-cell" : cell?.type === "N" ? "normal-cell" : ""}`}
//                   onClick={() => handleManualThrow(rowIndex, colIndex)}
//                   style={{ backgroundImage: cell?.color ? `url(${cell.color})` : "none" }}
//                 ></div>
//               ))}
//             </div>
//           ))}
//         </div>
//       )}

//       <button className="back-button" onClick={navigateToSelection}>
//         Back to Selection
//       </button>
//     </div>
//   );
// };

// export default DiscArcadeModeGame;



// import React, { useState, useEffect, useCallback } from "react";
// import "./DiscArcadeModeGame.css";
// import * as signalR from "@microsoft/signalr"; // Import SignalR library
// import Timer from "./Timer"; // Import Timer component
// import forbiddenCircle from "../assets/forbiddenCircle.png";
// import purpleDisc from "../assets/purpledisc.png";
// import redDisc from "../assets/reddisc.png";
// import orangeDisc from "../assets/orangedisc.png";
// import blueDisc from "../assets/bluedisc.png";
// import yellowDisc from "../assets/yellowdisc.png";
// import greenDisc from "../assets/greendisc.png";
// import backgroundImage from "../assets/background-image.png";

// const DiscArcadeModeGame = ({ navigateToSelection }) => {
//   const [score, setScore] = useState(0);
//   const [misses, setMisses] = useState(0);
//   const [normalDiscs, setNormalDiscs] = useState(10);
//   const [bonusDiscs, setBonusDiscs] = useState(10);
//   const [gameStarted, setGameStarted] = useState(false);
//   const [firstThrowMade, setFirstThrowMade] = useState(false); // Track if the first throw was made
//   const [timeElapsed, setTimeElapsed] = useState(0); // Timer for gameplay

//   // Flags for input modes
//   const useManualInput = true; // Toggle for manual board clicks
//   const useApiInput = true; // Toggle for API/WebSocket input

//   const [normalDiscColors, setNormalDiscColors] = useState([
//     { color: purpleDisc, epc: "EPC001" },
//     { color: redDisc, epc: "EPC002" },
//     { color: orangeDisc, epc: "EPC003" },
//     { color: blueDisc, epc: "EPC004" },
//     { color: yellowDisc, epc: "EPC005" },
//     { color: purpleDisc, epc: "EPC006" },
//     { color: redDisc, epc: "EPC007" },
//     { color: orangeDisc, epc: "EPC008" },
//     { color: blueDisc, epc: "EPC009" },
//     { color: yellowDisc, epc: "EPC010" },
//   ]);

//   const [bonusDiscColors, setBonusDiscColors] = useState([
//     { color: greenDisc, epc: "EPC101" },
//     { color: blueDisc, epc: "EPC102" },
//     { color: redDisc, epc: "EPC103" },
//     { color: yellowDisc, epc: "EPC104" },
//     { color: orangeDisc, epc: "EPC105" },
//     { color: greenDisc, epc: "EPC106" },
//     { color: blueDisc, epc: "EPC107" },
//     { color: redDisc, epc: "EPC108" },
//     { color: yellowDisc, epc: "EPC109" },
//     { color: orangeDisc, epc: "EPC110" },
//   ]);

//   // Create a 3x3 grid for holes
//   const initialGrid = Array(3)
//     .fill(null)
//     .map(() => Array(3).fill(null));

//   const [grid, setGrid] = useState(initialGrid);

//   const handleApiThrow = useCallback((epc, row, col) => {
//     if (grid[row][col] !== null || !gameStarted) return;

//     const isBonus = bonusDiscColors.some((disc) => disc.epc === epc);
//     const points = isBonus ? 20 : 10;

//     setGrid((prev) => {
//       const newGrid = prev.map((r, rowIndex) =>
//         r.map((cell, colIndex) =>
//           rowIndex === row && colIndex === col ? { epc, type: isBonus ? "B" : "N" } : cell
//         )
//       );
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = prev.map((r, rowIndex) =>
//           r.map((cell, colIndex) =>
//             rowIndex === row && colIndex === col ? null : cell
//           )
//         );
//         return newGrid;
//       });
//     }, 1500);

//     if (isBonus) {
//       if (bonusDiscs > 0) {
//         setScore((prev) => prev + points);
//         setBonusDiscs((prev) => prev - 1);
//         setBonusDiscColors((prevColors) => prevColors.filter((disc) => disc.epc !== epc));
//       } else {
//         setMisses((prev) => prev + 1);
//       }
//     } else {
//       if (normalDiscs > 0) {
//         setScore((prev) => prev + points);
//         setNormalDiscs((prev) => prev - 1);
//         setNormalDiscColors((prevColors) => prevColors.filter((disc) => disc.epc !== epc));
//       } else {
//         setMisses((prev) => prev + 1);
//       }
//     }

//     if (normalDiscs === 0 && bonusDiscs === 0) {
//       setGameStarted(false);
//     }
//   }, [bonusDiscColors, normalDiscs, bonusDiscs, grid, gameStarted]);

//   const handleManualThrow = useCallback((row, col) => {
//     if (!useManualInput || grid[row][col] !== null) return;

//     if (!gameStarted) {
//       setGameStarted(true);
//       setFirstThrowMade(true);
//     }

//     const isBonus = normalDiscs === 0;
//     const points = isBonus ? 20 : 10;

//     setGrid((prev) => {
//       const newGrid = prev.map((r, rowIndex) =>
//         r.map((cell, colIndex) =>
//           rowIndex === row && colIndex === col ? { type: isBonus ? "B" : "N" } : cell
//         )
//       );
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = prev.map((r, rowIndex) =>
//           r.map((cell, colIndex) =>
//             rowIndex === row && colIndex === col ? null : cell
//           )
//         );
//         return newGrid;
//       });
//     }, 1500);

//     if (isBonus) {
//       if (bonusDiscs > 0) {
//         setScore((prev) => prev + points);
//         setBonusDiscs((prev) => prev - 1);
//       } else {
//         setMisses((prev) => prev + 1);
//       }
//     } else {
//       if (normalDiscs > 0) {
//         setScore((prev) => prev + points);
//         setNormalDiscs((prev) => prev - 1);
//       } else {
//         setMisses((prev) => prev + 1);
//       }
//     }

//     if (normalDiscs === 0 && bonusDiscs === 0) {
//       setGameStarted(false);
//     }
//   }, [normalDiscs, bonusDiscs, grid, useManualInput, gameStarted]);

//   const handleInputThrow = useCallback((epc, row, col) => {
//     if (useApiInput) {
//       handleApiThrow(epc, row, col);
//     } else if (useManualInput) {
//       handleManualThrow(row, col);
//     } else {
//       console.log("No valid input mode is active.");
//     }
//   }, [useApiInput, useManualInput, handleApiThrow, handleManualThrow]);

//   // Gameplay Timer
//   useEffect(() => {
//     let timer;
//     if (gameStarted) {
//       timer = setInterval(() => {
//         setTimeElapsed((prev) => prev + 1);
//       }, 1000);
//     } else {
//       clearInterval(timer);
//     }
//     return () => clearInterval(timer);
//   }, [gameStarted]);

//   // WebSocket/SignalR setup
//   useEffect(() => {
//     if (!useApiInput || gameStarted) return;

//     const connection = new signalR.HubConnectionBuilder()
//       .withUrl("https://arcadegamebackendapi20241227164011.azurewebsites.net/gameHub", {
//         transport: signalR.HttpTransportType.WebSockets |
//                    signalR.HttpTransportType.ServerSentEvents |
//                    signalR.HttpTransportType.LongPolling, // Enable fallback transports
//       })
//       .configureLogging(signalR.LogLevel.Information) // Optional: Logging for debugging
//       .withAutomaticReconnect()
//       .build();

//     connection
//       .start()
//       .then(() => {
//         console.log("SignalR connection established using fallback transports");
//         connection.on("ReceiveMove", (epc, row, col) => {
//           console.log(`Move received: EPC=${epc}, Row=${row}, Col=${col}`);
//           handleInputThrow(epc, row, col);
//         });
//       })
//       .catch((err) => console.error("SignalR connection error:", err));

//     return () => {
//       connection.stop(); // Clean up the connection on component unmount
//     };
//   }, [useApiInput, gameStarted, handleInputThrow]);

//   return (
//     <div
//       className="arcade-game-container"
//       style={{ backgroundImage: `url(${backgroundImage})` }}
//     >
//       <div className="top-section">
//         <div className="timer-display">
//           <span>Time: {timeElapsed}s</span>
//         </div>
//         <div className="misses-display">
//           <img src={forbiddenCircle} alt="Misses Icon" />
//           <span>Misses: {misses}</span>
//         </div>
//       </div>

//       <div className="score-display">
//         <h1>{score.toString().padStart(3, "0")}</h1>
//       </div>

//       {!gameStarted && (
//         <>
//           <Timer
//             userHasThrown={firstThrowMade}
//             onStart={() => setGameStarted(true)}
//           />
//           <div className="game-board tictactoe-board">
//             {grid.map((row, rowIndex) => (
//               <div key={rowIndex} className="board-row">
//                 {row.map((cell, colIndex) => (
//                   <div
//                     key={colIndex}
//                     className={`board-cell ${cell?.type === "B" ? "bonus-cell" : cell?.type === "N" ? "normal-cell" : ""}`}
//                     onClick={() => handleManualThrow(rowIndex, colIndex)}
//                   ></div>
//                 ))}
//               </div>
//             ))}
//           </div>
//         </>
//       )}

//       {gameStarted && (
//         <div className="game-board tictactoe-board">
//           {grid.map((row, rowIndex) => (
//             <div key={rowIndex} className="board-row">
//               {row.map((cell, colIndex) => (
//                 <div
//                   key={colIndex}
//                   className={`board-cell ${cell?.type === "B" ? "bonus-cell" : cell?.type === "N" ? "normal-cell" : ""}`}
//                   onClick={() => handleManualThrow(rowIndex, colIndex)}
//                 ></div>
//               ))}
//             </div>
//           ))}
//         </div>
//       )}

//       <button className="back-button" onClick={navigateToSelection}>
//         Back to Selection
//       </button>
//     </div>
//   );
// };

// export default DiscArcadeModeGame;


// import React, { useState, useEffect, useCallback } from "react";
// import "./DiscArcadeModeGame.css";
// import timerIcon from "../assets/timer.png";
// import forbiddenCircle from "../assets/forbiddenCircle.png";
// import purpleDisc from "../assets/purpledisc.png";
// import redDisc from "../assets/reddisc.png";
// import orangeDisc from "../assets/orangedisc.png";
// import blueDisc from "../assets/bluedisc.png";
// import yellowDisc from "../assets/yellowdisc.png";
// import greenDisc from "../assets/greendisc.png";
// import backgroundImage from "../assets/background-image.png";

// const DiscArcadeModeGame = ({ navigateToSelection }) => {
//   const [timeLeft, setTimeLeft] = useState(0); // Increment timer
//   const [score, setScore] = useState(0);
//   const [misses, setMisses] = useState(0);
//   const [normalDiscs, setNormalDiscs] = useState(10);
//   const [bonusDiscs, setBonusDiscs] = useState(10);
//   const [gameStarted, setGameStarted] = useState(false);
//   const [readyToStart, setReadyToStart] = useState(false); // Control when to start the game
//   const [startCountdown, setStartCountdown] = useState(null); // 3-second countdown
//   const [gameEnded, setGameEnded] = useState(false);
//   const [firstThrowMade, setFirstThrowMade] = useState(false); // Track if the first throw was made
//   const [idleTimeout, setIdleTimeout] = useState(null); // Track idle timeout

//   // Flags for input modes
//   const useSimulatedInput = false; // Toggle for simulated data
//   const useManualInput = true; // Toggle for manual board clicks

//   const [normalDiscColors, setNormalDiscColors] = useState([
//     purpleDisc,
//     redDisc,
//     orangeDisc,
//     blueDisc,
//     yellowDisc,
//     purpleDisc,
//     redDisc,
//     orangeDisc,
//     blueDisc,
//     yellowDisc,
//   ]);

//   const [bonusDiscColors, setBonusDiscColors] = useState([
//     greenDisc,
//     blueDisc,
//     redDisc,
//     yellowDisc,
//     orangeDisc,
//     greenDisc,
//     blueDisc,
//     redDisc,
//     yellowDisc,
//     orangeDisc,
//   ]);

//   const discSize = {
//     normal: "50px", // Large disc size
//     bonus: "30px", // Small disc size
//   };

//   // Create a 3x3 grid for holes
//   const initialGrid = Array(3)
//     .fill(null)
//     .map(() => Array(3).fill(null));

//   const [grid, setGrid] = useState(initialGrid);

//   const startCountdownTimer = useCallback((duration, onComplete) => {
//     setStartCountdown(duration);
//     const countdownInterval = setInterval(() => {
//       setStartCountdown((prev) => {
//         if (prev === 1) {
//           clearInterval(countdownInterval);
//           onComplete(); // Callback when countdown ends
//           return null;
//         }
//         return prev - 1;
//       });
//     }, 1000);
//     return countdownInterval; // Return interval for cleanup
//   }, []);

//   // Initial countdown logic
//   useEffect(() => {
//     if (readyToStart && !gameStarted && startCountdown === null) {
//       startCountdownTimer(3, () => setGameStarted(true));
//     }
//   }, [readyToStart, gameStarted, startCountdown, startCountdownTimer]);

//   // Idle detection logic
//   useEffect(() => {
//     if (!firstThrowMade && !gameEnded) {
//       const timeout = setTimeout(() => {
//         const countdownInterval = startCountdownTimer(3, () => {
//           setMisses((prevMisses) => prevMisses + 1); // Increment misses
//         });
//         setIdleTimeout(countdownInterval);
//       }, 5000);

//       return () => {
//         clearTimeout(timeout); // Cleanup idle timeout
//         if (idleTimeout) clearInterval(idleTimeout);
//       };
//     }
//   }, [firstThrowMade, gameEnded, idleTimeout, startCountdownTimer]);

//   // Start Game on First Throw or Countdown
//   const handleFirstThrow = useCallback(() => {
//     if (!gameStarted) {
//       setGameStarted(true);
//       setTimeLeft(0); // Reset timer
//     }
//     setFirstThrowMade(true);
//     if (idleTimeout) clearInterval(idleTimeout); // Clear idle countdown if throwing
//   }, [gameStarted, idleTimeout]);

//   // Handle manual input (simulated click)
//   const handleManualThrow = useCallback((row, col) => {
//     if ((useManualInput === false && useSimulatedInput === false) || gameEnded || grid[row][col] !== null) {
//       return;
//     }

//     handleFirstThrow(); // Start the game if it's the first throw

//     const isBonus = Math.random() > 0.5; // Randomly determine disc type
//     const points = isBonus ? 20 : 10;

//     // Highlight the grid cell temporarily
//     setGrid((prev) => {
//       const newGrid = [...prev];
//       newGrid[row][col] = isBonus ? "B" : "N";
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = [...prev];
//         newGrid[row][col] = null; // Reset cell after 1.5 seconds
//         return newGrid;
//       });
//     }, 1500);

//     if (isBonus) {
//       if (bonusDiscs > 0) {
//         setScore((prev) => prev + points);
//         setBonusDiscs((prev) => prev - 1);
//         setBonusDiscColors((prevColors) => prevColors.slice(0, -1)); // Remove one bonus disc color
//       } else {
//         setMisses((prev) => prev + 1); // Increment misses if no bonus discs left
//       }
//     } else {
//       if (normalDiscs > 0) {
//         setScore((prev) => prev + points);
//         setNormalDiscs((prev) => prev - 1);
//         setNormalDiscColors((prevColors) => prevColors.slice(0, -1)); // Remove one normal disc color
//       } else {
//         setMisses((prev) => prev + 1); // Increment misses if no normal discs left
//       }
//     }

//     if (normalDiscs === 0 && bonusDiscs === 0) {
//       setGameEnded(true);
//     }
//   }, [useManualInput, useSimulatedInput, gameEnded, grid, handleFirstThrow, bonusDiscs, normalDiscs]);

//   // Simulated Input Logic
//   useEffect(() => {
//     if (useSimulatedInput && !gameEnded) {
//       const simulateThrows = setInterval(() => {
//         if (normalDiscs <= 0 && bonusDiscs <= 0) {
//           clearInterval(simulateThrows); // Stop simulation if no discs are left
//           return;
//         }
//         const row = Math.floor(Math.random() * 3);
//         const col = Math.floor(Math.random() * 3);
//         handleManualThrow(row, col);
//       }, 1000);

//       return () => clearInterval(simulateThrows);
//     }
//   }, [normalDiscs, bonusDiscs, gameEnded, useSimulatedInput, handleManualThrow]);

//   // End Game Logic
//   const handleGameEnd = useCallback(() => {
//     setGameEnded(true);

//     // Simulated disc return check
//     const discsReturned = normalDiscs === 0 && bonusDiscs === 0; // Simulated check
//     if (discsReturned) {
//       alert("All discs returned. Game Over!");
//     } else {
//       alert("Please return all discs to the holding bin.");
//     }
//   }, [normalDiscs, bonusDiscs]);

//   useEffect(() => {
//     if (normalDiscs === 0 && bonusDiscs === 0) {
//       handleGameEnd();
//     }
//   }, [normalDiscs, bonusDiscs, handleGameEnd]);

//   return (
//     <div
//       className="arcade-game-container"
//       style={{ backgroundImage: `url(${backgroundImage})` }}
//     >
//       {!readyToStart && (
//         <button className="start-game-button" onClick={() => setReadyToStart(true)}>
//           Start Game
//         </button>
//       )}

//       {readyToStart && !gameStarted && startCountdown !== null && (
//         <div className="countdown-display">
//           <h2>Game starts in: {startCountdown}</h2>
//         </div>
//       )}

//       {gameEnded && (
//         <div className="summary-screen">
//           <h2>Game Over!</h2>
//           <p>Score: {score}</p>
//           <p>Misses: {misses}</p>
//           <button onClick={navigateToSelection}>Back to Selection</button>
//         </div>
//       )}

//       <div className="top-section">
//         <div className="time-left">
//           <img src={timerIcon} alt="Timer" />
//           <span>{`${Math.floor(timeLeft / 60)}:${(timeLeft % 60)
//             .toString()
//             .padStart(2, "0")}`}</span>
//         </div>
//         <div className="misses">
//           <img src={forbiddenCircle} alt="Misses" />
//           <span>{misses}</span>
//         </div>
//       </div>

//       <div className="score-display">
//         <h1>{score.toString().padStart(3, "0")}</h1>
//       </div>

//       <div className="game-board tictactoe-board">
//         {grid.map((row, rowIndex) => (
//           <div key={rowIndex} className="board-row">
//             {row.map((cell, colIndex) => (
//               <div
//                 key={colIndex}
//                 className={`board-cell ${cell === "B" ? "bonus-cell" : cell === "N" ? "normal-cell" : ""}`}
//                 onClick={() => handleManualThrow(rowIndex, colIndex)}
//               ></div>
//             ))}
//           </div>
//         ))}
//       </div>

//       <div className="bottom-section">
//         <div className="discs-left">
//           <h3>DISCS LEFT: {normalDiscs}</h3>
//           <div className="disc-info">
//             {normalDiscColors.slice(0, normalDiscs).map((disc, index) => (
//               <img
//                 key={index}
//                 src={disc}
//                 alt={`Normal Disc ${index}`}
//                 style={{ width: discSize.normal }}
//               />
//             ))}
//           </div>
//         </div>

//         <div className="bonus-discs-left">
//           <h3>BONUS DISCS LEFT: {bonusDiscs}</h3>
//           <div className="disc-info">
//             {bonusDiscColors.slice(0, bonusDiscs).map((disc, index) => (
//               <img
//                 key={index}
//                 src={disc}
//                 alt={`Bonus Disc ${index}`}
//                 style={{ width: discSize.bonus }}
//               />
//             ))}
//           </div>
//         </div>
//       </div>

//       <button className="back-button" onClick={navigateToSelection}>
//         Back to Selection
//       </button>
//     </div>
//   );
// };

// export default DiscArcadeModeGame;




// import React, { useState, useEffect } from "react";
// import "./DiscArcadeModeGame.css";
// import timerIcon from "../assets/timer.png";
// import forbiddenCircle from "../assets/forbiddenCircle.png";
// import purpleDisc from "../assets/purpledisc.png";
// import redDisc from "../assets/reddisc.png";
// import orangeDisc from "../assets/orangedisc.png";
// import blueDisc from "../assets/bluedisc.png";
// import yellowDisc from "../assets/yellowdisc.png";
// import greenDisc from "../assets/greendisc.png";
// import backgroundImage from "../assets/background-image.png";

// const DiscArcadeModeGame = ({ navigateToSelection }) => {
//   const [timeLeft, setTimeLeft] = useState(0); // Increment timer
//   const [score, setScore] = useState(0);
//   const [misses, setMisses] = useState(0);
//   const [normalDiscs, setNormalDiscs] = useState(10);
//   const [bonusDiscs, setBonusDiscs] = useState(10);
//   const [gameStarted, setGameStarted] = useState(false);
//   const [readyToStart, setReadyToStart] = useState(false); // Control when to start the game
//   const [startCountdown, setStartCountdown] = useState(null); // 3-second countdown
//   const [gameEnded, setGameEnded] = useState(false);
//   const [firstThrowMade, setFirstThrowMade] = useState(false); // Track if the first throw was made
//   const [idleTimeout, setIdleTimeout] = useState(null); // Track idle timeout

//   // Flags for input modes
//   const useSimulatedInput = false; // Toggle for simulated data
//   const useManualInput = true; // Toggle for manual board clicks

//   const [normalDiscColors, setNormalDiscColors] = useState([
//     purpleDisc,
//     redDisc,
//     orangeDisc,
//     blueDisc,
//     yellowDisc,
//     purpleDisc,
//     redDisc,
//     orangeDisc,
//     blueDisc,
//     yellowDisc,
//   ]);

//   const [bonusDiscColors, setBonusDiscColors] = useState([
//     greenDisc,
//     blueDisc,
//     redDisc,
//     yellowDisc,
//     orangeDisc,
//     greenDisc,
//     blueDisc,
//     redDisc,
//     yellowDisc,
//     orangeDisc,
//   ]);

//   const discSize = {
//     normal: "50px", // Large disc size
//     bonus: "30px", // Small disc size
//   };

//   // Create a 3x3 grid for holes
//   const initialGrid = Array(3)
//     .fill(null)
//     .map(() => Array(3).fill(null));

//   const [grid, setGrid] = useState(initialGrid);

//   // Initial countdown logic
//   useEffect(() => {
//     if (readyToStart && !gameStarted && startCountdown === null) {
//       setStartCountdown(3); // Start the countdown when ready

//       const countdownInterval = setInterval(() => {
//         setStartCountdown((prev) => {
//           if (prev === 1) {
//             clearInterval(countdownInterval);
//             setGameStarted(true); // Start the game
//             setStartCountdown(null); // Reset countdown
//             return null;
//           }
//           return prev - 1;
//         });
//       }, 1000);

//       return () => clearInterval(countdownInterval); // Cleanup interval
//     }
//   }, [readyToStart, gameStarted, startCountdown]);

//   // Idle detection logic
//   useEffect(() => {
//     if (!firstThrowMade && !gameEnded) {
//       const timeout = setTimeout(() => {
//         setStartCountdown(3); // Start 3-second countdown
//         const countdownInterval = setInterval(() => {
//           setStartCountdown((prev) => {
//             if (prev === 1) {
//               clearInterval(countdownInterval);
//               setMisses((prevMisses) => prevMisses + 1); // Increment misses
//               setStartCountdown(null); // Clear countdown
//               return null;
//             }
//             return prev - 1;
//           });
//         }, 1000);

//         setIdleTimeout(countdownInterval);
//       }, 5000);

//       return () => {
//         clearTimeout(timeout); // Cleanup idle timeout
//         if (idleTimeout) clearInterval(idleTimeout);
//       };
//     }
//   }, [firstThrowMade, gameEnded, idleTimeout]);

//   // Start Game on First Throw or Countdown
//   const handleFirstThrow = () => {
//     if (!gameStarted) {
//       setGameStarted(true);
//       setTimeLeft(0); // Reset timer
//     }
//     setFirstThrowMade(true);
//     if (idleTimeout) clearInterval(idleTimeout); // Clear idle countdown if throwing
//   };

//   // Handle manual input (simulated click)
//   const handleManualThrow = (row, col) => {
//     if ((useManualInput === false && useSimulatedInput === false) || gameEnded || grid[row][col] !== null) {
//       return;
//     }

//     handleFirstThrow(); // Start the game if it's the first throw

//     const isBonus = Math.random() > 0.5; // Randomly determine disc type
//     const points = isBonus ? 20 : 10;

//     // Highlight the grid cell temporarily
//     setGrid((prev) => {
//       const newGrid = [...prev];
//       newGrid[row][col] = isBonus ? "B" : "N";
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = [...prev];
//         newGrid[row][col] = null; // Reset cell after 1.5 seconds
//         return newGrid;
//       });
//     }, 1500);

//     if (isBonus) {
//       if (bonusDiscs > 0) {
//         setScore((prev) => prev + points);
//         setBonusDiscs((prev) => prev - 1);
//         setBonusDiscColors((prevColors) => prevColors.slice(0, -1)); // Remove one bonus disc color
//       } else {
//         setMisses((prev) => prev + 1); // Increment misses if no bonus discs left
//       }
//     } else {
//       if (normalDiscs > 0) {
//         setScore((prev) => prev + points);
//         setNormalDiscs((prev) => prev - 1);
//         setNormalDiscColors((prevColors) => prevColors.slice(0, -1)); // Remove one normal disc color
//       } else {
//         setMisses((prev) => prev + 1); // Increment misses if no normal discs left
//       }
//     }

//     if (normalDiscs === 0 && bonusDiscs === 0) {
//       setGameEnded(true);
//     }
//   };

//   // Simulated Input Logic
//   useEffect(() => {
//     if (useSimulatedInput && !gameEnded) {
//       const simulateThrows = setInterval(() => {
//         if (normalDiscs <= 0 && bonusDiscs <= 0) {
//           clearInterval(simulateThrows); // Stop simulation if no discs are left
//           return;
//         }
//         const row = Math.floor(Math.random() * 3);
//         const col = Math.floor(Math.random() * 3);
//         handleManualThrow(row, col);
//       }, 1000);

//       return () => clearInterval(simulateThrows);
//     }
//     // eslint-disable-next-line 
//   }, [normalDiscs, bonusDiscs, gameEnded, useSimulatedInput]);

//   // End Game Logic
//   const handleGameEnd = () => {
//     setGameEnded(true);

//     // Simulated disc return check
//     const discsReturned = normalDiscs === 0 && bonusDiscs === 0; // Simulated check
//     if (discsReturned) {
//       alert("All discs returned. Game Over!");
//     } else {
//       alert("Please return all discs to the holding bin.");
//     }
//   };

//   useEffect(() => {
//     if (normalDiscs === 0 && bonusDiscs === 0) {
//       handleGameEnd();
//     }
//     // eslint-disable-next-line 
//   }, [normalDiscs, bonusDiscs]);

//   return (
//     <div
//       className="arcade-game-container"
//       style={{ backgroundImage: `url(${backgroundImage})` }}
//     >
//       {!readyToStart && (
//         <button className="start-game-button" onClick={() => setReadyToStart(true)}>
//           Start Game
//         </button>
//       )}

//       {readyToStart && !gameStarted && startCountdown !== null && (
//         <div className="countdown-display">
//           <h2>Game starts in: {startCountdown}</h2>
//         </div>
//       )}

//       {gameEnded && <h2>Game Over!</h2>}

//       <div className="top-section">
//         <div className="time-left">
//           <img src={timerIcon} alt="Timer" />
//           <span>{`${Math.floor(timeLeft / 60)}:${(timeLeft % 60)
//             .toString()
//             .padStart(2, "0")}`}</span>
//         </div>
//         <div className="misses">
//           <img src={forbiddenCircle} alt="Misses" />
//           <span>{misses}</span>
//         </div>
//       </div>

//       <div className="score-display">
//         <h1>{score.toString().padStart(3, "0")}</h1>
//       </div>

//       <div className="game-board1">
//         {grid.map((row, rowIndex) => (
//           <div key={rowIndex} className="board-row">
//             {row.map((cell, colIndex) => (
//               <div
//                 key={colIndex}
//                 className={`board-cell1 ${cell === "B" ? "bonus-cell" : cell === "N" ? "normal-cell" : ""}`}
//                 onClick={() => handleManualThrow(rowIndex, colIndex)}
//               ></div>
//             ))}
//           </div>
//         ))}
//       </div>

//       <div className="bottom-section">
//         <div className="discs-left">
//           <h3>DISCS LEFT: {normalDiscs}</h3>
//           <div className="disc-info">
//             {normalDiscColors.slice(0, normalDiscs).map((disc, index) => (
//               <img
//                 key={index}
//                 src={disc}
//                 alt={`Normal Disc ${index}`}
//                 style={{ width: discSize.normal }}
//               />
//             ))}
//           </div>
//         </div>

//         <div className="bonus-discs-left">
//           <h3>BONUS DISCS LEFT: {bonusDiscs}</h3>
//           <div className="disc-info">
//             {bonusDiscColors.slice(0, bonusDiscs).map((disc, index) => (
//               <img
//                 key={index}
//                 src={disc}
//                 alt={`Bonus Disc ${index}`}
//                 style={{ width: discSize.bonus }}
//               />
//             ))}
//           </div>
//         </div>
//       </div>

//       <button className="back-button" onClick={navigateToSelection}>
//         Back to Selection
//       </button>
//     </div>
//   );
// };

// export default DiscArcadeModeGame;



// import React, { useState, useEffect } from "react";
// import "./DiscArcadeModeGame.css";
// import timerIcon from "../assets/timer.png";
// import forbiddenCircle from "../assets/forbiddenCircle.png";
// import purpleDisc from "../assets/purpledisc.png";
// import redDisc from "../assets/reddisc.png";
// import orangeDisc from "../assets/orangedisc.png";
// import blueDisc from "../assets/bluedisc.png";
// import yellowDisc from "../assets/yellowdisc.png";
// import greenDisc from "../assets/greendisc.png";
// import backgroundImage from "../assets/background-image.png";

// const DiscArcadeModeGame = ({ navigateToSelection }) => {
//   const [timeLeft, setTimeLeft] = useState(0); // Increment timer
//   const [score, setScore] = useState(0);
//   const [misses, setMisses] = useState(0);
//   const [normalDiscs, setNormalDiscs] = useState(10);
//   const [bonusDiscs, setBonusDiscs] = useState(10);
//   const [gameStarted, setGameStarted] = useState(false);
//   const [readyToStart, setReadyToStart] = useState(false); // Control when to start the game
//   const [startCountdown, setStartCountdown] = useState(null); // 3-second countdown
//   const [gameEnded, setGameEnded] = useState(false);
//   const [firstThrowMade, setFirstThrowMade] = useState(false); // Track if the first throw was made

//   // Flags for input modes
//   const useSimulatedInput = false; // Toggle for simulated data
//   const useManualInput = true; // Toggle for manual board clicks

//   const [normalDiscColors, setNormalDiscColors] = useState([
//     purpleDisc,
//     redDisc,
//     orangeDisc,
//     blueDisc,
//     yellowDisc,
//     purpleDisc,
//     redDisc,
//     orangeDisc,
//     blueDisc,
//     yellowDisc,
//   ]);

//   const [bonusDiscColors, setBonusDiscColors] = useState([
//     greenDisc,
//     blueDisc,
//     redDisc,
//     yellowDisc,
//     orangeDisc,
//     greenDisc,
//     blueDisc,
//     redDisc,
//     yellowDisc,
//     orangeDisc,
//   ]);

//   const discSize = {
//     normal: "50px", // Large disc size
//     bonus: "30px", // Small disc size
//   };

//   // Create a 3x3 grid for holes
//   const initialGrid = Array(3)
//     .fill(null)
//     .map(() => Array(3).fill(null));

//   const [grid, setGrid] = useState(initialGrid);

//   // Initial countdown logic
//   useEffect(() => {
//     if (readyToStart && !gameStarted && startCountdown === null) {
//       setStartCountdown(3); // Start the countdown when ready

//       const countdownInterval = setInterval(() => {
//         setStartCountdown((prev) => {
//           if (prev === 1) {
//             clearInterval(countdownInterval);
//             setGameStarted(true); // Start the game
//             setStartCountdown(null); // Reset countdown
//             return null;
//           }
//           return prev - 1;
//         });
//       }, 1000);

//       return () => clearInterval(countdownInterval); // Cleanup interval
//     }
//   }, [readyToStart, gameStarted, startCountdown]);

//   // Idle detection logic
//   useEffect(() => {
//     if (firstThrowMade && !gameEnded) {
//       const idleTimeout = setTimeout(() => {
//         setStartCountdown(3); // Start 3-second countdown
//         const countdownInterval = setInterval(() => {
//           setStartCountdown((prev) => {
//             if (prev === 1) {
//               clearInterval(countdownInterval);
//               setMisses((prevMisses) => prevMisses + 1); // Increment misses
//               setStartCountdown(null); // Clear countdown
//               return null;
//             }
//             return prev - 1;
//           });
//         }, 1000);
//       }, 5000);

//       return () => {
//         clearTimeout(idleTimeout); // Cleanup idle timeout
//       };
//     }
//   }, [firstThrowMade, gameEnded]);

//   // Start Game on First Throw or Countdown
//   const handleFirstThrow = () => {
//     if (!gameStarted) {
//       setGameStarted(true);
//       setTimeLeft(0); // Reset timer
//     }
//     setFirstThrowMade(true);
//   };

//   // Handle manual input (simulated click)
//   const handleManualThrow = (row, col) => {
//     if ((useManualInput === false && useSimulatedInput === false) || gameEnded || grid[row][col] !== null) {
//       return;
//     }

//     handleFirstThrow(); // Start the game if it's the first throw

//     const isBonus = Math.random() > 0.5; // Randomly determine disc type
//     const points = isBonus ? 20 : 10;

//     // Highlight the grid cell temporarily
//     setGrid((prev) => {
//       const newGrid = [...prev];
//       newGrid[row][col] = isBonus ? "B" : "N";
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = [...prev];
//         newGrid[row][col] = null; // Reset cell after 1.5 seconds
//         return newGrid;
//       });
//     }, 1500);

//     if (isBonus) {
//       if (bonusDiscs > 0) {
//         setScore((prev) => prev + points);
//         setBonusDiscs((prev) => prev - 1);
//         setBonusDiscColors((prevColors) => prevColors.slice(0, -1)); // Remove one bonus disc color
//       } else {
//         setMisses((prev) => prev + 1); // Increment misses if no bonus discs left
//       }
//     } else {
//       if (normalDiscs > 0) {
//         setScore((prev) => prev + points);
//         setNormalDiscs((prev) => prev - 1);
//         setNormalDiscColors((prevColors) => prevColors.slice(0, -1)); // Remove one normal disc color
//       } else {
//         setMisses((prev) => prev + 1); // Increment misses if no normal discs left
//       }
//     }

//     if (normalDiscs === 0 && bonusDiscs === 0) {
//       setGameEnded(true);
//     }
//   };

//   // Simulated Input Logic
//   useEffect(() => {
//     if (useSimulatedInput && !gameEnded) {
//       const simulateThrows = setInterval(() => {
//         if (normalDiscs <= 0 && bonusDiscs <= 0) {
//           clearInterval(simulateThrows); // Stop simulation if no discs are left
//           return;
//         }
//         const row = Math.floor(Math.random() * 3);
//         const col = Math.floor(Math.random() * 3);
//         handleManualThrow(row, col);
//       }, 1000);

//       return () => clearInterval(simulateThrows);
//     }
//   }, [normalDiscs, bonusDiscs, gameEnded, useSimulatedInput]);

//   // End Game Logic
//   const handleGameEnd = () => {
//     setGameEnded(true);

//     // Simulated disc return check
//     const discsReturned = normalDiscs === 0 && bonusDiscs === 0; // Simulated check
//     if (discsReturned) {
//       alert("All discs returned. Game Over!");
//     } else {
//       alert("Please return all discs to the holding bin.");
//     }
//   };

//   useEffect(() => {
//     if (normalDiscs === 0 && bonusDiscs === 0) {
//       handleGameEnd();
//     }
//   }, [normalDiscs, bonusDiscs]);

//   return (
//     <div
//       className="arcade-game-container"
//       style={{ backgroundImage: `url(${backgroundImage})` }}
//     >
//       {!readyToStart && (
//         <button className="start-game-button" onClick={() => setReadyToStart(true)}>
//           Start Game
//         </button>
//       )}

//       {readyToStart && !gameStarted && startCountdown !== null && (
//         <div className="countdown-display">
//           <h2>Game starts in: {startCountdown}</h2>
//         </div>
//       )}

//       {gameEnded && <h2>Game Over!</h2>}

//       <div className="top-section">
//         <div className="time-left">
//           <img src={timerIcon} alt="Timer" />
//           <span>{`${Math.floor(timeLeft / 60)}:${(timeLeft % 60)
//             .toString()
//             .padStart(2, "0")}`}</span>
//         </div>
//         <div className="misses">
//           <img src={forbiddenCircle} alt="Misses" />
//           <span>{misses}</span>
//         </div>
//       </div>

//       <div className="score-display">
//         <h1>{score.toString().padStart(3, "0")}</h1>
//       </div>

//       <div className="game-board tictactoe-board">
//         {grid.map((row, rowIndex) => (
//           <div key={rowIndex} className="board-row">
//             {row.map((cell, colIndex) => (
//               <div
//                 key={colIndex}
//                 className={`board-cell ${cell === "B" ? "bonus-cell" : cell === "N" ? "normal-cell" : ""}`}
//                 onClick={() => handleManualThrow(rowIndex, colIndex)}
//               ></div>
//             ))}
//           </div>
//         ))}
//       </div>

//       <div className="bottom-section">
//         <div className="discs-left">
//           <h3>DISCS LEFT: {normalDiscs}</h3>
//           <div className="disc-info">
//             {normalDiscColors.slice(0, normalDiscs).map((disc, index) => (
//               <img
//                 key={index}
//                 src={disc}
//                 alt={`Normal Disc ${index}`}
//                 style={{ width: discSize.normal }}
//               />
//             ))}
//           </div>
//         </div>

//         <div className="bonus-discs-left">
//           <h3>BONUS DISCS LEFT: {bonusDiscs}</h3>
//           <div className="disc-info">
//             {bonusDiscColors.slice(0, bonusDiscs).map((disc, index) => (
//               <img
//                 key={index}
//                 src={disc}
//                 alt={`Bonus Disc ${index}`}
//                 style={{ width: discSize.bonus }}
//               />
//             ))}
//           </div>
//         </div>
//       </div>

//       <button className="back-button" onClick={navigateToSelection}>
//         Back to Selection
//       </button>
//     </div>
//   );
// };

// export default DiscArcadeModeGame;



// import React, { useState, useEffect } from "react";
// import "./DiscArcadeModeGame.css";
// import timerIcon from "../assets/timer.png";
// import forbiddenCircle from "../assets/forbiddenCircle.png";
// import purpleDisc from "../assets/purpledisc.png";
// import redDisc from "../assets/reddisc.png";
// import orangeDisc from "../assets/orangedisc.png";
// import blueDisc from "../assets/bluedisc.png";
// import yellowDisc from "../assets/yellowdisc.png";
// import greenDisc from "../assets/greendisc.png";
// import backgroundImage from "../assets/background-image.png";

// const DiscArcadeModeGame = ({ navigateToSelection }) => {
//   const [timeLeft, setTimeLeft] = useState(0); // Increment timer
//   const [score, setScore] = useState(0);
//   const [misses, setMisses] = useState(0);
//   const [normalDiscs, setNormalDiscs] = useState(10);
//   const [bonusDiscs, setBonusDiscs] = useState(10);
//   const [gameStarted, setGameStarted] = useState(false);
//   const [startCountdown, setStartCountdown] = useState(3); // 3-second countdown
//   const [gameEnded, setGameEnded] = useState(false);
//   const [firstThrowMade, setFirstThrowMade] = useState(false); // Track if the first throw was made

//   // Flags for input modes
//   const useSimulatedInput = false; // Toggle for simulated data
//   const useManualInput = true; // Toggle for manual board clicks

//   const [normalDiscColors, setNormalDiscColors] = useState([
//     purpleDisc,
//     redDisc,
//     orangeDisc,
//     blueDisc,
//     yellowDisc,
//     purpleDisc,
//     redDisc,
//     orangeDisc,
//     blueDisc,
//     yellowDisc,
//   ]);

//   const [bonusDiscColors, setBonusDiscColors] = useState([
//     greenDisc,
//     blueDisc,
//     redDisc,
//     yellowDisc,
//     orangeDisc,
//     greenDisc,
//     blueDisc,
//     redDisc,
//     yellowDisc,
//     orangeDisc,
//   ]);

//   const discSize = {
//     normal: "50px", // Large disc size
//     bonus: "30px", // Small disc size
//   };

//   // Create a 3x3 grid for holes
//   const initialGrid = Array(3)
//     .fill(null)
//     .map(() => Array(3).fill(null));

//   const [grid, setGrid] = useState(initialGrid);

//   // Initial countdown logic
//   useEffect(() => {
//     if (!gameStarted && startCountdown !== null) {
//       const countdownInterval = setInterval(() => {
//         setStartCountdown((prev) => {
//           if (prev === 1) {
//             clearInterval(countdownInterval);
//             setGameStarted(true); // Start the game
//             setStartCountdown(null); // Reset countdown
//             return null;
//           }
//           return prev - 1;
//         });
//       }, 1000);

//       return () => clearInterval(countdownInterval); // Cleanup interval
//     }
//   }, [gameStarted, startCountdown]);

//   // Idle detection logic
//   useEffect(() => {
//     if (firstThrowMade && !gameEnded) {
//       const idleTimeout = setTimeout(() => {
//         setStartCountdown(3); // Start 3-second countdown
//         const countdownInterval = setInterval(() => {
//           setStartCountdown((prev) => {
//             if (prev === 1) {
//               clearInterval(countdownInterval);
//               setMisses((prevMisses) => prevMisses + 1); // Increment misses
//               setStartCountdown(null); // Clear countdown
//               return null;
//             }
//             return prev - 1;
//           });
//         }, 1000);
//       }, 5000);

//       return () => {
//         clearTimeout(idleTimeout); // Cleanup idle timeout
//       };
//     }
//   }, [firstThrowMade, gameEnded]);

//   // Start Game on First Throw or Countdown
//   const handleFirstThrow = () => {
//     if (!gameStarted) {
//       setGameStarted(true);
//       setTimeLeft(0); // Reset timer
//     }
//     setFirstThrowMade(true);
//   };

//   // Handle manual input (simulated click)
//   const handleManualThrow = (row, col) => {
//     if ((useManualInput === false && useSimulatedInput === false) || gameEnded || grid[row][col] !== null) {
//       return;
//     }

//     handleFirstThrow(); // Start the game if it's the first throw

//     const isBonus = Math.random() > 0.5; // Randomly determine disc type
//     const points = isBonus ? 20 : 10;

//     // Highlight the grid cell temporarily
//     setGrid((prev) => {
//       const newGrid = [...prev];
//       newGrid[row][col] = isBonus ? "B" : "N";
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = [...prev];
//         newGrid[row][col] = null; // Reset cell after 1.5 seconds
//         return newGrid;
//       });
//     }, 1500);

//     if (isBonus) {
//       if (bonusDiscs > 0) {
//         setScore((prev) => prev + points);
//         setBonusDiscs((prev) => prev - 1);
//         setBonusDiscColors((prevColors) => prevColors.slice(0, -1)); // Remove one bonus disc color
//       } else {
//         setMisses((prev) => prev + 1); // Increment misses if no bonus discs left
//       }
//     } else {
//       if (normalDiscs > 0) {
//         setScore((prev) => prev + points);
//         setNormalDiscs((prev) => prev - 1);
//         setNormalDiscColors((prevColors) => prevColors.slice(0, -1)); // Remove one normal disc color
//       } else {
//         setMisses((prev) => prev + 1); // Increment misses if no normal discs left
//       }
//     }

//     if (normalDiscs === 0 && bonusDiscs === 0) {
//       setGameEnded(true);
//     }
//   };

//   // Simulated Input Logic
//   useEffect(() => {
//     if (useSimulatedInput && !gameEnded) {
//       const simulateThrows = setInterval(() => {
//         if (normalDiscs <= 0 && bonusDiscs <= 0) {
//           clearInterval(simulateThrows); // Stop simulation if no discs are left
//           return;
//         }
//         const row = Math.floor(Math.random() * 3);
//         const col = Math.floor(Math.random() * 3);
//         handleManualThrow(row, col);
//       }, 1000);

//       return () => clearInterval(simulateThrows);
//     }
//   }, [normalDiscs, bonusDiscs, gameEnded, useSimulatedInput]);

//   // End Game Logic
//   const handleGameEnd = () => {
//     setGameEnded(true);

//     // Simulated disc return check
//     const discsReturned = normalDiscs === 0 && bonusDiscs === 0; // Simulated check
//     if (discsReturned) {
//       alert("All discs returned. Game Over!");
//     } else {
//       alert("Please return all discs to the holding bin.");
//     }
//   };

//   useEffect(() => {
//     if (normalDiscs === 0 && bonusDiscs === 0) {
//       handleGameEnd();
//     }
//   }, [normalDiscs, bonusDiscs]);

//   return (
//     <div
//       className="arcade-game-container"
//       style={{ backgroundImage: `url(${backgroundImage})` }}
//     >
//       {!gameStarted && startCountdown !== null && (
//         <div className="countdown-display">
//           <h2>Game starts in: {startCountdown}</h2>
//         </div>
//       )}

//       {gameEnded && <h2>Game Over!</h2>}

//       <div className="top-section">
//         <div className="time-left">
//           <img src={timerIcon} alt="Timer" />
//           <span>{`${Math.floor(timeLeft / 60)}:${(timeLeft % 60)
//             .toString()
//             .padStart(2, "0")}`}</span>
//         </div>
//         <div className="misses">
//           <img src={forbiddenCircle} alt="Misses" />
//           <span>{misses}</span>
//         </div>
//       </div>

//       <div className="score-display">
//         <h1>{score.toString().padStart(3, "0")}</h1>
//       </div>

//       <div className="game-board tictactoe-board">
//         {grid.map((row, rowIndex) => (
//           <div key={rowIndex} className="board-row">
//             {row.map((cell, colIndex) => (
//               <div
//                 key={colIndex}
//                 className={`board-cell ${cell === "B" ? "bonus-cell" : cell === "N" ? "normal-cell" : ""}`}
//                 onClick={() => handleManualThrow(rowIndex, colIndex)}
//               ></div>
//             ))}
//           </div>
//         ))}
//       </div>

//       <div className="bottom-section">
//         <div className="discs-left">
//           <h3>DISCS LEFT: {normalDiscs}</h3>
//           <div className="disc-info">
//             {normalDiscColors.slice(0, normalDiscs).map((disc, index) => (
//               <img
//                 key={index}
//                 src={disc}
//                 alt={`Normal Disc ${index}`}
//                 style={{ width: discSize.normal }}
//               />
//             ))}
//           </div>
//         </div>

//         <div className="bonus-discs-left">
//           <h3>BONUS DISCS LEFT: {bonusDiscs}</h3>
//           <div className="disc-info">
//             {bonusDiscColors.slice(0, bonusDiscs).map((disc, index) => (
//               <img
//                 key={index}
//                 src={disc}
//                 alt={`Bonus Disc ${index}`}
//                 style={{ width: discSize.bonus }}
//               />
//             ))}
//           </div>
//         </div>
//       </div>

//       <button className="back-button" onClick={navigateToSelection}>
//         Back to Selection
//       </button>
//     </div>
//   );
// };

// export default DiscArcadeModeGame;



