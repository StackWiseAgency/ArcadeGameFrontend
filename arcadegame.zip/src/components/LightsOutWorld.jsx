import React, { useState, useEffect, useCallback } from "react";
import Timer from "./Timer";
import "./LightsOutWorld.css";
import * as signalR from "@microsoft/signalr";

const LightsOutWorld = ({ navigateToSelection }) => {
  // State Variables
  const [grid, setGrid] = useState(
    Array(3)
      .fill(null)
      .map(() => Array(3).fill(true))
  ); // Grid state (true = ON, false = OFF)
  const [remainingDiscs, setRemainingDiscs] = useState(20); // Total discs
  const [misses, setMisses] = useState(0); // Missed throws
  const [timer, setTimer] = useState(0); // Elapsed time
  const [isGameOver, setIsGameOver] = useState(false); // Game over flag
  const [userHasThrown, setUserHasThrown] = useState(false); // Disc throw detection
  const [lastThrowTime, setLastThrowTime] = useState(Date.now()); // Track last throw time
  const [useManualInput] = useState(false); // Manual mode flag
  const [useApiInput] = useState(false); // API mode flag
  const [useWebSocketInput] = useState(true); // WebSocket mode flag

  // Handle Game End
  const handleGameEnd = useCallback(() => {
    setIsGameOver(true);
  }, []);

  // Reset the grid for the next round
  const resetGrid = useCallback(() => {
    const newGrid = Array(3)
      .fill(null)
      .map(() => Array(3).fill(false)); // Start with all lights OFF

    let lightsToTurnOn = Math.floor(Math.random() * 3) + 3; // Randomly choose 3 to 5 lights to turn ON
    while (lightsToTurnOn > 0) {
      const row = Math.floor(Math.random() * 3);
      const col = Math.floor(Math.random() * 3);

      if (!newGrid[row][col]) {
        newGrid[row][col] = true;
        lightsToTurnOn--;
      }
    }

    setGrid(newGrid); // Set the new grid with random lights ON
  }, []);

  // Handle Throw (Manual and API Play)
  const handleThrow = useCallback((row, col) => {
    // This is the main function where the game's logic for handling a player's throw resides.
    // Ensure it integrates all necessary checks for game end and grid updates.

    if (isGameOver) return; // Prevent interaction after game ends

    if (!userHasThrown) {
      setUserHasThrown(true); // Start the game if the user throws before the timer begins
    }

    setLastThrowTime(Date.now()); // Update last throw time

    if (remainingDiscs <= 1) {
      setRemainingDiscs(0); // Ensure discs are set to 0 for visual consistency
      handleGameEnd(); // End game if no discs are left
      return;
    }

    const newGrid = grid.map((gridRow, rowIndex) =>
      gridRow.map((cell, colIndex) => {
        if (rowIndex === row && colIndex === col) {
          if (cell) {
            setRemainingDiscs((prev) => Math.max(0, prev - 1)); // Decrement discs with guard
            return false; // Turn the light OFF
          } else {
            setMisses((prev) => prev + 1); // Increment misses
            setRemainingDiscs((prev) => Math.max(0, prev - 1)); // Decrement discs with guard
          }
        }
        return cell;
      })
    );

    setGrid(newGrid);

    // Check for game reset or end
    if (newGrid.flat().every((cell) => !cell)) {
      if (remainingDiscs > 0) {
        resetGrid(); // Reset the grid for the next round with random lights ON
      } else {
        handleGameEnd(); // End the game if no frisbees are left
      }
    }
  }, [grid, isGameOver, handleGameEnd, resetGrid, remainingDiscs, userHasThrown]);

  // Fetch API Data for Throws with Retry (Commented Out)
  
  const fetchAntennaDataFromAPI = useCallback(async () => {
    if (!useApiInput || isGameOver) return; // Ignore if not in API mode or game ends

    const fetchWithRetry = async (url, retries = 3) => {
      for (let i = 0; i < retries; i++) {
        try {
          const response = await fetch(url, {
            method: "POST", // Replace with the correct method
            headers: {
              "Content-Type": "application/json", // Include required headers
              "Referer": "http://localhost:3000",
            },
            body: JSON.stringify({ /* Include payload if needed */ }),
          });
          if (response.ok) return await response.json();
        } catch (error) {
          if (i === retries - 1) throw error; // Throw error after last retry
        }
      }
    };
    

    try {
      const data = await fetchWithRetry("https://arcadegamebackendapi20241227164011.azurewebsites.net/api/GameSimulation/simulate", 3); // Retry 3 times
      const { row, col } = data;
      if (row >= 0 && row < 3 && col >= 0 && col < 3) { // Validate row and col
        handleThrow(row, col);
      } else {
        console.warn("Invalid data received from API:", data);
      }
    } catch (error) {
      console.error("Error fetching antenna data:", error);
    }
  }, [useApiInput, isGameOver, handleThrow]);
  
  // API Integration for Real-Time Data
  useEffect(() => {
    if (!useApiInput || isGameOver) return;

    const interval = setInterval(() => {
      fetchAntennaDataFromAPI(); // Call API function periodically
    }, 2000); // Fetch every 2 seconds

    return () => clearInterval(interval); // Cleanup on unmount or mode change
  }, [useApiInput, isGameOver, fetchAntennaDataFromAPI]);

  // Timer for elapsed time
  useEffect(() => {
    if (!userHasThrown || isGameOver) return;

    const timerInterval = setInterval(() => {
      setTimer((prev) => prev + 1);
    }, 1000);

    return () => clearInterval(timerInterval);
  }, [userHasThrown, isGameOver]);

  useEffect(() => {
    if (!useWebSocketInput || isGameOver) return;

    const connection = new signalR.HubConnectionBuilder()
      .withUrl("https://arcadegamebackendapi20241227164011.azurewebsites.net/gameHub", {
        transport: signalR.HttpTransportType.WebSockets | 
                   signalR.HttpTransportType.ServerSentEvents | 
                   signalR.HttpTransportType.LongPolling, // Enable fallback transports
      })
      .configureLogging(signalR.LogLevel.Information) // Optional: Logging for debugging
      .withAutomaticReconnect() 
      .build();

    connection.start()
      .then(() => {
        console.log("SignalR connection established using fallback transports");
        connection.on("ReceiveMove", (row, col) => {
          console.log(`Move received: Row=${row}, Col=${col}`);
          handleThrow(row, col); // Update UI or game state
        });
      })
      .catch((err) => console.error("SignalR connection error:", err));

    return () => {
      connection.stop(); // Clean up the connection on component unmount
    };
  }, [useWebSocketInput, isGameOver, handleThrow]);

  useEffect(() => {
    if (isGameOver) return;

    const inactivityInterval = setInterval(() => {
      // This handles the 30-second inactivity timeout to end the game, ensuring players cannot leave the game in an unfinished state.
      if (Date.now() - lastThrowTime > 90000) {
        handleGameEnd();
      }
    }, 1000); // Check every second

    return () => clearInterval(inactivityInterval);
  }, [isGameOver, lastThrowTime, handleGameEnd]);

  // Result Screen
  const renderResultScreen = () => (
    <div className="lights-result-screen">
      <h1>Game Over</h1>
      <p>
        Status: {grid.flat().every((cell) => !cell) ? "All Lights Turned Off!" : "Out of Discs!"}
      </p>
      <p>Time: {`${Math.floor(timer / 60)}:${timer % 60}`}</p>
      <p>Discs Left: {remainingDiscs}</p>
      <p>Misses: {misses}</p>
      <button className="lights-back-button" onClick={navigateToSelection}>
        Back to Game Selection
      </button>
    </div>
  );

  // Game Board
  const renderGameBoard = () => (
    <div className="lights-container">
      <h1 className="lights-game-title">Lights Out</h1>
      <div className="lights-scoreboard">
        <p>Time: {`${Math.floor(timer / 60)}:${timer % 60}`}</p>
        <p>Discs Left: {remainingDiscs}</p>
        <p>Misses: {misses}</p>
      </div>
      <div className="lights-grid">
        {grid.map((row, rowIndex) => (
          <div key={rowIndex} className="lights-grid-row">
            {row.map((cell, colIndex) => (
              <div
                key={colIndex}
                className={`lights-cell ${cell ? "lit" : "off"}`}
                onClick={() => useManualInput && handleThrow(rowIndex, colIndex)}
              ></div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
  // Return Main Component
  return (
    <div className="lights-container">
      {!userHasThrown && !isGameOver && (
        <Timer userHasThrown={userHasThrown} onStart={() => setUserHasThrown(true)} />
      )}
      {isGameOver ? renderResultScreen() : renderGameBoard()}
    </div>
  );
};

export default LightsOutWorld;

// import React, { useState, useEffect, useCallback } from "react";
// import Timer from "./Timer";
// import "./LightsOutWorld.css";

// const LightsOutWorld = ({ navigateToSelection }) => {
//   // State Variables
//   const [grid, setGrid] = useState(
//     Array(3)
//       .fill(null)
//       .map(() => Array(3).fill(true))
//   ); // Grid state (true = ON, false = OFF)
//   const [remainingDiscs, setRemainingDiscs] = useState(20); // Total discs
//   const [misses, setMisses] = useState(0); // Missed throws
//   const [timer, setTimer] = useState(0); // Elapsed time
//   const [isGameOver, setIsGameOver] = useState(false); // Game over flag
//   const [userHasThrown, setUserHasThrown] = useState(false); // Disc throw detection
//   const [lastThrowTime, setLastThrowTime] = useState(Date.now()); // Track last throw time
//   const [useManualInput] = useState(false); // Manual mode flag
//   const [useApiInput] = useState(true); // API mode flag

//   // Handle Game End
//   const handleGameEnd = useCallback(() => {
//     setIsGameOver(true);
//   }, []);

//   // Reset the grid for the next round
//   const resetGrid = useCallback(() => {
//     const newGrid = Array(3)
//       .fill(null)
//       .map(() => Array(3).fill(false)); // Start with all lights OFF

//     let lightsToTurnOn = Math.floor(Math.random() * 3) + 3; // Randomly choose 3 to 5 lights to turn ON
//     while (lightsToTurnOn > 0) {
//       const row = Math.floor(Math.random() * 3);
//       const col = Math.floor(Math.random() * 3);

//       if (!newGrid[row][col]) {
//         newGrid[row][col] = true;
//         lightsToTurnOn--;
//       }
//     }

//     setGrid(newGrid); // Set the new grid with random lights ON
//   }, []);

//   // Handle Throw (Manual and API Play)
//   const handleThrow = useCallback((row, col) => {
//     // This is the main function where the game's logic for handling a player's throw resides.
//     // Ensure it integrates all necessary checks for game end and grid updates.

//     if (isGameOver) return; // Prevent interaction after game ends

//     if (!userHasThrown) {
//       setUserHasThrown(true); // Start the game if the user throws before the timer begins
//     }

//     setLastThrowTime(Date.now()); // Update last throw time

//     if (remainingDiscs <= 1) {
//       setRemainingDiscs(0); // Ensure discs are set to 0 for visual consistency
//       handleGameEnd(); // End game if no discs are left
//       return;
//     }

//     const newGrid = grid.map((gridRow, rowIndex) =>
//       gridRow.map((cell, colIndex) => {
//         if (rowIndex === row && colIndex === col) {
//           if (cell) {
//             setRemainingDiscs((prev) => Math.max(0, prev - 1)); // Decrement discs with guard
//             return false; // Turn the light OFF
//           } else {
//             setMisses((prev) => prev + 1); // Increment misses
//             setRemainingDiscs((prev) => Math.max(0, prev - 1)); // Decrement discs with guard
//           }
//         }
//         return cell;
//       })
//     );

//     setGrid(newGrid);

//     // Check for game reset or end
//     if (newGrid.flat().every((cell) => !cell)) {
//       if (remainingDiscs > 0) {
//         resetGrid(); // Reset the grid for the next round with random lights ON
//       } else {
//         handleGameEnd(); // End the game if no frisbees are left
//       }
//     }
//   }, [grid, isGameOver, handleGameEnd, resetGrid, remainingDiscs, userHasThrown]);

//   // Fetch API Data for Throws with Retry (Commented Out)
  
//   const fetchAntennaDataFromAPI = useCallback(async () => {
//     if (!useApiInput || isGameOver) return; // Ignore if not in API mode or game ends

//     const fetchWithRetry = async (url, retries = 3) => {
//       for (let i = 0; i < retries; i++) {
//         try {
//           const response = await fetch(url);
//           if (response.ok) return await response.json();
//         } catch (error) {
//           if (i === retries - 1) throw error; // Throw error after last retry
//         }
//       }
//     };

//     try {
//       const data = await fetchWithRetry("https://arcadegamebackendapi20241227164011.azurewebsites.net/api/GameSimulation/simulate", 3); // Retry 3 times
//       const { row, col } = data;
//       if (row >= 0 && row < 3 && col >= 0 && col < 3) { // Validate row and col
//         handleThrow(row, col);
//       } else {
//         console.warn("Invalid data received from API:", data);
//       }
//     } catch (error) {
//       console.error("Error fetching antenna data:", error);
//     }
//   }, [useApiInput, isGameOver, handleThrow]);
  

//   // Timer for elapsed time
//   useEffect(() => {
//     if (!userHasThrown || isGameOver) return;

//     const timerInterval = setInterval(() => {
//       setTimer((prev) => prev + 1);
//     }, 1000);

//     return () => clearInterval(timerInterval);
//   }, [userHasThrown, isGameOver]);

//   // WebSocket Integration for Real-Time Data
//   // useEffect(() => {
//   //   if (!useApiInput || isGameOver) return;

//   //   const socket = new WebSocket("https://arcadegamebackendapi20241227164011.azurewebsites.net/api/GameSimulation/simulate");

//   //   socket.onopen = () => {
//   //     console.log("WebSocket connection established");
//   //   };

//   //   socket.onmessage = (event) => {
//   //     const { row, col } = JSON.parse(event.data);

//   //     // Validate the received data
//   //     if (row >= 0 && row < 3 && col >= 0 && col < 3) {
//   //       handleThrow(row, col);
//   //     } else {
//   //       console.warn("Invalid data received from WebSocket:", { row, col });
//   //     }
//   //   };

//   //   socket.onerror = (error) => {
//   //     console.error("WebSocket error:", error);
//   //   };

//   //   socket.onclose = () => {
//   //     console.log("WebSocket connection closed");
//   //   };

//   //   return () => {
//   //     socket.close();
//   //   };
//   // }, [useApiInput, isGameOver, handleThrow]);

//   // Inactivity Timer for 30 seconds
//   useEffect(() => {
//     if (isGameOver) return;

//     const inactivityInterval = setInterval(() => {
//       // This handles the 30-second inactivity timeout to end the game, ensuring players cannot leave the game in an unfinished state.
//       if (Date.now() - lastThrowTime > 90000) {
//         handleGameEnd();
//       }
//     }, 1000); // Check every second

//     return () => clearInterval(inactivityInterval);
//   }, [isGameOver, lastThrowTime, handleGameEnd]);

//   // Result Screen
//   const renderResultScreen = () => (
//     <div className="lights-result-screen">
//       <h1>Game Over</h1>
//       <p>
//         Status: {grid.flat().every((cell) => !cell) ? "All Lights Turned Off!" : "Out of Discs!"}
//       </p>
//       <p>Time: {`${Math.floor(timer / 60)}:${timer % 60}`}</p>
//       <p>Discs Left: {remainingDiscs}</p>
//       <p>Misses: {misses}</p>
//       <button className="lights-back-button" onClick={navigateToSelection}>
//         Back to Game Selection
//       </button>
//     </div>
//   );

//   // Game Board
//   const renderGameBoard = () => (
//     <div className="lights-container">
//       <h1 className="lights-game-title">Lights Out</h1>
//       <div className="lights-scoreboard">
//         <p>Time: {`${Math.floor(timer / 60)}:${timer % 60}`}</p>
//         <p>Discs Left: {remainingDiscs}</p>
//         <p>Misses: {misses}</p>
//       </div>
//       <div className="lights-grid">
//         {grid.map((row, rowIndex) => (
//           <div key={rowIndex} className="lights-grid-row">
//             {row.map((cell, colIndex) => (
//               <div
//                 key={colIndex}
//                 className={`lights-cell ${cell ? "lit" : "off"}`}
//                 onClick={() => useManualInput && handleThrow(rowIndex, colIndex)}
//               ></div>
//             ))}
//           </div>
//         ))}
//       </div>
//     </div>
//   );

//   // Return Main Component
//   return (
//     <div className="lights-container">
//       {!userHasThrown && !isGameOver && (
//         <Timer userHasThrown={userHasThrown} onStart={() => setUserHasThrown(true)} />
//       )}
//       {isGameOver ? renderResultScreen() : renderGameBoard()}
//     </div>
//   );
// };

// export default LightsOutWorld;




// import React, { useState, useEffect, useCallback } from "react";
// import Timer from "./Timer";
// import "./LightsOutWorld.css";

// const LightsOutWorld = ({ navigateToSelection }) => {
//   // State Variables
//   const [grid, setGrid] = useState(
//     Array(3)
//       .fill(null)
//       .map(() => Array(3).fill(true))
//   ); // Grid state (true = ON, false = OFF)
//   const [remainingDiscs, setRemainingDiscs] = useState(20); // Total discs
//   const [misses, setMisses] = useState(0); // Missed throws
//   const [timer, setTimer] = useState(0); // Elapsed time
//   const [isGameOver, setIsGameOver] = useState(false); // Game over flag
//   const [userHasThrown, setUserHasThrown] = useState(false); // Disc throw detection
//   const [lastThrowTime, setLastThrowTime] = useState(Date.now()); // Track last throw time
//   const [useManualInput] = useState(true); // Manual mode flag
//   const [useApiInput] = useState(false); // API mode flag

//   // Handle Game End
//   const handleGameEnd = useCallback(() => {
//     setIsGameOver(true);
//   }, []);

//   // Reset the grid for the next round
//   const resetGrid = useCallback(() => {
//     const newGrid = Array(3)
//       .fill(null)
//       .map(() => Array(3).fill(false)); // Start with all lights OFF

//     let lightsToTurnOn = Math.floor(Math.random() * 3) + 3; // Randomly choose 3 to 5 lights to turn ON
//     while (lightsToTurnOn > 0) {
//       const row = Math.floor(Math.random() * 3);
//       const col = Math.floor(Math.random() * 3);

//       if (!newGrid[row][col]) {
//         newGrid[row][col] = true;
//         lightsToTurnOn--;
//       }
//     }

//     setGrid(newGrid); // Set the new grid with random lights ON
//   }, []);

//   // Handle Throw (Manual and API Play)
//   const handleThrow = useCallback((row, col) => {
//     // This is the main function where the game's logic for handling a player's throw resides.
//     // Ensure it integrates all necessary checks for game end and grid updates.

//     if (isGameOver) return; // Prevent interaction after game ends

//     if (!userHasThrown) {
//       setUserHasThrown(true); // Start the game if the user throws before the timer begins
//     }

//     setLastThrowTime(Date.now()); // Update last throw time

//     if (remainingDiscs <= 1) {
//       setRemainingDiscs(0); // Ensure discs are set to 0 for visual consistency
//       handleGameEnd(); // End game if no discs are left
//       return;
//     }

//     const newGrid = grid.map((gridRow, rowIndex) =>
//       gridRow.map((cell, colIndex) => {
//         if (rowIndex === row && colIndex === col) {
//           if (cell) {
//             setRemainingDiscs((prev) => Math.max(0, prev - 1)); // Decrement discs with guard
//             return false; // Turn the light OFF
//           } else {
//             setMisses((prev) => prev + 1); // Increment misses
//             setRemainingDiscs((prev) => Math.max(0, prev - 1)); // Decrement discs with guard
//           }
//         }
//         return cell;
//       })
//     );

//     setGrid(newGrid);

//     // Check for game reset or end
//     if (newGrid.flat().every((cell) => !cell)) {
//       if (remainingDiscs > 0) {
//         resetGrid(); // Reset the grid for the next round with random lights ON
//       } else {
//         handleGameEnd(); // End the game if no frisbees are left
//       }
//     }
//   }, [grid, isGameOver, handleGameEnd, resetGrid, remainingDiscs, userHasThrown]);

//   // Fetch API Data for Throws with Retry
//   const fetchAntennaDataFromAPI = useCallback(async () => {
//     if (!useApiInput || isGameOver) return; // Ignore if not in API mode or game ends

//     const fetchWithRetry = async (url, retries = 3) => {
//       for (let i = 0; i < retries; i++) {
//         try {
//           const response = await fetch(url);
//           if (response.ok) return await response.json();
//         } catch (error) {
//           if (i === retries - 1) throw error; // Throw error after last retry
//         }
//       }
//     };

//     try {
//       const data = await fetchWithRetry("http://your-api-endpoint", 3); // Retry 3 times
//       const { row, col } = data;
//       if (row >= 0 && row < 3 && col >= 0 && col < 3) { // Validate row and col
//         handleThrow(row, col);
//       } else {
//         console.warn("Invalid data received from API:", data);
//       }
//     } catch (error) {
//       console.error("Error fetching antenna data:", error);
//     }
//   }, [useApiInput, isGameOver, handleThrow]);

//   // Timer for elapsed time
//   useEffect(() => {
//     if (!userHasThrown || isGameOver) return;

//     const timerInterval = setInterval(() => {
//       setTimer((prev) => prev + 1);
//     }, 1000);

//     return () => clearInterval(timerInterval);
//   }, [userHasThrown, isGameOver]);

//   // Poll API Data if in API Mode
//   useEffect(() => {
//     if (!useApiInput || isGameOver) return;

//     const interval = setInterval(() => {
//       fetchAntennaDataFromAPI();
//     }, 2000); // Poll every 2 seconds

//     return () => clearInterval(interval);
//   }, [useApiInput, isGameOver, fetchAntennaDataFromAPI]);

  
//   useEffect(() => {
//     if (isGameOver) return;

//     const inactivityInterval = setInterval(() => {
      
//       if (Date.now() - lastThrowTime > 10000) {
//         handleGameEnd();
//       }
//     }, 1000); 

//     return () => clearInterval(inactivityInterval);
//   }, [isGameOver, lastThrowTime, handleGameEnd]);

 
//   const renderResultScreen = () => (
//     <div className="lights-result-screen">
//       <h1>Game Over</h1>
//       <p>
//         Status: {grid.flat().every((cell) => !cell) ? "All Lights Turned Off!" : "Out of Discs!"}
//       </p>
//       <p>Time: {`${Math.floor(timer / 60)}:${timer % 60}`}</p>
//       <p>Discs Left: {remainingDiscs}</p>
//       <p>Misses: {misses}</p>
//       <button className="lights-back-button" onClick={navigateToSelection}>
//         Back to Game Selection
//       </button>
//     </div>
//   );


//   const renderGameBoard = () => (
//     <div className="lights-container">
//       <h1 className="lights-game-title">Lights Out</h1>
//       <div className="lights-scoreboard">
//         <p>Time: {`${Math.floor(timer / 60)}:${timer % 60}`}</p>
//         <p>Discs Left: {remainingDiscs}</p>
//         <p>Misses: {misses}</p>
//       </div>
//       <div className="lights-grid">
//         {grid.map((row, rowIndex) => (
//           <div key={rowIndex} className="lights-grid-row">
//             {row.map((cell, colIndex) => (
//               <div
//                 key={colIndex}
//                 className={`lights-cell ${cell ? "lit" : "off"}`}
//                 onClick={() => useManualInput && handleThrow(rowIndex, colIndex)}
//               ></div>
//             ))}
//           </div>
//         ))}
//       </div>
//     </div>
//   );


//   return (
//     <div className="lights-container">
//       {!userHasThrown && !isGameOver && (
//         <Timer userHasThrown={userHasThrown} onStart={() => setUserHasThrown(true)} />
//       )}
//       {isGameOver ? renderResultScreen() : renderGameBoard()}
//     </div>
//   );
// };

// export default LightsOutWorld;


