import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import Coins from "./../assets/coins.png";
import "./../styles/SigninPage.css"; // Import the CSS file

const SigninPage = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (event) => {
    event.preventDefault(); // Prevent the form from refreshing the page

    if (!email || !password) {
      alert("Please enter both email and password.");
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      alert("Please enter a valid email address.");
      return;
    }

    try {
      console.log("Request Payload:", { email, password });

      // Create form data
      const formData = new URLSearchParams();
      formData.append("email", email);
      formData.append("password", password);

      // Send request as form data
      const response = await axios.post(
        "https://arcadegamebackendapi20241227164011.azurewebsites.net/api/Auth/Login",
        formData, // Pass the form data here
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded", // Form data header
          },
        }
      );

      console.log("Response Data:", response.data);

      if (response.status === 200) {
        navigate("/GameSelect");
      } else {
        alert("Invalid credentials, please try again.");
      }
    } catch (error) {
      console.error("Login failed:", error.response?.data || error.message);

      if (error.response?.data?.errors) {
        alert(`Validation Errors: ${JSON.stringify(error.response.data.errors, null, 2)}`);
      } else {
        alert("An error occurred. Please try again later.");
      }
    }
  };

  return (
    <div className="signin-container">
      <h1 className="signin-title">Welcome to Fling Disc</h1>
      <form className="signin-card" onSubmit={handleLogin}>
        <div className="input-field">
          <label htmlFor="email">Email</label>
          <input
            id="email"
            type="text"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div className="input-field">
          <label htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <button type="submit" className="signin-button">
          SIGN IN TO GET REWARDS <img src={Coins} alt="coins" />
        </button>
      </form>
      <div className="signin-divider">
        <span className="line"></span>
        <span className="divider-text">or</span>
        <span className="line"></span>
      </div>
      <div className="signin-footer">
        <a href="/signup" className="guest-link">
          Signup
        </a>
        <span className="separator">|</span>
        <a href="/guest" className="guest-link">
          Continue as a Guest
        </a>
      </div>
    </div>
  );
};

export default SigninPage;


// import React, { useState } from "react";
// // eslint-disable-next-line
// import axios from 'axios';
// import { useNavigate } from "react-router-dom";
// import Coins from "./../assets/coins.png";
// import "./../styles/SigninPage.css"; // Import the CSS file

// const SigninPage = () => {
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");
//   const [isLoading, setIsLoading] = useState(false); // For loading state
//   const navigate = useNavigate();

//   const handleLogin = async (event) => {
//     event.preventDefault(); // Prevent the form from refreshing the page

//     if (!email || !password) {
//       alert("Please enter both email and password.");
//       return;
//     }

//     if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
//       alert("Please enter a valid email address.");
//       return;
//     }

//     setIsLoading(true); // Start loading spinner

//     try {
//       const response = await axios.post(
//         "https://arcadegamebackendapi20241227164011.azurewebsites.net/api/Auth/Login",
//         { email: email, password: password },
//         { headers: { "Content-Type": "application/json" } }
//       );

//       if (response.status === 200) {
//         const token = response.data.token; // Adjust key based on API response
//         const user = response.data.user; // Adjust key based on API response
        
//         // Save token and user data
//         localStorage.setItem("authToken", token);
//         localStorage.setItem("user", JSON.stringify(user));

//         // Redirect to GameSelect
//         navigate("/GameSelect");
//       } else {
//         alert("Invalid credentials, please try again.");
//       }
//     } catch (error) {
//       console.error("Login failed:", error.response?.data || error.message);

//       if (error.response?.status === 401) {
//         alert("Unauthorized: Invalid email or password.");
//       } else if (error.response?.data?.errors) {
//         alert(`Validation Errors: ${JSON.stringify(error.response.data.errors, null, 2)}`);
//       } else {
//         alert("An error occurred. Please try again later.");
//       }
//     } finally {
//       setIsLoading(false); // End loading spinner
//     }
//   };

//   return (
//     <div className="signin-container">
//       <h1 className="signin-title">Welcome to Fling Disc</h1>
//       <form className="signin-card" onSubmit={handleLogin}>
//         <div className="input-field">
//           <label htmlFor="email">Email</label>
//           <input
//             id="email"
//             type="text"
//             placeholder="Enter your email"
//             value={email}
//             onChange={(e) => setEmail(e.target.value)}
//             required
//           />
//         </div>
//         <div className="input-field">
//           <label htmlFor="password">Password</label>
//           <input
//             id="password"
//             type="password"
//             placeholder="Enter your password"
//             value={password}
//             onChange={(e) => setPassword(e.target.value)}
//             required
//           />
//         </div>
//         <button
//           type="submit"
//           className="signin-button"
//           disabled={isLoading} // Disable button when loading
//         >
//           {isLoading ? "Signing In..." : "SIGN IN TO GET REWARDS"}
//           {!isLoading && <img src={Coins} alt="coins" />}
//         </button>
//       </form>
//       <div className="signin-divider">
//         <span className="line"></span>
//         <span className="divider-text">or</span>
//         <span className="line"></span>
//       </div>
//       <div className="signin-footer">
//         <a href="/signup" className="guest-link">
//           Signup
//         </a>
//         <span className="separator">|</span>
//         <a href="/guest" className="guest-link">
//           Continue as a Guest
//         </a>
//       </div>
//     </div>
//   );
// };

// export default SigninPage;


// import React, { useState } from "react";
// // eslint-disable-next-line
// import axios from 'axios';
// import { useNavigate } from "react-router-dom";
// import Coins from "./../assets/coins.png";
// import "./../styles/SigninPage.css"; // Import the CSS file

// const SigninPage = () => {
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");
//   const navigate = useNavigate();

//   const handleLogin = async (event) => {
//     event.preventDefault(); // Prevent the form from refreshing the page

//     if (!email || !password) {
//       alert("Please enter both email and password.");
//       return;
//     }

//     if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
//       alert("Please enter a valid email address.");
//       return;
//     }

//     try {
//       console.log("Request Payload:", { email, password });
//       const response = await axios.post(
//         "https://arcadegamebackendapi20241227164011.azurewebsites.net/api/Auth/Login",
//         { email: email, password: password },
//         { headers: { "Content-Type": "application/json" } }
//       );

//       console.log("Response Data:", response.data);

//       if (response.status === 200) {
//         navigate("/GameSelect");
//       } else {
//         alert("Invalid credentials, please try again.");
//       }
//     } catch (error) {
//       console.error("Login failed:", error.response?.data || error.message);

//       if (error.response?.data?.errors) {
//         alert(`Validation Errors: ${JSON.stringify(error.response.data.errors, null, 2)}`);
//       } else {
//         alert("An error occurred. Please try again later.");
//       }
//     }
//   };

//   return (
//     <div className="signin-container">
//       <h1 className="signin-title">Welcome to Fling Disc</h1>
//       <form className="signin-card" onSubmit={handleLogin}>
//         <div className="input-field">
//           <label htmlFor="email">Email</label>
//           <input
//             id="email"
//             type="text"
//             placeholder=""
//             value={email}
//             onChange={(e) => setEmail(e.target.value)}
//           />
//         </div>
//         <div className="input-field">
//           <label htmlFor="password">Password</label>
//           <input
//             id="password"
//             type="password"
//             placeholder=""
//             value={password}
//             onChange={(e) => setPassword(e.target.value)}
//           />
//         </div>
//         <button type="submit" className="signin-button">
//           SIGN IN TO GET REWARDS <img src={Coins} alt="coins" />
//         </button>
//       </form>
//       <div className="signin-divider">
//         <span className="line"></span>
//         <span className="divider-text">or</span>
//         <span className="line"></span>
//       </div>
//       <div className="signin-footer">
//         <a href="/signup" className="guest-link">
//           Signup
//         </a>
//         <span className="separator">|</span>
//         <a href="/guest" className="guest-link">
//           Continue as a Guest
//         </a>
//       </div>
//     </div>
//   );
// };

// export default SigninPage;



// import React, { useState } from "react";
// // eslint-disable-next-line
// import axios from 'axios';
// import { useNavigate } from "react-router-dom";
// import Coins from "./../assets/coins.png";
// import "./../styles/SigninPage.css"; // Import the CSS file

// const SigninPage = () => {
//   const [useremail, setUseremail] = useState("");
//   const [password, setPassword] = useState("");
//   const navigate = useNavigate();


//   const handleLogin = async () => {
//     if (!useremail || !password) {
//       alert("Please enter both email and password.");
//       return;
//     }
  
//     if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(useremail)) {
//       alert("Please enter a valid email address.");
//       return;
//     }
  
//     try {
//       const response = await axios.post(
//         "https://arcadegamebackendapi20241227164011.azurewebsites.net/api/Auth/Login",
//         { email: useremail, password: password },
//         { headers: { "Content-Type": "application/json" } }
//       );
  
//       if (response.status === 200) {
//         navigate("/GameSelect");
//       } else {
//         alert("Invalid credentials, please try again.");
//       }
//     } catch (error) {
//       console.error("Login failed:", error.response?.data || error.message);
  
//       if (error.response?.data?.errors) {
//         alert(`Validation Errors: ${JSON.stringify(error.response.data.errors, null, 2)}`);
//       } else {
//         alert("An error occurred. Please try again later.");
//       }
//     }
//   };
  
  


//   // const handleLogin = () => {
//   //   if (useremail && password) {
//   //     navigate("/GameSelect");
//   //   } else {
//   //     alert("Please enter both useremail and password");
//   //   }
//   // };

//   // const handleLogin = async () => {
//   //   if (useremail && password) {
//   //     try {
//   //       // Send the login request to your API
//   //       const response = await axios.post("https://arcadegamebackendapi20241227164011.azurewebsites.net/api/Auth/Login", {
//   //         email: useremail,
//   //         password: password,
//   //       });

//   //       // Check if the login was successful
//   //       if (response.status === 200) {
//   //         // Redirect to the GameSelect page upon successful login
//   //         navigate("/GameSelect");
//   //       } else {
//   //         // Handle login failure (optional)
//   //         alert("Invalid credentials, please try again.");
//   //       }
//   //     } catch (error) {
//   //       // Handle network or API errors
//   //       console.error("Login failed", error);
//   //       alert("An error occurred. Please try again later.");
//   //     }
//   //   } else {
//   //     alert("Please enter both email and password.");
//   //   }
//   // };


//   return (
//     <div className="signin-container">
//       <h1 className="signin-title">Welcome to Fling Disc</h1>
//       <div className="signin-card">
//         <div className="input-field">
//           <label htmlFor="email">Email</label>
//           <input
//             id="email"
//             type="text"
//             placeholder=""
//             value={useremail}
//             onChange={(e) => setUseremail(e.target.value)}
//           />
//         </div>
//         <div className="input-field">
//           <label htmlFor="password">Password</label>
//           <input
//             id="password"
//             type="password"
//             placeholder=""
//             value={password}
//             onChange={(e) => setPassword(e.target.value)}
//           />
//         </div>
//         <button className="signin-button" onClick={handleLogin}>
//           SIGN IN TO GET REWARDS <img src={Coins} alt="coins" />
//         </button>
//         <div className="signin-divider">
//           <span className="line"></span>
//           <span className="divider-text">or</span>
//           <span className="line"></span>
//         </div>
//         <div className="signin-footer">
//           <a href="/signup" className="guest-link">
//             Signup
//           </a>
//           <span className="separator">|</span>
//           <a href="/guest" className="guest-link">
//             Continue as a Guest
//           </a>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SigninPage;






// import React, { useState } from "react";
// import { useNavigate } from "react-router-dom";
// import "./../styles/SigninPage.css"; // Import the CSS file

// const SigninPage = () => {
//   const [useremail, setUseremail] = useState("");
//   const [password, setPassword] = useState("");
//   const navigate = useNavigate();

//   const handleLogin = () => {
//     if (useremail && password) {
//       // Simulate successful signin
//       navigate("/games");
//     } else {
//       alert("Please enter both useremail and password");
//     }
//   };

//   return (
//     <div className="signin-container">
//       <div className="signin-card">
//         <h2>Login</h2>
//         <div className="input-field">
//           <input
//             type="text"
//             placeholder="Useremail"
//             value={useremail}
//             onChange={(e) => setUseremail(e.target.value)}
//           />
//         </div>
//         <div className="input-field">
//           <input
//             type="password"
//             placeholder="Password"
//             value={password}
//             onChange={(e) => setPassword(e.target.value)}
//           />
//         </div>
//         <button className="button" onClick={handleLogin}>SIGNIN TO GET REWARDS</button>
//       </div>
//     </div>
//   );
// };

// export default SigninPage;
