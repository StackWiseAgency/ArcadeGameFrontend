
import discGolfImage from "./assets/disc-golf.png";
import ticTacToe from "./assets/tic-tac-toe.png";

export const PLACEHOLDER_IMAGES = [
    discGolfImage,
    ticTacToe,
    discGolfImage,
    ticTacToe
]