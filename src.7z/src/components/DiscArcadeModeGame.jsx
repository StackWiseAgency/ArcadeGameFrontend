import React, { useState, useEffect } from "react";
import "./DiscArcadeModeGame.css";
import timerIcon from "../assets/timer.png";
import forbiddenCircle from "../assets/forbiddenCircle.png";
import purpleDisc from "../assets/purpledisc.png";
import redDisc from "../assets/reddisc.png";
import orangeDisc from "../assets/orangedisc.png";
import blueDisc from "../assets/bluedisc.png";
import yellowDisc from "../assets/yellowdisc.png";
import greenDisc from "../assets/greendisc.png";
import backgroundImage from "../assets/background-image.png";

const DiscArcadeModeGame = ({ navigateToSelection }) => {
  const [timeLeft, setTimeLeft] = useState(0); // Increment timer
  const [score, setScore] = useState(0);
  const [misses, setMisses] = useState(0);
  const [normalDiscs, setNormalDiscs] = useState(10);
  const [bonusDiscs, setBonusDiscs] = useState(10);
  const [gameStarted, setGameStarted] = useState(false);
  const [readyToStart, setReadyToStart] = useState(false); // Control when to start the game
  const [startCountdown, setStartCountdown] = useState(null); // 3-second countdown
  const [gameEnded, setGameEnded] = useState(false);
  const [firstThrowMade, setFirstThrowMade] = useState(false); // Track if the first throw was made
  const [idleTimeout, setIdleTimeout] = useState(null); // Track idle timeout

  // Flags for input modes
  const useSimulatedInput = false; // Toggle for simulated data
  const useManualInput = true; // Toggle for manual board clicks

  const [normalDiscColors, setNormalDiscColors] = useState([
    purpleDisc,
    redDisc,
    orangeDisc,
    blueDisc,
    yellowDisc,
    purpleDisc,
    redDisc,
    orangeDisc,
    blueDisc,
    yellowDisc,
  ]);

  const [bonusDiscColors, setBonusDiscColors] = useState([
    greenDisc,
    blueDisc,
    redDisc,
    yellowDisc,
    orangeDisc,
    greenDisc,
    blueDisc,
    redDisc,
    yellowDisc,
    orangeDisc,
  ]);

  const discSize = {
    normal: "50px", // Large disc size
    bonus: "30px", // Small disc size
  };

  // Create a 3x3 grid for holes
  const initialGrid = Array(3)
    .fill(null)
    .map(() => Array(3).fill(null));

  const [grid, setGrid] = useState(initialGrid);

  // Initial countdown logic
  useEffect(() => {
    if (readyToStart && !gameStarted && startCountdown === null) {
      setStartCountdown(3); // Start the countdown when ready

      const countdownInterval = setInterval(() => {
        setStartCountdown((prev) => {
          if (prev === 1) {
            clearInterval(countdownInterval);
            setGameStarted(true); // Start the game
            setStartCountdown(null); // Reset countdown
            return null;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(countdownInterval); // Cleanup interval
    }
  }, [readyToStart, gameStarted, startCountdown]);

  // Idle detection logic
  useEffect(() => {
    if (!firstThrowMade && !gameEnded) {
      const timeout = setTimeout(() => {
        setStartCountdown(3); // Start 3-second countdown
        const countdownInterval = setInterval(() => {
          setStartCountdown((prev) => {
            if (prev === 1) {
              clearInterval(countdownInterval);
              setMisses((prevMisses) => prevMisses + 1); // Increment misses
              setStartCountdown(null); // Clear countdown
              return null;
            }
            return prev - 1;
          });
        }, 1000);

        setIdleTimeout(countdownInterval);
      }, 5000);

      return () => {
        clearTimeout(timeout); // Cleanup idle timeout
        if (idleTimeout) clearInterval(idleTimeout);
      };
    }
  }, [firstThrowMade, gameEnded, idleTimeout]);

  // Start Game on First Throw or Countdown
  const handleFirstThrow = () => {
    if (!gameStarted) {
      setGameStarted(true);
      setTimeLeft(0); // Reset timer
    }
    setFirstThrowMade(true);
    if (idleTimeout) clearInterval(idleTimeout); // Clear idle countdown if throwing
  };

  // Handle manual input (simulated click)
  const handleManualThrow = (row, col) => {
    if ((useManualInput === false && useSimulatedInput === false) || gameEnded || grid[row][col] !== null) {
      return;
    }

    handleFirstThrow(); // Start the game if it's the first throw

    const isBonus = Math.random() > 0.5; // Randomly determine disc type
    const points = isBonus ? 20 : 10;

    // Highlight the grid cell temporarily
    setGrid((prev) => {
      const newGrid = [...prev];
      newGrid[row][col] = isBonus ? "B" : "N";
      return newGrid;
    });

    setTimeout(() => {
      setGrid((prev) => {
        const newGrid = [...prev];
        newGrid[row][col] = null; // Reset cell after 1.5 seconds
        return newGrid;
      });
    }, 1500);

    if (isBonus) {
      if (bonusDiscs > 0) {
        setScore((prev) => prev + points);
        setBonusDiscs((prev) => prev - 1);
        setBonusDiscColors((prevColors) => prevColors.slice(0, -1)); // Remove one bonus disc color
      } else {
        setMisses((prev) => prev + 1); // Increment misses if no bonus discs left
      }
    } else {
      if (normalDiscs > 0) {
        setScore((prev) => prev + points);
        setNormalDiscs((prev) => prev - 1);
        setNormalDiscColors((prevColors) => prevColors.slice(0, -1)); // Remove one normal disc color
      } else {
        setMisses((prev) => prev + 1); // Increment misses if no normal discs left
      }
    }

    if (normalDiscs === 0 && bonusDiscs === 0) {
      setGameEnded(true);
    }
  };

  // Simulated Input Logic
  useEffect(() => {
    if (useSimulatedInput && !gameEnded) {
      const simulateThrows = setInterval(() => {
        if (normalDiscs <= 0 && bonusDiscs <= 0) {
          clearInterval(simulateThrows); // Stop simulation if no discs are left
          return;
        }
        const row = Math.floor(Math.random() * 3);
        const col = Math.floor(Math.random() * 3);
        handleManualThrow(row, col);
      }, 1000);

      return () => clearInterval(simulateThrows);
    }
    // eslint-disable-next-line 
  }, [normalDiscs, bonusDiscs, gameEnded, useSimulatedInput]);

  // End Game Logic
  const handleGameEnd = () => {
    setGameEnded(true);

    // Simulated disc return check
    const discsReturned = normalDiscs === 0 && bonusDiscs === 0; // Simulated check
    if (discsReturned) {
      alert("All discs returned. Game Over!");
    } else {
      alert("Please return all discs to the holding bin.");
    }
  };

  useEffect(() => {
    if (normalDiscs === 0 && bonusDiscs === 0) {
      handleGameEnd();
    }
    // eslint-disable-next-line 
  }, [normalDiscs, bonusDiscs]);

  return (
    <div
      className="arcade-game-container"
      style={{ backgroundImage: `url(${backgroundImage})` }}
    >
      {!readyToStart && (
        <button className="start-game-button" onClick={() => setReadyToStart(true)}>
          Start Game
        </button>
      )}

      {readyToStart && !gameStarted && startCountdown !== null && (
        <div className="countdown-display">
          <h2>Game starts in: {startCountdown}</h2>
        </div>
      )}

      {gameEnded && <h2>Game Over!</h2>}

      <div className="top-section">
        <div className="time-left">
          <img src={timerIcon} alt="Timer" />
          <span>{`${Math.floor(timeLeft / 60)}:${(timeLeft % 60)
            .toString()
            .padStart(2, "0")}`}</span>
        </div>
        <div className="misses">
          <img src={forbiddenCircle} alt="Misses" />
          <span>{misses}</span>
        </div>
      </div>

      <div className="score-display">
        <h1>{score.toString().padStart(3, "0")}</h1>
      </div>

      <div className="game-board1">
        {grid.map((row, rowIndex) => (
          <div key={rowIndex} className="board-row">
            {row.map((cell, colIndex) => (
              <div
                key={colIndex}
                className={`board-cell1 ${cell === "B" ? "bonus-cell" : cell === "N" ? "normal-cell" : ""}`}
                onClick={() => handleManualThrow(rowIndex, colIndex)}
              ></div>
            ))}
          </div>
        ))}
      </div>

      <div className="bottom-section">
        <div className="discs-left">
          <h3>DISCS LEFT: {normalDiscs}</h3>
          <div className="disc-info">
            {normalDiscColors.slice(0, normalDiscs).map((disc, index) => (
              <img
                key={index}
                src={disc}
                alt={`Normal Disc ${index}`}
                style={{ width: discSize.normal }}
              />
            ))}
          </div>
        </div>

        <div className="bonus-discs-left">
          <h3>BONUS DISCS LEFT: {bonusDiscs}</h3>
          <div className="disc-info">
            {bonusDiscColors.slice(0, bonusDiscs).map((disc, index) => (
              <img
                key={index}
                src={disc}
                alt={`Bonus Disc ${index}`}
                style={{ width: discSize.bonus }}
              />
            ))}
          </div>
        </div>
      </div>

      <button className="back-button" onClick={navigateToSelection}>
        Back to Selection
      </button>
    </div>
  );
};

export default DiscArcadeModeGame;



// import React, { useState, useEffect } from "react";
// import "./DiscArcadeModeGame.css";
// import timerIcon from "../assets/timer.png";
// import forbiddenCircle from "../assets/forbiddenCircle.png";
// import purpleDisc from "../assets/purpledisc.png";
// import redDisc from "../assets/reddisc.png";
// import orangeDisc from "../assets/orangedisc.png";
// import blueDisc from "../assets/bluedisc.png";
// import yellowDisc from "../assets/yellowdisc.png";
// import greenDisc from "../assets/greendisc.png";
// import backgroundImage from "../assets/background-image.png";

// const DiscArcadeModeGame = ({ navigateToSelection }) => {
//   const [timeLeft, setTimeLeft] = useState(0); // Increment timer
//   const [score, setScore] = useState(0);
//   const [misses, setMisses] = useState(0);
//   const [normalDiscs, setNormalDiscs] = useState(10);
//   const [bonusDiscs, setBonusDiscs] = useState(10);
//   const [gameStarted, setGameStarted] = useState(false);
//   const [readyToStart, setReadyToStart] = useState(false); // Control when to start the game
//   const [startCountdown, setStartCountdown] = useState(null); // 3-second countdown
//   const [gameEnded, setGameEnded] = useState(false);
//   const [firstThrowMade, setFirstThrowMade] = useState(false); // Track if the first throw was made

//   // Flags for input modes
//   const useSimulatedInput = false; // Toggle for simulated data
//   const useManualInput = true; // Toggle for manual board clicks

//   const [normalDiscColors, setNormalDiscColors] = useState([
//     purpleDisc,
//     redDisc,
//     orangeDisc,
//     blueDisc,
//     yellowDisc,
//     purpleDisc,
//     redDisc,
//     orangeDisc,
//     blueDisc,
//     yellowDisc,
//   ]);

//   const [bonusDiscColors, setBonusDiscColors] = useState([
//     greenDisc,
//     blueDisc,
//     redDisc,
//     yellowDisc,
//     orangeDisc,
//     greenDisc,
//     blueDisc,
//     redDisc,
//     yellowDisc,
//     orangeDisc,
//   ]);

//   const discSize = {
//     normal: "50px", // Large disc size
//     bonus: "30px", // Small disc size
//   };

//   // Create a 3x3 grid for holes
//   const initialGrid = Array(3)
//     .fill(null)
//     .map(() => Array(3).fill(null));

//   const [grid, setGrid] = useState(initialGrid);

//   // Initial countdown logic
//   useEffect(() => {
//     if (readyToStart && !gameStarted && startCountdown === null) {
//       setStartCountdown(3); // Start the countdown when ready

//       const countdownInterval = setInterval(() => {
//         setStartCountdown((prev) => {
//           if (prev === 1) {
//             clearInterval(countdownInterval);
//             setGameStarted(true); // Start the game
//             setStartCountdown(null); // Reset countdown
//             return null;
//           }
//           return prev - 1;
//         });
//       }, 1000);

//       return () => clearInterval(countdownInterval); // Cleanup interval
//     }
//   }, [readyToStart, gameStarted, startCountdown]);

//   // Idle detection logic
//   useEffect(() => {
//     if (firstThrowMade && !gameEnded) {
//       const idleTimeout = setTimeout(() => {
//         setStartCountdown(3); // Start 3-second countdown
//         const countdownInterval = setInterval(() => {
//           setStartCountdown((prev) => {
//             if (prev === 1) {
//               clearInterval(countdownInterval);
//               setMisses((prevMisses) => prevMisses + 1); // Increment misses
//               setStartCountdown(null); // Clear countdown
//               return null;
//             }
//             return prev - 1;
//           });
//         }, 1000);
//       }, 5000);

//       return () => {
//         clearTimeout(idleTimeout); // Cleanup idle timeout
//       };
//     }
//   }, [firstThrowMade, gameEnded]);

//   // Start Game on First Throw or Countdown
//   const handleFirstThrow = () => {
//     if (!gameStarted) {
//       setGameStarted(true);
//       setTimeLeft(0); // Reset timer
//     }
//     setFirstThrowMade(true);
//   };

//   // Handle manual input (simulated click)
//   const handleManualThrow = (row, col) => {
//     if ((useManualInput === false && useSimulatedInput === false) || gameEnded || grid[row][col] !== null) {
//       return;
//     }

//     handleFirstThrow(); // Start the game if it's the first throw

//     const isBonus = Math.random() > 0.5; // Randomly determine disc type
//     const points = isBonus ? 20 : 10;

//     // Highlight the grid cell temporarily
//     setGrid((prev) => {
//       const newGrid = [...prev];
//       newGrid[row][col] = isBonus ? "B" : "N";
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = [...prev];
//         newGrid[row][col] = null; // Reset cell after 1.5 seconds
//         return newGrid;
//       });
//     }, 1500);

//     if (isBonus) {
//       if (bonusDiscs > 0) {
//         setScore((prev) => prev + points);
//         setBonusDiscs((prev) => prev - 1);
//         setBonusDiscColors((prevColors) => prevColors.slice(0, -1)); // Remove one bonus disc color
//       } else {
//         setMisses((prev) => prev + 1); // Increment misses if no bonus discs left
//       }
//     } else {
//       if (normalDiscs > 0) {
//         setScore((prev) => prev + points);
//         setNormalDiscs((prev) => prev - 1);
//         setNormalDiscColors((prevColors) => prevColors.slice(0, -1)); // Remove one normal disc color
//       } else {
//         setMisses((prev) => prev + 1); // Increment misses if no normal discs left
//       }
//     }

//     if (normalDiscs === 0 && bonusDiscs === 0) {
//       setGameEnded(true);
//     }
//   };

//   // Simulated Input Logic
//   useEffect(() => {
//     if (useSimulatedInput && !gameEnded) {
//       const simulateThrows = setInterval(() => {
//         if (normalDiscs <= 0 && bonusDiscs <= 0) {
//           clearInterval(simulateThrows); // Stop simulation if no discs are left
//           return;
//         }
//         const row = Math.floor(Math.random() * 3);
//         const col = Math.floor(Math.random() * 3);
//         handleManualThrow(row, col);
//       }, 1000);

//       return () => clearInterval(simulateThrows);
//     }
//   }, [normalDiscs, bonusDiscs, gameEnded, useSimulatedInput]);

//   // End Game Logic
//   const handleGameEnd = () => {
//     setGameEnded(true);

//     // Simulated disc return check
//     const discsReturned = normalDiscs === 0 && bonusDiscs === 0; // Simulated check
//     if (discsReturned) {
//       alert("All discs returned. Game Over!");
//     } else {
//       alert("Please return all discs to the holding bin.");
//     }
//   };

//   useEffect(() => {
//     if (normalDiscs === 0 && bonusDiscs === 0) {
//       handleGameEnd();
//     }
//   }, [normalDiscs, bonusDiscs]);

//   return (
//     <div
//       className="arcade-game-container"
//       style={{ backgroundImage: `url(${backgroundImage})` }}
//     >
//       {!readyToStart && (
//         <button className="start-game-button" onClick={() => setReadyToStart(true)}>
//           Start Game
//         </button>
//       )}

//       {readyToStart && !gameStarted && startCountdown !== null && (
//         <div className="countdown-display">
//           <h2>Game starts in: {startCountdown}</h2>
//         </div>
//       )}

//       {gameEnded && <h2>Game Over!</h2>}

//       <div className="top-section">
//         <div className="time-left">
//           <img src={timerIcon} alt="Timer" />
//           <span>{`${Math.floor(timeLeft / 60)}:${(timeLeft % 60)
//             .toString()
//             .padStart(2, "0")}`}</span>
//         </div>
//         <div className="misses">
//           <img src={forbiddenCircle} alt="Misses" />
//           <span>{misses}</span>
//         </div>
//       </div>

//       <div className="score-display">
//         <h1>{score.toString().padStart(3, "0")}</h1>
//       </div>

//       <div className="game-board tictactoe-board">
//         {grid.map((row, rowIndex) => (
//           <div key={rowIndex} className="board-row">
//             {row.map((cell, colIndex) => (
//               <div
//                 key={colIndex}
//                 className={`board-cell ${cell === "B" ? "bonus-cell" : cell === "N" ? "normal-cell" : ""}`}
//                 onClick={() => handleManualThrow(rowIndex, colIndex)}
//               ></div>
//             ))}
//           </div>
//         ))}
//       </div>

//       <div className="bottom-section">
//         <div className="discs-left">
//           <h3>DISCS LEFT: {normalDiscs}</h3>
//           <div className="disc-info">
//             {normalDiscColors.slice(0, normalDiscs).map((disc, index) => (
//               <img
//                 key={index}
//                 src={disc}
//                 alt={`Normal Disc ${index}`}
//                 style={{ width: discSize.normal }}
//               />
//             ))}
//           </div>
//         </div>

//         <div className="bonus-discs-left">
//           <h3>BONUS DISCS LEFT: {bonusDiscs}</h3>
//           <div className="disc-info">
//             {bonusDiscColors.slice(0, bonusDiscs).map((disc, index) => (
//               <img
//                 key={index}
//                 src={disc}
//                 alt={`Bonus Disc ${index}`}
//                 style={{ width: discSize.bonus }}
//               />
//             ))}
//           </div>
//         </div>
//       </div>

//       <button className="back-button" onClick={navigateToSelection}>
//         Back to Selection
//       </button>
//     </div>
//   );
// };

// export default DiscArcadeModeGame;



// import React, { useState, useEffect } from "react";
// import "./DiscArcadeModeGame.css";
// import timerIcon from "../assets/timer.png";
// import forbiddenCircle from "../assets/forbiddenCircle.png";
// import purpleDisc from "../assets/purpledisc.png";
// import redDisc from "../assets/reddisc.png";
// import orangeDisc from "../assets/orangedisc.png";
// import blueDisc from "../assets/bluedisc.png";
// import yellowDisc from "../assets/yellowdisc.png";
// import greenDisc from "../assets/greendisc.png";
// import backgroundImage from "../assets/background-image.png";

// const DiscArcadeModeGame = ({ navigateToSelection }) => {
//   const [timeLeft, setTimeLeft] = useState(0); // Increment timer
//   const [score, setScore] = useState(0);
//   const [misses, setMisses] = useState(0);
//   const [normalDiscs, setNormalDiscs] = useState(10);
//   const [bonusDiscs, setBonusDiscs] = useState(10);
//   const [gameStarted, setGameStarted] = useState(false);
//   const [startCountdown, setStartCountdown] = useState(3); // 3-second countdown
//   const [gameEnded, setGameEnded] = useState(false);
//   const [firstThrowMade, setFirstThrowMade] = useState(false); // Track if the first throw was made

//   // Flags for input modes
//   const useSimulatedInput = false; // Toggle for simulated data
//   const useManualInput = true; // Toggle for manual board clicks

//   const [normalDiscColors, setNormalDiscColors] = useState([
//     purpleDisc,
//     redDisc,
//     orangeDisc,
//     blueDisc,
//     yellowDisc,
//     purpleDisc,
//     redDisc,
//     orangeDisc,
//     blueDisc,
//     yellowDisc,
//   ]);

//   const [bonusDiscColors, setBonusDiscColors] = useState([
//     greenDisc,
//     blueDisc,
//     redDisc,
//     yellowDisc,
//     orangeDisc,
//     greenDisc,
//     blueDisc,
//     redDisc,
//     yellowDisc,
//     orangeDisc,
//   ]);

//   const discSize = {
//     normal: "50px", // Large disc size
//     bonus: "30px", // Small disc size
//   };

//   // Create a 3x3 grid for holes
//   const initialGrid = Array(3)
//     .fill(null)
//     .map(() => Array(3).fill(null));

//   const [grid, setGrid] = useState(initialGrid);

//   // Initial countdown logic
//   useEffect(() => {
//     if (!gameStarted && startCountdown !== null) {
//       const countdownInterval = setInterval(() => {
//         setStartCountdown((prev) => {
//           if (prev === 1) {
//             clearInterval(countdownInterval);
//             setGameStarted(true); // Start the game
//             setStartCountdown(null); // Reset countdown
//             return null;
//           }
//           return prev - 1;
//         });
//       }, 1000);

//       return () => clearInterval(countdownInterval); // Cleanup interval
//     }
//   }, [gameStarted, startCountdown]);

//   // Idle detection logic
//   useEffect(() => {
//     if (firstThrowMade && !gameEnded) {
//       const idleTimeout = setTimeout(() => {
//         setStartCountdown(3); // Start 3-second countdown
//         const countdownInterval = setInterval(() => {
//           setStartCountdown((prev) => {
//             if (prev === 1) {
//               clearInterval(countdownInterval);
//               setMisses((prevMisses) => prevMisses + 1); // Increment misses
//               setStartCountdown(null); // Clear countdown
//               return null;
//             }
//             return prev - 1;
//           });
//         }, 1000);
//       }, 5000);

//       return () => {
//         clearTimeout(idleTimeout); // Cleanup idle timeout
//       };
//     }
//   }, [firstThrowMade, gameEnded]);

//   // Start Game on First Throw or Countdown
//   const handleFirstThrow = () => {
//     if (!gameStarted) {
//       setGameStarted(true);
//       setTimeLeft(0); // Reset timer
//     }
//     setFirstThrowMade(true);
//   };

//   // Handle manual input (simulated click)
//   const handleManualThrow = (row, col) => {
//     if ((useManualInput === false && useSimulatedInput === false) || gameEnded || grid[row][col] !== null) {
//       return;
//     }

//     handleFirstThrow(); // Start the game if it's the first throw

//     const isBonus = Math.random() > 0.5; // Randomly determine disc type
//     const points = isBonus ? 20 : 10;

//     // Highlight the grid cell temporarily
//     setGrid((prev) => {
//       const newGrid = [...prev];
//       newGrid[row][col] = isBonus ? "B" : "N";
//       return newGrid;
//     });

//     setTimeout(() => {
//       setGrid((prev) => {
//         const newGrid = [...prev];
//         newGrid[row][col] = null; // Reset cell after 1.5 seconds
//         return newGrid;
//       });
//     }, 1500);

//     if (isBonus) {
//       if (bonusDiscs > 0) {
//         setScore((prev) => prev + points);
//         setBonusDiscs((prev) => prev - 1);
//         setBonusDiscColors((prevColors) => prevColors.slice(0, -1)); // Remove one bonus disc color
//       } else {
//         setMisses((prev) => prev + 1); // Increment misses if no bonus discs left
//       }
//     } else {
//       if (normalDiscs > 0) {
//         setScore((prev) => prev + points);
//         setNormalDiscs((prev) => prev - 1);
//         setNormalDiscColors((prevColors) => prevColors.slice(0, -1)); // Remove one normal disc color
//       } else {
//         setMisses((prev) => prev + 1); // Increment misses if no normal discs left
//       }
//     }

//     if (normalDiscs === 0 && bonusDiscs === 0) {
//       setGameEnded(true);
//     }
//   };

//   // Simulated Input Logic
//   useEffect(() => {
//     if (useSimulatedInput && !gameEnded) {
//       const simulateThrows = setInterval(() => {
//         if (normalDiscs <= 0 && bonusDiscs <= 0) {
//           clearInterval(simulateThrows); // Stop simulation if no discs are left
//           return;
//         }
//         const row = Math.floor(Math.random() * 3);
//         const col = Math.floor(Math.random() * 3);
//         handleManualThrow(row, col);
//       }, 1000);

//       return () => clearInterval(simulateThrows);
//     }
//   }, [normalDiscs, bonusDiscs, gameEnded, useSimulatedInput]);

//   // End Game Logic
//   const handleGameEnd = () => {
//     setGameEnded(true);

//     // Simulated disc return check
//     const discsReturned = normalDiscs === 0 && bonusDiscs === 0; // Simulated check
//     if (discsReturned) {
//       alert("All discs returned. Game Over!");
//     } else {
//       alert("Please return all discs to the holding bin.");
//     }
//   };

//   useEffect(() => {
//     if (normalDiscs === 0 && bonusDiscs === 0) {
//       handleGameEnd();
//     }
//   }, [normalDiscs, bonusDiscs]);

//   return (
//     <div
//       className="arcade-game-container"
//       style={{ backgroundImage: `url(${backgroundImage})` }}
//     >
//       {!gameStarted && startCountdown !== null && (
//         <div className="countdown-display">
//           <h2>Game starts in: {startCountdown}</h2>
//         </div>
//       )}

//       {gameEnded && <h2>Game Over!</h2>}

//       <div className="top-section">
//         <div className="time-left">
//           <img src={timerIcon} alt="Timer" />
//           <span>{`${Math.floor(timeLeft / 60)}:${(timeLeft % 60)
//             .toString()
//             .padStart(2, "0")}`}</span>
//         </div>
//         <div className="misses">
//           <img src={forbiddenCircle} alt="Misses" />
//           <span>{misses}</span>
//         </div>
//       </div>

//       <div className="score-display">
//         <h1>{score.toString().padStart(3, "0")}</h1>
//       </div>

//       <div className="game-board tictactoe-board">
//         {grid.map((row, rowIndex) => (
//           <div key={rowIndex} className="board-row">
//             {row.map((cell, colIndex) => (
//               <div
//                 key={colIndex}
//                 className={`board-cell ${cell === "B" ? "bonus-cell" : cell === "N" ? "normal-cell" : ""}`}
//                 onClick={() => handleManualThrow(rowIndex, colIndex)}
//               ></div>
//             ))}
//           </div>
//         ))}
//       </div>

//       <div className="bottom-section">
//         <div className="discs-left">
//           <h3>DISCS LEFT: {normalDiscs}</h3>
//           <div className="disc-info">
//             {normalDiscColors.slice(0, normalDiscs).map((disc, index) => (
//               <img
//                 key={index}
//                 src={disc}
//                 alt={`Normal Disc ${index}`}
//                 style={{ width: discSize.normal }}
//               />
//             ))}
//           </div>
//         </div>

//         <div className="bonus-discs-left">
//           <h3>BONUS DISCS LEFT: {bonusDiscs}</h3>
//           <div className="disc-info">
//             {bonusDiscColors.slice(0, bonusDiscs).map((disc, index) => (
//               <img
//                 key={index}
//                 src={disc}
//                 alt={`Bonus Disc ${index}`}
//                 style={{ width: discSize.bonus }}
//               />
//             ))}
//           </div>
//         </div>
//       </div>

//       <button className="back-button" onClick={navigateToSelection}>
//         Back to Selection
//       </button>
//     </div>
//   );
// };

// export default DiscArcadeModeGame;



