import React from "react";
import "./PlayersQueue.css";

import avatar1 from "../assets/profile-icon.png";

const PlayersQueue = ({ onClose }) => {
  const players = [
    { name: "azeemsmart1777", game: "Tic Tac Toe", score: 245464 },
    { name: "azeemsmart1777", game: "Tic Tac Toe", score: 154656 },
    { name: "azeemsmart1777", game: "Tic Tac Toe", score: 15454 },
    { name: "azeemsmart1777", game: "Tic Tac Toe", score: 2211 },
  ];
  // axios.get('url')
  return (
    <div className="queue-modal-container">
      <div className="modal-overlay"></div>
      <div className="queue-modal">
        <h2>
          While waiting for your turn, feel free to explore the store and
          discover more exciting options.
        </h2>
        <p>You will be notified by email when it's your turn to play!</p>

        <table className="players-table">
          <thead>
            <tr>
              <th>Players</th>
              <th>Game in Play</th>
              <th>High Score</th>
            </tr>
          </thead>
          <tbody>
            {players.map((player, index) => (
              <tr key={index}>
                <td>
                  <div className="player-info">
                    <img
                      src={avatar1}
                      alt={player.name}
                      className="player-avatar"
                    />
                    {player.name}
                  </div>
                </td>
                <td>{player.game}</td>
                <td>{player.score}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="queue-footer">
          <button onClick={onClose} className="close-button">
            <p>Total Players in Queue: {players.length}</p>
          </button>
        </div>


      </div>
    </div>
  );
};

export default PlayersQueue;
