// Timer.js (inside components)
import React, { useState, useEffect } from 'react';

const Timer = () => {
  const [seconds, setSeconds] = useState(0); // Timer state

  useEffect(() => {
    const interval = setInterval(() => {
      setSeconds(prevSeconds => prevSeconds + 1); // Increase time by 1 second
    }, 1000);

    return () => clearInterval(interval); // Cleanup on unmount
  }, []);

  return (
    <div className="timer">
      <h2>Timer: {seconds} seconds</h2>
    </div>
  );
};

export default Timer;
