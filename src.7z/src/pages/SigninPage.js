import React, { useState } from "react";
// eslint-disable-next-line
import axios from 'axios';
import { useNavigate } from "react-router-dom";
import Coins from "./../assets/coins.png";
import "./../styles/SigninPage.css"; // Import the CSS file

const SigninPage = () => {
  const [useremail, setUseremail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = () => {
    if (useremail && password) {
      navigate("/GameSelect");
    } else {
      alert("Please enter both useremail and password");
    }
  };

  // const handleLogin = async () => {
  //   if (useremail && password) {
  //     try {
  //       // Send the login request to your API
  //       const response = await axios.post("YOUR_API_URL", {
  //         email: useremail,
  //         password: password,
  //       });

  //       // Check if the login was successful
  //       if (response.status === 200) {
  //         // Redirect to the GameSelect page upon successful login
  //         navigate("/GameSelect");
  //       } else {
  //         // Handle login failure (optional)
  //         alert("Invalid credentials, please try again.");
  //       }
  //     } catch (error) {
  //       // Handle network or API errors
  //       console.error("Login failed", error);
  //       alert("An error occurred. Please try again later.");
  //     }
  //   } else {
  //     alert("Please enter both email and password.");
  //   }
  // };


  return (
    <div className="signin-container">
      <h1 className="signin-title">Welcome to Fling Disc</h1>
      <div className="signin-card">
        <div className="input-field">
          <label htmlFor="email">Email</label>
          <input
            id="email"
            type="text"
            placeholder=""
            value={useremail}
            onChange={(e) => setUseremail(e.target.value)}
          />
        </div>
        <div className="input-field">
          <label htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            placeholder=""
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <button className="signin-button" onClick={handleLogin}>
          SIGN IN TO GET REWARDS <img src={Coins} alt="coins" />
        </button>
        <div className="signin-divider">
          <span className="line"></span>
          <span className="divider-text">or</span>
          <span className="line"></span>
        </div>
        <div className="signin-footer">
          <a href="/signup" className="guest-link">
            Signup
          </a>
          <span className="separator">|</span>
          <a href="/guest" className="guest-link">
            Continue as a Guest
          </a>
        </div>
      </div>
    </div>
  );
};

export default SigninPage;






// import React, { useState } from "react";
// import { useNavigate } from "react-router-dom";
// import "./../styles/SigninPage.css"; // Import the CSS file

// const SigninPage = () => {
//   const [useremail, setUseremail] = useState("");
//   const [password, setPassword] = useState("");
//   const navigate = useNavigate();

//   const handleLogin = () => {
//     if (useremail && password) {
//       // Simulate successful signin
//       navigate("/games");
//     } else {
//       alert("Please enter both useremail and password");
//     }
//   };

//   return (
//     <div className="signin-container">
//       <div className="signin-card">
//         <h2>Login</h2>
//         <div className="input-field">
//           <input
//             type="text"
//             placeholder="Useremail"
//             value={useremail}
//             onChange={(e) => setUseremail(e.target.value)}
//           />
//         </div>
//         <div className="input-field">
//           <input
//             type="password"
//             placeholder="Password"
//             value={password}
//             onChange={(e) => setPassword(e.target.value)}
//           />
//         </div>
//         <button className="button" onClick={handleLogin}>SIGNIN TO GET REWARDS</button>
//       </div>
//     </div>
//   );
// };

// export default SigninPage;
