
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import "./../styles/SignupPage.css";
import Coins from "./../assets/coins.png";
import defaultprofile from "./../assets/default-profile.png";
import QRCodeImage from "./../assets/qr-code.png"; // QR code image

const SignupPage = () => {
  const [formData, setFormData] = useState({
    profilePicture: null,
    name: "",
    username: "",
    email: "",
    password: "",
    optInRecording: false,
    subscribeMailing: false,
    
  });

  const navigate = useNavigate();

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === "checkbox" ? checked : value,
    });
  };

  // eslint-disable-next-line
  // const handleFileChange = (e) => {
  //   const files = e.target.files;
  //   const reader = new FileReader();
  //   reader.onloadend = function () {
  //     if (typeof reader.result === 'string') {
  //       setFormData({
  //         ...formData,
  //         profilePicture: reader.result,
  //       });
  //     }
  //   };
  //   reader.readAsDataURL(files[0]);
  // };

  const handleFileChange = (e) => {
    const files = e.target.files;
    if (files[0]) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({
          ...formData,
          profilePicture: files[0],  // Directly store the file object
        });
      };
      reader.readAsDataURL(files[0]);
    }
  };

  // const handleSignup = () => {
  //   if (formData.name && formData.username && formData.email && formData.password) {
  //     alert("Account created successfully!");
  //     navigate("/GameSelect");
  //   } else {
  //     alert("Please fill in all required fields!");
  //   }
  //   ////////////////////////

  //   // const result = await axios.post('', formData);
  //   // if (result === 200) {
  //   //   navigate('/sign')
  //   // }
  // };

  // const handleSignup = async () => {
  //   // Check if required fields are filled
  //   if (formData.name && formData.username && formData.email && formData.password) {
  //     try {
  //       // Replace 'YOUR_API_ENDPOINT' with your actual API URL
  //       const result = await axios.post('https://localhost:7223/api/SignUp', formData, {
  //         headers: {
  //           'Content-Type': 'application/json'  // Set the content type to JSON
  //         }
  //       });
  
  //       // Check if the response status is 200 (successful account creation)
  //       if (result.status === 200) {
  //         alert("Account created successfully!");
  //         navigate("/GameSelect");  // Navigate to another page upon success
  //       } else {
  //         alert("There was an issue with creating your account. Please try again.");
  //       }
  //     } catch (error) {
  //       // Handle any error from the API request
  //       console.error("Error creating account:", error);
  //       alert("There was an error creating your account. Please try again later.");
  //     }
  //   } else {
  //     // If any required field is missing, show an alert
  //     alert("Please fill in all required fields!");
  //   }
  // };
  
  const handleSignup = async () => {
    if (formData.name && formData.username && formData.email && formData.password) {
      try {
        
        const formDataToSend = new FormData();
        if (formData.profilePicture) {
          formDataToSend.append("profilePicture", formData.profilePicture);  
        }
        formDataToSend.append("name", formData.name);
        formDataToSend.append("username", formData.username);
        formDataToSend.append("email", formData.email);
        formDataToSend.append("password", formData.password);
        formDataToSend.append("optInRecording", formData.optInRecording);
        formDataToSend.append("subscribeMailing", formData.subscribeMailing);
        

        
        const result = await axios.post("http:// 192.168.18.16:5278/api/SignUp", formDataToSend, {
          headers: {
            "Content-Type": "multipart/form-data", 
          },
        });

        if (result.status === 200) {
          alert("Account created successfully!");
          navigate("/GameSelect");
        }
      } catch (error) {
        console.error("Error creating account:", error.response || error.message);
        alert("There was an error creating your account. Please try again later.");
      }
    } else {
      alert("Please fill in all required fields!");
    }
  };


  return (
    <div className="signup-container">
      <h1 className="signup-title">Welcome to Fling Disc</h1>
      <div className="signup-card">
        <div className="profile-picture">
          <img src={formData.profilePicture ? URL.createObjectURL(formData.profilePicture) : defaultprofile} alt="Profile" />
          <div>
            <input
              type="file"
              id="fileInput"
              onChange={handleFileChange}
              style={{ display: 'none' }}
            />
            <button
              className="upload-btn"
              onClick={() => document.getElementById('fileInput').click()} 
            >
              +
            </button>
          </div>
        </div>
        <div className="input-field">
          <label htmlFor="name">Name</label>
          <input
            id="name"
            type="text"
            name="name"
            placeholder=""
            value={formData.name}
            onChange={handleInputChange}
          />
        </div>
        <div className="input-field">
          <label htmlFor="username">User Name</label>
          <input
            id="username"
            type="text"
            name="username"
            placeholder=""
            value={formData.username}
            onChange={handleInputChange}
          />
        </div>
        <div className="input-field">
          <label htmlFor="email">Email Address</label>
          <input
            id="email"
            type="email"
            name="email"
            placeholder=""
            value={formData.email}
            onChange={handleInputChange}
          />
        </div>
        <div className="input-field">
          <label htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            name="password"
            placeholder=""
            value={formData.password}
            onChange={handleInputChange}
          />
        </div>
        <div className="checkbox-group">
          <label>
            <input
              type="checkbox"
              name="optInRecording"
              checked={formData.optInRecording}
              onChange={handleInputChange}
            />
            Opt-in for Video Recording
          </label>
          <label>
            <input
              type="checkbox"
              name="subscribeMailing"
              checked={formData.subscribeMailing}
              onChange={handleInputChange}
            />
            Subscribe to Mailing Lists
          </label>
        </div>
        <button className="signup-button" onClick={handleSignup}>
          SIGN UP TO GET REWARDS <img src={Coins} alt="Coins" />
        </button>
        <div className="signup-divider">
          <span className="line"></span>
          <span className="divider-text">or</span>
          <span className="line"></span>
        </div>
        <div className="signup-footer">
          <a href="/signin" className="guest-link">
            Sign in
          </a>
          <span className="separator">|</span>
          <a href="/guest" className="guest-link">
            Continue as a Guest
          </a>
        </div>
        
        <div className="qr-section">
          <img src={QRCodeImage} alt="QR Code" className="qr-code" />
          <p>Scan this QR code to complete your registration on your personal device.</p>
        </div>
      </div>
    </div>
  );
};

export default SignupPage;


// import React, { useState } from "react";
// import { useNavigate } from "react-router-dom";
// import "./../styles/SignupPage.css";
// import Coins from "./../assets/coins.png";
// import defaultprofile from "./../assets/default-profile.png";
// import QRCodeImage from "./../assets/qr-code.png"; // QR code image

// const SignupPage = () => {
//   const [formData, setFormData] = useState({
//     name: "",
//     username: "",
//     email: "",
//     password: "",
//     optInRecording: false,
//     subscribeMailing: false,
//     profilePicture: null,
//   });

//   const [errors, setErrors] = useState({
//     name: "",
//     username: "",
//     email: "",
//     password: "",
//   });  

//   const navigate = useNavigate();

//   const handleInputChange = (e) => {
//     const { name, value, type, checked } = e.target;
//     setFormData({
//       ...formData,
//       [name]: type === "checkbox" ? checked : value,
//     });
//   };



//   // Real-time validation
//   let errorMessage = "";

//   if (name === "name") {
//     // Name should not have special characters or numbers
//     if (!/^[a-zA-Z\s]+$/.test(value)) {
//       errorMessage = "Name should not contain special characters or numbers.";
//     }
//   } else if (name === "username") {
//     // Username should not have spaces
//     if (/\s/.test(value)) {
//       errorMessage = "Username should not contain spaces.";
//     }
//   } else if (name === "email") {
//     // Check if email is valid
//     const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
//     if (!emailRegex.test(value)) {
//       errorMessage = "Please enter a valid email address.";
//     }
//   } else if (name === "password") {
//     // Password should be at least 8 characters long
//     if (value.length < 8) {
//       errorMessage = "Password must be at least 8 characters long.";
//     }
//   }

//   // Update errors state
//   setErrors({
//     ...errors,
//     [name]: errorMessage,
//   });
//   };  

//   // eslint-disable-next-line
//   const handleFileChange = (e) => {
//     const files = e.target.files;
//     const reader = new FileReader();
//     reader.onloadend = function () {
//       if (typeof reader.result === 'string') {
//         setFormData({
//           ...formData,
//           profilePicture: reader.result,
//         });
//       }
//     };
//     reader.readAsDataURL(files[0]);
//   };

//   const handleSignup = () => {
//     if (formData.name && formData.username && formData.email && formData.password) {
//       alert("Account created successfully!");
//       navigate("/GameSelect");
//     } else {
//       alert("Please fill in all required fields!");
//     }
//     ////////////////////////

//     // const result = await axios.post('', formData);
//     // if (result === 200) {
//     //   navigate('/sign')
//     // }

//   };


//   return (
//     <div className="signup-container">
//       <h1 className="signup-title">Welcome to Fling Disc</h1>
//       <div className="signup-card">
//         <div className="profile-picture">
//           <img src={formData.profilePicture ? formData.profilePicture : defaultprofile} alt="Profile" />
//           <div>
//             <input
//               type="file"
//               id="fileInput"
//               onChange={handleFileChange}
//               style={{ display: 'none' }}
//             />
//             <button
//               className="upload-btn"
//               onClick={() => document.getElementById('fileInput').click()} // Trigger the input when the button is clicked
//             >
//               +
//             </button>
//           </div>
//         </div>
//         <div className="input-field">
//           <label htmlFor="name">Name</label>
//           <input
//             id="name"
//             type="text"
//             name="name"
//             placeholder=""
//             value={formData.name}
//             onChange={handleInputChange}
//           />
//            {errors.name && <div className="error-message">{errors.name}</div>}
//         </div>
//         <div className="input-field">
//           <label htmlFor="username">User Name</label>
//           <input
//             id="username"
//             type="text"
//             name="username"
//             placeholder=""
//             value={formData.username}
//             onChange={handleInputChange}
//           />
//           {errors.username && <div className="error-message">{errors.username}</div>}
//         </div>
//         <div className="input-field">
//           <label htmlFor="email">Email Address</label>
//           <input
//             id="email"
//             type="email"
//             name="email"
//             placeholder=""
//             value={formData.email}
//             onChange={handleInputChange}
//           />
//           {errors.email && <div className="error-message">{errors.email}</div>}
//         </div>
//         <div className="input-field">
//           <label htmlFor="password">Password</label>
//           <input
//             id="password"
//             type="password"
//             name="password"
//             placeholder=""
//             value={formData.password}
//             onChange={handleInputChange}
//           />
//           {errors.password && <div className="error-message">{errors.password}</div>}
//         </div>
//         <div className="checkbox-group">
//           <label>
//             <input
//               type="checkbox"
//               name="optInRecording"
//               checked={formData.optInRecording}
//               onChange={handleInputChange}
//             />
//             Opt-in for Video Recording
//           </label>
//           <label>
//             <input
//               type="checkbox"
//               name="subscribeMailing"
//               checked={formData.subscribeMailing}
//               onChange={handleInputChange}
//             />
//             Subscribe to Mailing Lists
//           </label>
//         </div>
//         <button className="signup-button" onClick={handleSignup}>
//           SIGN UP TO GET REWARDS <img src={Coins} alt="Coins" />
//         </button>
//         <div className="signup-divider">
//           <span className="line"></span>
//           <span className="divider-text">or</span>
//           <span className="line"></span>
//         </div>
//         <div className="signup-footer">
//           <a href="/signin" className="guest-link">
//             Sign in
//           </a>
//           <span className="separator">|</span>
//           <a href="/guest" className="guest-link">
//             Continue as a Guest
//           </a>
//         </div>
//         {/* QR Code Section */}
//         <div className="qr-section">
//           <img src={QRCodeImage} alt="QR Code" className="qr-code" />
//           <p>Scan this QR code to complete your registration on your personal device.</p>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SignupPage;











// import React, { useState } from "react";
// import { useNavigate } from "react-router-dom";
// import "./../styles/SignupPage.css";
// import Coins from "./../assets/coins.png";

// import defaultprofile from "./../assets/default-profile.png";

// const SignupPage = () => {
//   const [formData, setFormData] = useState({
//     name: "",
//     username: "",
//     email: "",
//     password: "",
//     optInRecording: false,
//     subscribeMailing: false,
//   });

//   const navigate = useNavigate();

//   const handleInputChange = (e) => {
//     const { name, value, type, checked } = e.target;
//     setFormData({
//       ...formData,
//       [name]: type === "checkbox" ? checked : value,
//     });
//   };

//   const handleSignup = () => {
//     if (formData.name && formData.username && formData.email && formData.password) {
//       alert("Account created successfully!");
//       navigate("/GameSelect");
//     } else {
//       alert("Please fill in all required fields!");
//     }
//   };

//   return (
//     <div className="signup-container">
//       <h1 className="signup-title">Welcome to Fling Disc</h1>
//       <div className="signup-card">
//         <div className="profile-picture">
//           <img src={defaultprofile} alt="Profile" />
//           <button className="upload-btn">+</button>
//         </div>
//         <div className="input-field">
//           <label htmlFor="name">Name</label>
//           <input
//             id="name"
//             type="text"
//             name="name"
//             placeholder=""
//             value={formData.name}
//             onChange={handleInputChange}
//           />
//         </div>
//         <div className="input-field">
//           <label htmlFor="username">User Name</label>
//           <input
//             id="username"
//             type="text"
//             name="username"
//             placeholder=""
//             value={formData.username}
//             onChange={handleInputChange}
//           />
//         </div>
//         <div className="input-field">
//           <label htmlFor="email">Email Address</label>
//           <input
//             id="email"
//             type="email"
//             name="email"
//             placeholder=""
//             value={formData.email}
//             onChange={handleInputChange}
//           />
//         </div>
//         <div className="input-field">
//           <label htmlFor="password">Password</label>
//           <input
//             id="password"
//             type="password"
//             name="password"
//             placeholder=""
//             value={formData.password}
//             onChange={handleInputChange}
//           />
//         </div>
//         <div className="checkbox-group">
//           <label>
//             <input
//               type="checkbox"
//               name="optInRecording"
//               checked={formData.optInRecording}
//               onChange={handleInputChange}
//             />
//             Opt-in for Video Recording
//           </label>
//           <label>
//             <input
//               type="checkbox"
//               name="subscribeMailing"
//               checked={formData.subscribeMailing}
//               onChange={handleInputChange}
//             />
//             Subscribe to Mailing Lists
//           </label>
//         </div>
//         <button className="signup-button" onClick={handleSignup}>
//           SIGN UP TO GET REWARDS <img src={Coins} alt="Coins" />
//         </button>
//         <div className="signup-divider">
//           <span className="line"></span>
//           <span className="divider-text">or</span>
//           <span className="line"></span>
//         </div>
//         <div className="signup-footer">
//           <a href="/signin" className="guest-link">
//             Sign in
//           </a>
//           <span className="separator">|</span>
//           <a href="/guest" className="guest-link">
//             Continue as a Guest
//           </a>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SignupPage;




